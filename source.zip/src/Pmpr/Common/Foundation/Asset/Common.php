<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c61c8485             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\145\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\x6f\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\x69\x67\x72\x61\164\145"; }
