<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2ce2062a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\145\x72\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\x6d\x69\147\x72\141\x74\145"; }
