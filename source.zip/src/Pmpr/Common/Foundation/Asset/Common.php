<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\x75\145\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\x6f\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\155\x69\147\x72\141\x74\x65"; }
