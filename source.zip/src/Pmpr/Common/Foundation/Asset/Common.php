<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16ccfaa782             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\145\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\143\157\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\147\x72\x61\x74\x65"; }
