<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6052e08a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\165\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\x6f\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\x6d\151\x67\162\141\x74\145"; }
