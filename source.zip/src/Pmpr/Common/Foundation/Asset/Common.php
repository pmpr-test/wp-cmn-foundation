<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec064496439             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\x6f\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\x67\x72\x61\x74\x65"; }
