<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\145\x72\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\157\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\x67\162\141\164\x65"; }
