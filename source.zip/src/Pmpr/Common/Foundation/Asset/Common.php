<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ec0c0505             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\157\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\147\162\141\164\145"; }
