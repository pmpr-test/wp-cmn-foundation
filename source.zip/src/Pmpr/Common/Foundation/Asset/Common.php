<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae859a8f03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\x75\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\x6f\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\x67\162\141\164\x65"; }
