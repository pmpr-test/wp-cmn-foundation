<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77d1b4081             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\x75\x65\x72\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\157\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\x6d\x69\x67\162\x61\164\x65"; }
