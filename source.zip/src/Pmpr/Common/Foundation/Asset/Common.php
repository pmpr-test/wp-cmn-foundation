<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e76cb0010             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\157\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\151\x67\162\141\x74\145"; }
