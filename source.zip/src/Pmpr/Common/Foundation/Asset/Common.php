<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\x6f\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\155\x69\147\162\x61\x74\145"; }
