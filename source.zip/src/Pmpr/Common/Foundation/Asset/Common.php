<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a408a2b74             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\165\x65\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\x6f\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\x67\162\x61\164\145"; }
