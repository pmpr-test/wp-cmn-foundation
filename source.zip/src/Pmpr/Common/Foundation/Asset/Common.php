<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2e8864db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\x71\165\145\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\x6f\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\x67\x72\x61\x74\145"; }
