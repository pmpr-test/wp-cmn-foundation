<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132d18d1e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\x71\x75\145\x72\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\x6f\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\151\x67\x72\x61\164\x65"; }
