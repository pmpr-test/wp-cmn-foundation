<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e295acabc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\157\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\x69\147\x72\141\x74\145"; }
