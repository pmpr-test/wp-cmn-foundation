<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\x6d\151\x67\x72\141\164\x65"; }
