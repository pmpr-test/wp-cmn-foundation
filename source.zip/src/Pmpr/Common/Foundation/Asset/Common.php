<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e176fddf2d5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\x75\145\x72\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\151\x67\x72\141\164\x65"; }
