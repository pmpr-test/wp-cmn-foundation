<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19cd8e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\x6f\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\147\x72\x61\164\x65"; }
