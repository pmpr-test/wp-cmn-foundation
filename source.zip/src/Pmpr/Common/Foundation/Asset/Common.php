<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192c055a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\165\x65\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\157\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\x69\x67\x72\x61\x74\145"; }
