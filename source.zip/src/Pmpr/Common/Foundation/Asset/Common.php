<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a6c2def5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\165\x65\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\x6f\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\x67\162\141\164\145"; }
