<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfc3785             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\x65\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\x6f\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\x6d\x69\x67\x72\141\164\x65"; }
