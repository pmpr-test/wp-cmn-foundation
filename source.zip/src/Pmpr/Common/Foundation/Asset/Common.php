<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\x71\165\145\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\x6f\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\147\x72\141\164\145"; }
