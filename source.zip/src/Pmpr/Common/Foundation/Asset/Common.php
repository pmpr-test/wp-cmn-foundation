<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e17b763d23d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\165\x65\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\x69\147\162\141\x74\145"; }
