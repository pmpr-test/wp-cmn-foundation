<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\x71\x75\145\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\x69\x67\x72\x61\164\145"; }
