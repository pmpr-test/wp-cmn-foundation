<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\x75\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\151\147\x72\x61\x74\145"; }
