<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\165\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\x6f\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\151\x67\x72\141\164\145"; }
