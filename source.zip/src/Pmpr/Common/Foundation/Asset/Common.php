<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76ba63557             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\x75\x65\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\x6f\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\147\x72\141\164\x65"; }
