<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             684453ff396ae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Mediator\REST; use Pmpr\Common\Foundation\REST\RESTRegister; class REST extends RESTRegister { public function gigwcakmiyayoigw() { $this->ogyceaekywowkqsc(Controller::symcgieuakksimmu()); } }
