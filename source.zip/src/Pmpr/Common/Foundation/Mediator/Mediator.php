<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e17b763d23d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Mediator; use Pmpr\Common\Foundation\Mediator\REST\REST; class Mediator extends Common { public function mameiwsayuyquoeq() { REST::symcgieuakksimmu(); } }
