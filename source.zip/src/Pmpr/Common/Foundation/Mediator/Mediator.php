<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Mediator; use Pmpr\Common\Foundation\Mediator\REST\REST; class Mediator extends Common { public function mameiwsayuyquoeq() { REST::symcgieuakksimmu(); } }
