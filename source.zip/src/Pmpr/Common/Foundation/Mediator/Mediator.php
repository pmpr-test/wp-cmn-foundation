<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a4e17b10cc7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Mediator; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Mediator\REST\REST; class Mediator extends Container { public function mameiwsayuyquoeq() { REST::symcgieuakksimmu(); } }
