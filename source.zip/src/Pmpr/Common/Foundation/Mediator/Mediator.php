<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Mediator; use Pmpr\Common\Foundation\Mediator\REST\REST; class Mediator extends Common { public function mameiwsayuyquoeq() { REST::symcgieuakksimmu(); } }
