<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a0a0f99ffc0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\REST; class REST extends RESTRegister { public function gigwcakmiyayoigw() { $this->ogyceaekywowkqsc(Controller::symcgieuakksimmu()); } }
