<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d83a968b15             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\137\161\x75\145\x75\x65\137\143\154\145\x61\x6e\x75\160\x5f\x6f\x6c\x64\137\x69\164\x65\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\156\x64\141\164\x69\x6f\156\137\143\x6c\145\x61\156\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\156\x5f\151\x6e\151\164", [$this, "\x79\x65\171\x69\147\x75\171\x65\x67\155\155\x79\165\163\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\163\145\x6d\153\x69\153\153\x69\141\141\x71\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\x6e\x69\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
