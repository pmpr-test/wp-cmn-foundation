<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676d4ae089ce3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\137\161\x75\145\x75\145\x5f\x63\154\x65\x61\156\x75\x70\137\157\x6c\144\x5f\x69\164\x65\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\156\x64\x61\x74\x69\x6f\x6e\137\x63\x6c\x65\x61\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\151\x6e\x5f\151\156\151\x74", [$this, "\171\x65\x79\151\x67\x75\x79\145\x67\155\x6d\x79\x75\163\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\x65\155\153\151\x6b\x6b\x69\x61\x61\161\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\156\151\147\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
