<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\x5f\x71\165\145\x75\145\x5f\143\x6c\x65\x61\x6e\165\x70\x5f\x6f\154\x64\137\151\164\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\x75\156\144\141\164\151\x6f\x6e\x5f\x63\154\x65\x61\156\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\137\151\x6e\x69\164", [$this, "\x79\145\x79\151\147\x75\x79\145\x67\155\x6d\x79\165\x73\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\x73\145\x6d\153\151\x6b\153\x69\x61\141\161\145\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\156\151\x67\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
