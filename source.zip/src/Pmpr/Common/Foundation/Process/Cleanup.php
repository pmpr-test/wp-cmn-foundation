<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da3806785e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\x71\165\145\x75\x65\137\143\154\x65\x61\x6e\165\x70\x5f\157\154\x64\137\x69\x74\145\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\165\x6e\x64\x61\x74\151\157\x6e\137\143\154\145\141\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\151\156\x5f\151\x6e\x69\164", [$this, "\171\145\x79\151\147\x75\171\145\x67\155\x6d\x79\165\163\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\145\155\153\151\153\x6b\151\141\x61\161\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\156\151\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
