<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\137\x71\x75\x65\165\145\x5f\x63\x6c\x65\x61\156\x75\x70\137\x6f\154\144\x5f\x69\164\x65\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\144\141\164\151\157\x6e\x5f\143\154\145\x61\156\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\137\151\156\151\164", [$this, "\x79\x65\x79\151\x67\165\x79\145\x67\x6d\x6d\x79\165\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\x65\155\153\x69\153\x6b\x69\141\141\x71\x65\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\x6e\151\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
