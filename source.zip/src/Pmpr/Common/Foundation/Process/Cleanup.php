<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\161\x75\145\x75\x65\137\x63\154\145\x61\x6e\165\160\x5f\157\x6c\144\137\151\x74\145\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\156\x64\141\x74\151\x6f\x6e\137\143\154\145\x61\x6e\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\137\151\x6e\x69\x74", [$this, "\x79\x65\171\151\x67\165\171\x65\x67\x6d\x6d\x79\165\x73\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\145\155\153\x69\153\x6b\x69\141\x61\161\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\156\151\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
