<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670598d3a6ee7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\x5f\161\x75\145\x75\x65\137\x63\154\x65\141\156\x75\160\x5f\157\154\x64\x5f\x69\x74\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\165\156\144\x61\164\151\x6f\156\x5f\x63\154\x65\141\x6e\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\x6e\137\151\x6e\x69\x74", [$this, "\171\145\171\151\147\x75\171\145\x67\155\155\x79\x75\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\145\x6d\x6b\x69\153\x6b\x69\x61\x61\x71\145\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\156\x69\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
