<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec0bde9d3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\x71\165\x65\x75\145\x5f\143\154\x65\x61\156\165\x70\137\x6f\x6c\144\x5f\x69\164\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\165\x6e\x64\x61\x74\x69\x6f\156\x5f\143\x6c\x65\x61\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\156\x5f\151\x6e\151\164", [$this, "\171\x65\x79\x69\147\x75\171\x65\x67\x6d\x6d\x79\165\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\163\145\x6d\x6b\151\153\x6b\151\x61\141\161\145\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\156\x69\147\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
