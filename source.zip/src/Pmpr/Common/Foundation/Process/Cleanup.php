<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f9903c56c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\161\x75\x65\x75\145\137\x63\154\x65\x61\x6e\165\160\137\x6f\154\144\x5f\151\x74\x65\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\x75\156\144\x61\164\x69\x6f\156\x5f\143\x6c\145\x61\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\156\137\151\156\151\164", [$this, "\x79\x65\x79\x69\147\x75\x79\x65\x67\155\x6d\x79\x75\x73\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\x65\x6d\153\151\153\153\x69\141\141\161\145\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\x6e\x69\147\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
