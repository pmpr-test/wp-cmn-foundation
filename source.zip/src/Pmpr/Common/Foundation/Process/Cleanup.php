<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b088f1290             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\161\x75\145\x75\145\137\x63\154\x65\141\156\165\x70\137\x6f\154\144\137\151\164\145\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\156\144\141\x74\151\157\156\137\143\154\145\x61\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\x6e\137\x69\156\151\164", [$this, "\171\145\171\x69\147\165\171\x65\x67\x6d\x6d\171\x75\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\x65\x6d\x6b\x69\x6b\153\x69\141\141\161\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\156\151\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
