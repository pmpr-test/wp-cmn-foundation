<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\x5f\161\x75\x65\x75\145\137\143\154\145\x61\156\x75\160\x5f\x6f\x6c\x64\137\151\x74\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\x6e\144\x61\x74\151\x6f\x6e\137\x63\154\x65\141\156\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\x6e\137\151\156\x69\x74", [$this, "\x79\x65\171\151\147\165\171\145\147\x6d\x6d\171\165\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\145\x6d\x6b\x69\x6b\153\x69\x61\141\x71\x65\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\151\x67\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
