<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\161\165\x65\x75\145\x5f\143\x6c\145\x61\156\165\160\137\x6f\154\x64\137\x69\x74\145\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\x75\x6e\x64\141\164\151\x6f\156\137\x63\x6c\x65\141\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\156\137\151\x6e\x69\x74", [$this, "\171\x65\171\151\147\165\x79\x65\147\x6d\155\x79\x75\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\x65\155\x6b\151\153\x6b\x69\x61\141\x71\x65\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
