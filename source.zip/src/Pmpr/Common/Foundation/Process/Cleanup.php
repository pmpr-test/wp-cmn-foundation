<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19cd8e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\x5f\x71\165\145\165\x65\137\143\x6c\145\141\x6e\165\x70\137\157\x6c\144\x5f\x69\164\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\x6e\x64\x61\164\x69\x6f\156\137\143\154\x65\x61\156\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\151\156\137\x69\x6e\x69\x74", [$this, "\x79\145\x79\x69\147\165\171\x65\147\155\155\171\165\163\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\x65\x6d\x6b\151\x6b\x6b\x69\x61\141\x71\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\156\151\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
