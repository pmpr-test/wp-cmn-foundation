<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c9bc679             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\x71\x75\145\x75\145\x5f\143\x6c\145\x61\x6e\165\160\137\x6f\154\x64\137\151\164\x65\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\165\x6e\144\x61\164\151\157\x6e\137\x63\x6c\145\x61\156\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\x69\x6e\x5f\x69\x6e\x69\164", [$this, "\x79\x65\171\151\x67\165\x79\x65\147\x6d\x6d\171\165\x73\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\x73\145\x6d\x6b\151\x6b\x6b\x69\141\141\x71\x65\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\x67\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
