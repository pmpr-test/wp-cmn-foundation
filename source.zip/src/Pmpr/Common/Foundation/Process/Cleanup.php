<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16ccfaa782             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\161\165\145\x75\145\137\143\154\145\x61\x6e\x75\160\137\x6f\154\x64\137\x69\164\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\x6e\x64\141\164\151\x6f\x6e\x5f\143\154\145\141\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\x5f\x69\x6e\x69\x74", [$this, "\171\x65\171\x69\147\165\x79\145\147\155\x6d\171\165\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\163\145\155\x6b\x69\x6b\153\x69\141\141\x71\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\x64\x6e\x69\147\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
