<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffe229367             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\x5f\x71\x75\x65\165\145\137\143\x6c\x65\141\x6e\165\x70\137\157\154\x64\137\x69\x74\145\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\x75\156\144\141\x74\151\157\x6e\137\x63\x6c\x65\141\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\137\151\x6e\x69\x74", [$this, "\171\145\171\151\147\165\171\x65\x67\155\x6d\171\165\163\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\x65\155\x6b\151\153\x6b\151\141\x61\161\145\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\x6e\151\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
