<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d16a012f73             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\x5f\x71\x75\145\165\145\x5f\143\x6c\x65\141\x6e\165\160\137\x6f\x6c\x64\x5f\x69\x74\x65\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\165\156\144\141\x74\151\157\156\x5f\x63\x6c\x65\x61\x6e\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\x69\156\x5f\x69\156\x69\164", [$this, "\x79\x65\171\151\x67\x75\171\x65\x67\155\x6d\171\x75\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\x65\155\x6b\151\153\153\151\141\x61\161\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
