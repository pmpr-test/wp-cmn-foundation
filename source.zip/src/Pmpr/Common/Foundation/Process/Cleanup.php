<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9fd229d29             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\137\161\x75\x65\x75\x65\137\143\x6c\x65\x61\156\x75\x70\x5f\x6f\x6c\144\137\151\164\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\x6e\x64\141\x74\151\157\156\137\x63\x6c\x65\141\156\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\x69\156\137\151\x6e\151\164", [$this, "\171\145\x79\151\147\165\x79\145\x67\155\155\171\x75\x73\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\163\145\x6d\x6b\x69\153\x6b\151\x61\x61\161\145\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\x6e\x69\147\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
