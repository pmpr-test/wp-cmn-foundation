<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6ea7f40             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\x71\165\x65\x75\145\x5f\143\x6c\x65\141\x6e\165\160\137\x6f\x6c\144\137\x69\164\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\156\144\141\164\x69\157\156\137\x63\x6c\145\x61\x6e\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\x5f\x69\156\x69\164", [$this, "\171\145\171\x69\x67\x75\171\145\147\155\155\171\x75\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\163\145\x6d\153\x69\153\153\x69\141\x61\x71\145\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\x6e\x69\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
