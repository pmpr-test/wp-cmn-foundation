<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720bb1389a49             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\137\x71\165\145\x75\145\137\143\154\145\141\x6e\165\160\x5f\x6f\x6c\144\x5f\x69\164\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\165\x6e\x64\141\164\x69\x6f\x6e\x5f\x63\154\145\x61\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\151\156\x5f\151\156\151\164", [$this, "\171\x65\x79\x69\147\165\171\145\147\x6d\155\171\165\163\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\x73\145\x6d\153\151\x6b\153\x69\x61\141\x71\x65\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\x64\156\x69\147\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
