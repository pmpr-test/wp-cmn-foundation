<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d172c3f1f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\161\x75\x65\x75\145\137\x63\154\x65\x61\x6e\x75\160\x5f\157\x6c\x64\137\151\164\145\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\156\x64\141\x74\151\x6f\156\x5f\143\x6c\145\x61\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\x69\x6e\137\x69\156\151\164", [$this, "\171\145\x79\x69\147\165\171\145\x67\x6d\155\171\x75\163\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\163\145\155\153\x69\x6b\153\x69\141\x61\161\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\156\x69\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
