<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d47a28db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\161\x75\x65\165\x65\137\143\x6c\x65\141\156\x75\160\137\x6f\x6c\x64\x5f\151\x74\x65\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\x75\156\144\141\164\151\157\156\137\143\154\145\x61\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\x69\x6e\137\x69\x6e\x69\x74", [$this, "\x79\x65\x79\151\x67\165\x79\145\147\x6d\155\x79\165\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\x65\x6d\153\x69\153\153\x69\141\141\x71\x65\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\x6e\151\x67\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
