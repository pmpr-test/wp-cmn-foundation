<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d585ed47eb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\x71\x75\145\165\x65\137\143\x6c\x65\x61\x6e\165\x70\x5f\x6f\154\144\137\151\164\145\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\x64\x61\x74\151\157\x6e\137\x63\x6c\145\141\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\156\137\151\x6e\151\x74", [$this, "\171\145\x79\151\147\x75\x79\145\x67\x6d\x6d\171\165\x73\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\145\155\153\x69\153\153\151\141\x61\x71\145\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\x6e\x69\x67\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
