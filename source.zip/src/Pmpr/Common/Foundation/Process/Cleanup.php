<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835e37313             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\161\x75\x65\x75\145\x5f\x63\154\145\x61\156\x75\160\x5f\157\x6c\x64\137\151\164\145\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\x64\141\164\x69\x6f\x6e\137\x63\x6c\145\x61\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\x6e\137\x69\156\x69\x74", [$this, "\171\x65\171\151\x67\x75\171\x65\x67\x6d\x6d\171\x75\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\145\155\153\x69\x6b\153\x69\x61\x61\161\145\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\x64\156\151\x67\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
