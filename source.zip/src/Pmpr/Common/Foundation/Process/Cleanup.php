<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522a8f9030b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\161\165\x65\165\145\x5f\x63\x6c\x65\x61\156\165\x70\x5f\x6f\x6c\x64\137\x69\x74\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\165\x6e\144\x61\164\151\x6f\156\x5f\x63\154\145\x61\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\151\x6e\137\x69\156\x69\164", [$this, "\x79\145\171\151\x67\165\x79\145\147\155\155\x79\165\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\x6d\153\151\153\x6b\x69\141\141\x71\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\147\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
