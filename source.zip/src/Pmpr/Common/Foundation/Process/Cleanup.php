<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\x71\x75\145\x75\x65\137\x63\154\145\141\x6e\165\160\x5f\157\154\x64\137\x69\164\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\x64\141\x74\x69\x6f\156\137\143\x6c\x65\x61\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\x6e\137\151\156\151\x74", [$this, "\x79\145\171\x69\x67\x75\171\x65\x67\155\x6d\x79\165\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\x65\155\x6b\151\153\x6b\x69\141\141\161\x65\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\x6e\151\147\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
