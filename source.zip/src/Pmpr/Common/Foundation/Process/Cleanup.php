<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e3ee38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\x5f\x71\x75\x65\x75\145\137\143\x6c\145\x61\x6e\165\160\137\157\154\x64\137\151\x74\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\165\156\x64\141\164\x69\157\x6e\x5f\x63\x6c\x65\141\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\x6e\x5f\x69\x6e\151\x74", [$this, "\171\145\x79\x69\147\x75\171\145\147\155\x6d\171\x75\x73\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\163\x65\x6d\153\151\x6b\153\x69\x61\x61\x71\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\156\151\147\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
