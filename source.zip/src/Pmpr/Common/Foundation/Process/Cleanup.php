<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fd4e8b59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\x71\x75\x65\x75\x65\x5f\143\154\145\141\x6e\165\160\x5f\157\154\x64\x5f\x69\x74\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\165\x6e\x64\141\164\x69\x6f\156\137\x63\154\145\141\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\x5f\x69\x6e\x69\x74", [$this, "\171\145\x79\151\147\165\x79\145\147\155\155\x79\x75\x73\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\x73\x65\x6d\x6b\151\x6b\153\151\x61\x61\x71\145\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\x6e\x69\147\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
