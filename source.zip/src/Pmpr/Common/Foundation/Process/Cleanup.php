<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e3816e1675             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\x71\165\x65\x75\x65\x5f\x63\154\145\x61\156\x75\x70\137\x6f\x6c\x64\137\151\x74\x65\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\165\x6e\144\x61\164\151\x6f\x6e\137\x63\x6c\x65\141\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\156\137\x69\156\x69\164", [$this, "\171\x65\x79\151\x67\x75\x79\x65\147\x6d\155\x79\x75\163\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\155\x6b\151\x6b\x6b\151\141\x61\x71\145\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\x69\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
