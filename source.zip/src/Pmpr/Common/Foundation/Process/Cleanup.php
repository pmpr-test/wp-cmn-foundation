<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da3200825a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\x71\165\145\165\x65\137\x63\x6c\x65\x61\156\165\x70\137\157\154\x64\x5f\151\x74\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\165\x6e\x64\141\164\151\157\156\x5f\x63\154\x65\141\x6e\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\156\x5f\151\x6e\151\x74", [$this, "\x79\x65\171\x69\147\165\x79\145\147\x6d\155\171\x75\163\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\163\145\x6d\x6b\x69\153\x6b\x69\x61\141\161\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\156\151\x67\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
