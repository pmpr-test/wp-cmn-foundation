<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b58eab716             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\161\x75\x65\165\x65\137\x63\x6c\145\x61\x6e\165\x70\x5f\x6f\154\x64\137\x69\164\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\165\156\x64\141\x74\151\157\156\137\143\x6c\145\x61\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\156\137\x69\156\151\164", [$this, "\171\x65\x79\x69\x67\165\x79\145\147\x6d\x6d\171\x75\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\x73\x65\x6d\153\x69\153\x6b\151\141\x61\x71\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\x6e\x69\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
