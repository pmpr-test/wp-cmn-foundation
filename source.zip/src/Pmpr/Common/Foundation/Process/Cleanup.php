<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0611cd07             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\x71\165\x65\165\x65\x5f\x63\x6c\145\141\156\x75\160\137\x6f\x6c\144\137\x69\164\145\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\x64\x61\164\151\157\156\x5f\143\154\x65\141\x6e\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\151\156\137\151\x6e\x69\164", [$this, "\x79\x65\171\x69\x67\x75\171\145\147\155\x6d\x79\165\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\x65\155\153\151\153\x6b\151\141\x61\161\x65\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\151\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
