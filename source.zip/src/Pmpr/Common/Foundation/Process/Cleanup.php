<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0000cbc1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\x5f\161\165\145\165\145\137\x63\154\145\141\156\x75\160\x5f\157\x6c\x64\137\x69\164\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\156\144\x61\x74\x69\157\x6e\x5f\143\154\x65\141\x6e\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\156\x5f\x69\156\151\164", [$this, "\x79\x65\x79\x69\147\x75\x79\145\x67\x6d\155\x79\x75\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\163\x65\155\153\x69\x6b\153\151\x61\x61\161\x65\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\156\x69\x67\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
