<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c8774d14             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\161\x75\145\x75\145\137\143\x6c\x65\141\156\165\160\137\157\x6c\144\137\x69\164\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\x6e\144\141\164\151\157\x6e\137\143\154\145\141\x6e\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\156\x5f\151\x6e\x69\164", [$this, "\171\x65\171\151\x67\x75\x79\x65\147\155\x6d\x79\165\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\x73\x65\155\x6b\x69\x6b\x6b\151\141\141\161\x65\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\x6e\x69\147\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
