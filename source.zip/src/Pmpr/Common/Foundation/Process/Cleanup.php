<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\137\x71\x75\x65\165\x65\x5f\143\154\x65\141\156\x75\x70\x5f\157\154\x64\x5f\x69\x74\x65\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\156\144\141\x74\151\x6f\x6e\137\143\x6c\145\x61\156\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\137\x69\156\151\x74", [$this, "\171\145\x79\151\147\x75\171\145\x67\155\x6d\171\165\163\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\145\155\x6b\x69\x6b\x6b\x69\141\x61\161\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
