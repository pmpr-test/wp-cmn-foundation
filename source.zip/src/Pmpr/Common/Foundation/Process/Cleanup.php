<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ec0c0505             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\137\161\x75\145\165\145\x5f\143\x6c\x65\x61\x6e\x75\160\x5f\157\x6c\x64\x5f\151\x74\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\x6e\x64\141\164\x69\157\156\137\x63\x6c\145\141\x6e\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\156\137\x69\156\151\x74", [$this, "\171\x65\171\x69\147\165\171\145\147\x6d\x6d\x79\x75\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\145\155\153\151\x6b\153\151\x61\x61\161\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
