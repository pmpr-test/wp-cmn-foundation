<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\x61\162\x63\x68\x61\x72"; parent::__construct("\x73\164\x72\151\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
