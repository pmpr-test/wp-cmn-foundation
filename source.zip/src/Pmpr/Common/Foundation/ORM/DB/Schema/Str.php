<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ec0c0505             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\166\x61\x72\x63\x68\x61\162"; parent::__construct("\163\164\x72\x69\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
