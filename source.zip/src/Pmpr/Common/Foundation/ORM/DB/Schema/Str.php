<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\x61\x72\143\150\141\162"; parent::__construct("\163\164\x72\x69\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
