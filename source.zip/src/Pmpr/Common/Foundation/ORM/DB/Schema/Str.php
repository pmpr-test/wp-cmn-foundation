<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\166\141\162\x63\x68\141\162"; parent::__construct("\163\164\162\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
