<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77d1b4081             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\x61\x72\x63\x68\x61\x72"; parent::__construct("\163\164\162\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
