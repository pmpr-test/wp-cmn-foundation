<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2ce2062a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\x67\151\156\164"; parent::__construct("\x62\x69\x67\x49\x6e\164\145\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
