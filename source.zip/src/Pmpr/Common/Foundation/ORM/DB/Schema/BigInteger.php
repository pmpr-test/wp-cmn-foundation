<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\142\x69\x67\x69\x6e\164"; parent::__construct("\142\151\x67\x49\156\x74\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
