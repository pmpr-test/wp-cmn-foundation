<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\x67\151\x6e\x74"; parent::__construct("\142\x69\147\x49\156\164\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
