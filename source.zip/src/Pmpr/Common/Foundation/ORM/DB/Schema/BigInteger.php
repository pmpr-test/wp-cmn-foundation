<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\x67\151\156\164"; parent::__construct("\142\151\147\x49\156\x74\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
