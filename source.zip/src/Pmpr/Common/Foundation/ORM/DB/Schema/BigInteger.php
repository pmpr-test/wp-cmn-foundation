<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf5417a8d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\x67\x69\x6e\x74"; parent::__construct("\x62\x69\x67\x49\x6e\164\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
