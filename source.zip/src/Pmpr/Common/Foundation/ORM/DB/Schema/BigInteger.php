<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\147\x69\x6e\164"; parent::__construct("\142\x69\x67\111\156\x74\x65\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
