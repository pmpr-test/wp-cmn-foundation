<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\142\x69\x67\x69\156\x74"; parent::__construct("\x62\x69\x67\111\156\x74\x65\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
