<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\151\147\x69\156\164"; parent::__construct("\x62\x69\x67\x49\x6e\164\x65\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
