<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c61c8485             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\163\x6d\141\154\x6c\x69\156\164"; parent::__construct("\x73\x6d\141\x6c\154\111\156\164\x65\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
