<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132d18d1e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\155\141\x6c\x6c\151\156\164"; parent::__construct("\163\x6d\141\x6c\x6c\x49\x6e\164\145\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
