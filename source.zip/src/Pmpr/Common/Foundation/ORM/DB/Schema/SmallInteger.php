<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\155\141\x6c\x6c\151\156\x74"; parent::__construct("\x73\155\141\154\154\x49\x6e\164\x65\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
