<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec064496439             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\163\x6d\141\x6c\x6c\151\x6e\164"; parent::__construct("\163\155\141\154\154\111\x6e\164\x65\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
