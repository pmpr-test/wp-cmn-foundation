<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf5417a8d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\163\155\141\x6c\x6c\x69\156\164"; parent::__construct("\x73\155\141\x6c\154\x49\x6e\164\x65\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
