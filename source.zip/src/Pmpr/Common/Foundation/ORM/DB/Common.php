<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19cd8e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB; use Pmpr\Common\Foundation\ORM\Common as BaseClass; class Common extends BaseClass { }
