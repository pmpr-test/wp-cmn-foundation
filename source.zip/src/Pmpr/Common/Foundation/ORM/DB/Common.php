<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB; use Pmpr\Common\Foundation\ORM\Common as BaseClass; class Common extends BaseClass { }
