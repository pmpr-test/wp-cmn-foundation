<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a408a2b74             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB; use Pmpr\Common\Foundation\ORM\Common as BaseClass; class Common extends BaseClass { }
