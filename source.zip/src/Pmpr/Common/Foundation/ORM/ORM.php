<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4d0827938             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; use Pmpr\Common\Foundation\Container\Container; class ORM extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x64\144\x5f\x6d\145\x6e\165\x5f\143\x6c\x61\x73\163\145\x73", [$this, "\161\161\x67\x69\x67\x69\x75\165\143\157\155\163\x77\143\x79\147"]); } public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2])) { $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\137\142\x75\x62\142\154\x65\x5f\x6e\x6f\164\x69\x66\151\143\141\164\x69\x6f\156\x73", 0); if ($gaeqamemwmwsyukm > 0) { $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); } } } return $ewuukoycimkekouc; } }
