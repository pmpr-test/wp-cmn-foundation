<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d16a012f73             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; use Pmpr\Common\Foundation\Container\Container; class ORM extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\144\144\137\155\145\156\x75\137\143\154\141\x73\163\x65\163", [$this, "\161\161\147\x69\147\x69\x75\x75\143\157\x6d\163\x77\143\171\147"]); } public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2])) { $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\x5f\142\165\142\x62\x6c\x65\137\156\157\164\151\146\151\143\141\164\x69\x6f\x6e\x73", 0); if ($gaeqamemwmwsyukm > 0) { $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); } } } return $ewuukoycimkekouc; } }
