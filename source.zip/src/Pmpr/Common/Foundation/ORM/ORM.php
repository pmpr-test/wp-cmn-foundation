<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051cac7bda7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; class ORM extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\144\144\x5f\155\145\156\165\137\x63\x6c\x61\163\163\145\x73", [$this, "\x71\x71\147\x69\x67\151\165\165\x63\x6f\155\163\167\x63\171\147"]); } public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { goto komymyuaekmkkiko; } Ajax::symcgieuakksimmu(); komymyuaekmkkiko: } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (!(isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2]))) { goto imyemkiyouuuequq; } $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\137\x62\165\142\x62\154\145\137\156\x6f\164\x69\x66\x69\x63\x61\164\x69\157\156\163", 0); if (!($gaeqamemwmwsyukm > 0)) { goto wiikygmkoykkkgyw; } $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); wiikygmkoykkkgyw: imyemkiyouuuequq: qccawiseummsemsk: } kkowueuygsqqgogc: return $ewuukoycimkekouc; } }
