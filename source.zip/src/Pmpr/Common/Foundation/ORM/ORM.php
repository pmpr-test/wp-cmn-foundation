<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517460aacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; class ORM extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\144\x64\x5f\x6d\x65\156\x75\137\x63\x6c\x61\163\163\145\163", [$this, "\x71\x71\x67\151\147\151\x75\x75\143\157\x6d\163\x77\143\x79\147"]); } public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { goto iikiiioqiyegyaak; } Ajax::symcgieuakksimmu(); iikiiioqiyegyaak: } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (!(isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2]))) { goto qmkaeeomgkwggoyo; } $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\x5f\x62\x75\x62\142\154\x65\x5f\x6e\157\164\151\146\x69\143\x61\x74\x69\157\x6e\x73", 0); if (!($gaeqamemwmwsyukm > 0)) { goto gcckqucukawcasgk; } $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); gcckqucukawcasgk: qmkaeeomgkwggoyo: cuumeogeomowqisc: } uiosisocuwokwkie: return $ewuukoycimkekouc; } }
