<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d585ed47eb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; use Pmpr\Common\Foundation\Container\Container; class ORM extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x64\x64\137\x6d\145\156\x75\x5f\x63\154\141\163\x73\x65\163", [$this, "\x71\x71\147\151\147\151\x75\165\x63\157\155\163\167\143\x79\147"]); } public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2])) { $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\x5f\x62\x75\142\x62\154\145\137\156\x6f\x74\x69\146\x69\x63\141\164\151\x6f\x6e\x73", 0); if ($gaeqamemwmwsyukm > 0) { $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); } } } return $ewuukoycimkekouc; } }
