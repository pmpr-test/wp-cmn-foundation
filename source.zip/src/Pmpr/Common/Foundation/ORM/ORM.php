<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfc3785             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; class ORM extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x64\x64\137\155\145\156\165\x5f\143\x6c\141\x73\163\x65\163", [$this, "\161\x71\147\x69\147\x69\165\x75\143\x6f\x6d\x73\x77\143\171\x67"]); } public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { goto iikiiioqiyegyaak; } Ajax::symcgieuakksimmu(); iikiiioqiyegyaak: } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (!(isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2]))) { goto qmkaeeomgkwggoyo; } $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\137\142\x75\142\x62\x6c\145\137\156\x6f\164\x69\x66\151\143\141\164\x69\157\156\x73", 0); if (!($gaeqamemwmwsyukm > 0)) { goto gcckqucukawcasgk; } $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); gcckqucukawcasgk: qmkaeeomgkwggoyo: cuumeogeomowqisc: } uiosisocuwokwkie: return $ewuukoycimkekouc; } }
