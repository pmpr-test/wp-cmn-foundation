<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b645383f9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; use Pmpr\Common\Foundation\Container\Container; class ORM extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x64\144\137\x6d\145\x6e\165\x5f\143\x6c\x61\163\163\x65\163", [$this, "\x71\161\x67\x69\147\151\x75\165\x63\x6f\x6d\163\x77\x63\x79\x67"]); } public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2])) { $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\x5f\x62\165\x62\x62\154\145\137\156\x6f\164\x69\146\151\x63\x61\164\x69\157\x6e\163", 0); if ($gaeqamemwmwsyukm > 0) { $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); } } } return $ewuukoycimkekouc; } }
