<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68821138ddb03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Foundation\ORM\Traits\ModelTrait; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Common extends Model { use ModelTrait; public function __construct($ykyqqwuyuqeekuqw) { $this->asumqyigwsqmyeoc($ykyqqwuyuqeekuqw); parent::__construct(); } public function register() { $this->okgmqaeuaeymaocm($this->mgogaykgkoogasim()->ogqgmqymcwsqikme()); } public function meqwysqkeuyqiioi() : string { return $this->mgogaykgkoogasim()->aakmagwggmkoiiyu() . Constants::mswocgcucqoaesaa; } }
