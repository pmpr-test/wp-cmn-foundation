<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68821f224aec3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Statement; class Having extends Statement { public function __construct(string $qgoqiacsiccwoawi, $eqgoocgaqwqcimie = '') { $this->iygyugseyaqwywyg($eqgoocgaqwqcimie); parent::__construct($qgoqiacsiccwoawi); } protected function run($siykeiywomwwuoiw) { $siykeiywomwwuoiw->having($this->myywwqkyiwawwquy(), $this->auiqywousmcqsskq(), $this->qooeaookuemoqecm()); return $siykeiywomwwuoiw; } }
