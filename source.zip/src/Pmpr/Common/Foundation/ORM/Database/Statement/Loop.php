<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68b4370b067f9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Statement; use Illuminate\Database\Query\Builder; class Loop extends Statement { protected function run($siykeiywomwwuoiw) { return $this->igyyscwegckkkkya($siykeiywomwwuoiw); } }
