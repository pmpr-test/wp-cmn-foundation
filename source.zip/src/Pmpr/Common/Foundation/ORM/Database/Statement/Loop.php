<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9eb1f4f62f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Statement; use Illuminate\Database\Query\Builder; class Loop extends Statement { protected function run($siykeiywomwwuoiw) { return $this->igyyscwegckkkkya($siykeiywomwwuoiw); } }
