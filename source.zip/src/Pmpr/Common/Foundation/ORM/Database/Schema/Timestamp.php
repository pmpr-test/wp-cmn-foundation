<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fe543e50             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; use Pmpr\Common\Foundation\ORM\Model; class Timestamp extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct("\x74\x69\x6d\145\x73\164\x61\155\x70", $aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie) { if ($eqgoocgaqwqcimie) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->gagsyqagguwwauac()->ekasyoagocygouom($eqgoocgaqwqcimie, $this->caokeucsksukesyo()->eiwcuqigayigimak()->yoaaussmackoisuw(), $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->iyouigcsiacgwksc()); } else { $eqgoocgaqwqcimie = "\55"; } return $eqgoocgaqwqcimie; }); } }
