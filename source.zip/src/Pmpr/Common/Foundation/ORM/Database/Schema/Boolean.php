<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676d4ae089ce3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Boolean extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x74\151\156\171\x69\156\164"); parent::__construct("\142\157\x6f\154\145\x61\x6e", $aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie) { if ($this->caokeucsksukesyo()->gyecsegqciqykomu()->ascqkksqiiwaouic($eqgoocgaqwqcimie)) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::sucyqiucaqowyomk, ["\x63\154\141\x73\163" => "\151\143\x6f\156\55\163\x75\x63\x63\145\163\x73"]); } else { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::kcyyouekgyaqyqak, ["\x63\x6c\141\x73\163" => "\151\x63\x6f\156\x2d\144\141\156\x67\x65\x72"]); } return $eqgoocgaqwqcimie; }); $this->aguakyuusmksagai()->eyygsasuqmommkua(0); } }
