<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356231cfee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Boolean extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\164\x69\x6e\171\x69\156\x74"); parent::__construct("\x62\157\x6f\x6c\145\141\156", $aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie) { if ($this->caokeucsksukesyo()->gyecsegqciqykomu()->ascqkksqiiwaouic($eqgoocgaqwqcimie)) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::sucyqiucaqowyomk, ["\x63\154\141\x73\163" => "\x69\x63\157\x6e\55\163\x75\143\143\145\163\163"]); } else { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::kcyyouekgyaqyqak, ["\143\154\x61\163\x73" => "\151\143\157\156\55\144\x61\x6e\147\145\162"]); } return $eqgoocgaqwqcimie; }); $this->aguakyuusmksagai()->eyygsasuqmommkua(0); } }
