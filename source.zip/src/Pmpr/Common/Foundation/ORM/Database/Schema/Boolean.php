<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791545e8b23b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Boolean extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x74\151\156\x79\x69\x6e\x74"); parent::__construct("\x62\157\x6f\154\x65\141\156", $aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie) { if ($this->caokeucsksukesyo()->gyecsegqciqykomu()->ascqkksqiiwaouic($eqgoocgaqwqcimie)) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::sucyqiucaqowyomk, ["\143\154\141\x73\163" => "\x69\143\157\156\x2d\x73\165\143\x63\x65\163\x73"]); } else { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::kcyyouekgyaqyqak, ["\x63\x6c\141\x73\163" => "\x69\143\157\x6e\x2d\144\x61\x6e\147\x65\x72"]); } return $eqgoocgaqwqcimie; }); $this->aguakyuusmksagai()->eyygsasuqmommkua(0); } }
