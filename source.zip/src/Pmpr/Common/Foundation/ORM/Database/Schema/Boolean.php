<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720bb1389a49             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Boolean extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x74\x69\x6e\x79\x69\156\164"); parent::__construct("\142\157\x6f\x6c\145\141\x6e", $aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie) { if ($this->caokeucsksukesyo()->gyecsegqciqykomu()->ascqkksqiiwaouic($eqgoocgaqwqcimie)) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::sucyqiucaqowyomk, ["\x63\x6c\141\163\x73" => "\151\x63\x6f\156\55\163\165\x63\143\x65\163\x73"]); } else { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::kcyyouekgyaqyqak, ["\x63\x6c\141\x73\x73" => "\x69\x63\157\156\55\144\141\x6e\147\145\x72"]); } return $eqgoocgaqwqcimie; }); $this->aguakyuusmksagai()->eyygsasuqmommkua(0); } }
