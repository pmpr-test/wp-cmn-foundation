<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671439f5ea337             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class DateTime extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct("\144\141\x74\x65\164\x69\155\145", $aokagokqyuysuksm, $meqocwsecsywiiqs); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->iwwmociiuayuwssq([$eqwoegegiamegqsm, "\x77\x67\x69\145\x63\x71\x63\147\141\153\153\x61\165\171\167\165"]); } }
