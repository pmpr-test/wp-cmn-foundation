<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e3ee38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class DateTime extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct("\x64\141\x74\145\164\151\155\x65", $aokagokqyuysuksm, $meqocwsecsywiiqs); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->iwwmociiuayuwssq([$eqwoegegiamegqsm, "\167\x67\x69\x65\x63\161\143\x67\x61\153\153\141\165\x79\x77\165"]); } }
