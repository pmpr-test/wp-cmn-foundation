<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356231cfee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class DateTime extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct("\x64\x61\164\x65\x74\151\155\x65", $aokagokqyuysuksm, $meqocwsecsywiiqs); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->iwwmociiuayuwssq([$eqwoegegiamegqsm, "\167\147\x69\x65\143\x71\143\147\141\153\153\141\x75\171\167\x75"]); } }
