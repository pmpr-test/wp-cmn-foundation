<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbd402ffa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class DateTime extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct("\x64\x61\x74\x65\164\x69\155\x65", $aokagokqyuysuksm, $meqocwsecsywiiqs); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->iwwmociiuayuwssq([$eqwoegegiamegqsm, "\x77\147\x69\x65\143\161\143\147\x61\x6b\x6b\x61\165\x79\167\165"]); } }
