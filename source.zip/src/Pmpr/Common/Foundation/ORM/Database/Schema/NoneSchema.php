<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791545e8b23b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class NoneSchema extends Schema { public function __construct(string $aokagokqyuysuksm) { parent::__construct("\x6e\157\156\x65\163\x63\150\x65\155\x61", $aokagokqyuysuksm); } }
