<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676d4ae089ce3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class NoneSchema extends Schema { public function __construct(string $aokagokqyuysuksm) { parent::__construct("\x6e\x6f\x6e\x65\163\143\x68\x65\x6d\141", $aokagokqyuysuksm); } }
