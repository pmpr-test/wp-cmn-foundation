<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d30e2de1d6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class NoneSchema extends Schema { public function __construct(string $aokagokqyuysuksm) { parent::__construct("\x6e\157\x6e\x65\163\143\x68\x65\155\x61", $aokagokqyuysuksm); } }
