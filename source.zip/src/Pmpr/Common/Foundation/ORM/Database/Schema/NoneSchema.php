<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d41a8027             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class NoneSchema extends Schema { public function __construct(string $aokagokqyuysuksm) { parent::__construct('noneschema', $aokagokqyuysuksm); } }
