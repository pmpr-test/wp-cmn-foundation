<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c8774d14             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Foundation\Interfaces\Constants; class File extends Integer { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct($aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie, $mksyucucyswaukig, ?Model $meywaqqsugaoeyys) { if (is_numeric($eqgoocgaqwqcimie) && $meywaqqsugaoeyys && ($meywaqqsugaoeyys->qcaekwgmiswccowk(Constants::ieioeisgwcgysukw) || $meywaqqsugaoeyys->qcaekwgmiswccowk(Constants::weiosaewqequuyuq))) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->iqsmaqoiukeasukw()->qaeeusqkgwagwaqc($eqgoocgaqwqcimie, Constants::meugkwqwuyoyeeqs); } return $eqgoocgaqwqcimie; }); } }
