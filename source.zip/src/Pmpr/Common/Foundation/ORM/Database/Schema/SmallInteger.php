<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d30e2de1d6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\141\154\154\151\156\164"); parent::__construct("\163\x6d\x61\x6c\154\x49\156\x74\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
