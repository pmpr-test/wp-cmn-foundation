<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676d4ae089ce3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\x61\154\x6c\151\156\x74"); parent::__construct("\x73\155\141\154\x6c\x49\x6e\164\145\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
