<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfc3785             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\x61\154\154\151\x6e\164"); parent::__construct("\163\155\x61\x6c\x6c\x49\x6e\x74\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
