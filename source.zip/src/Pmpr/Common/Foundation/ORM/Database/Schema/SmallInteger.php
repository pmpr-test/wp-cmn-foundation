<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671439f5ea337             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\141\154\154\151\x6e\164"); parent::__construct("\x73\155\141\x6c\154\111\x6e\164\x65\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
