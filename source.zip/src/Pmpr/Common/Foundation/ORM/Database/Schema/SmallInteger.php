<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4e36cacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\x6d\x61\x6c\x6c\x69\156\164"); parent::__construct("\x73\x6d\141\x6c\154\x49\156\164\x65\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
