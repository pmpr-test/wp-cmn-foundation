<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbd402ffa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\x61\x6c\x6c\x69\156\164"); parent::__construct("\163\155\x61\154\154\111\156\x74\145\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
