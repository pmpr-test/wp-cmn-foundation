<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd9cf3e241             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\141\x6c\154\151\x6e\164"); parent::__construct("\x73\155\x61\154\154\111\x6e\164\145\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
