<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051cac7bda7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\141\154\154\x69\x6e\164"); parent::__construct("\x73\155\141\x6c\x6c\111\x6e\164\145\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
