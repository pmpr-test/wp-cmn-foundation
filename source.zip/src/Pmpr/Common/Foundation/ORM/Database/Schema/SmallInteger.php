<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d585ed47eb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\x6d\x61\x6c\154\x69\156\164"); parent::__construct("\163\x6d\x61\x6c\x6c\111\156\x74\145\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
