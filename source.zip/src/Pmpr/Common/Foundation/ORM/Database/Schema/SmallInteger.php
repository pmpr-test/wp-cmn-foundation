<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b088f1290             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\x61\x6c\x6c\151\156\164"); parent::__construct("\x73\155\x61\x6c\154\111\x6e\x74\x65\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
