<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beb88b904             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\x61\154\154\x69\x6e\x74"); parent::__construct("\x73\x6d\141\154\154\111\156\164\145\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
