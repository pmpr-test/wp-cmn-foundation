<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed815f260e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\141\154\x6c\x69\x6e\x74"); parent::__construct("\163\155\141\154\154\111\x6e\x74\145\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
