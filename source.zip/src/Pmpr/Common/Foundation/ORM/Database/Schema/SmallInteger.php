<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d3e38c782d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\x61\154\x6c\151\x6e\x74"); parent::__construct("\163\x6d\141\154\x6c\111\156\x74\x65\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
