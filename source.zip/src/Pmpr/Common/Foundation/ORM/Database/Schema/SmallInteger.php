<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791512bce1c4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\x6d\141\x6c\x6c\151\x6e\x74"); parent::__construct("\x73\155\141\154\154\111\x6e\164\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
