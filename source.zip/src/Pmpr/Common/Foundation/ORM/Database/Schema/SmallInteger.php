<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c8774d14             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\x61\x6c\x6c\151\x6e\164"); parent::__construct("\163\155\x61\154\x6c\111\156\164\145\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
