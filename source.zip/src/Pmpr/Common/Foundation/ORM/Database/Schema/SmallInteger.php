<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a8e52d988             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\141\x6c\154\151\156\x74"); parent::__construct("\x73\155\141\x6c\x6c\111\156\164\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
