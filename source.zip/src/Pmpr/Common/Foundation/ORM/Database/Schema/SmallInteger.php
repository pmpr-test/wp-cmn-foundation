<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9fd229d29             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\141\x6c\154\151\x6e\x74"); parent::__construct("\x73\155\141\154\154\111\156\164\145\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
