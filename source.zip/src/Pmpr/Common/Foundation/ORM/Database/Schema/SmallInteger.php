<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d54c9a6ea1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\x6d\141\154\154\x69\x6e\x74"); parent::__construct("\x73\155\x61\x6c\x6c\111\156\x74\x65\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
