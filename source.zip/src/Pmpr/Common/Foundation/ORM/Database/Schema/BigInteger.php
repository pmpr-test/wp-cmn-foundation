<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517460aacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\151\147\151\x6e\164"); parent::__construct("\142\x69\147\x49\x6e\164\x65\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
