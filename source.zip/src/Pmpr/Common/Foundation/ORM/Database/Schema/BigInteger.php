<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d172c3f1f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\x67\x69\156\x74"); parent::__construct("\142\x69\147\x49\156\x74\x65\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
