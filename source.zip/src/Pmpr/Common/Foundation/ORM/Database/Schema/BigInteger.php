<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e3816e1675             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\151\147\151\156\x74"); parent::__construct("\x62\151\147\x49\156\164\145\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
