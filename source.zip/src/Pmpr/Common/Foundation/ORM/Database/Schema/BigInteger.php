<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c8774d14             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\x67\151\x6e\x74"); parent::__construct("\x62\x69\147\x49\156\164\145\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
