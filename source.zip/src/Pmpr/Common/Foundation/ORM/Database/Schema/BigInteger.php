<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051cac7bda7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\151\147\x69\156\x74"); parent::__construct("\x62\x69\x67\x49\x6e\x74\x65\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
