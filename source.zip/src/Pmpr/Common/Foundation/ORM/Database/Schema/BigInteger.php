<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581610eed2f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\151\x67\151\156\164"); parent::__construct("\x62\151\147\111\156\x74\x65\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
