<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052a91f300e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\147\x69\x6e\x74"); parent::__construct("\x62\151\x67\111\x6e\x74\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
