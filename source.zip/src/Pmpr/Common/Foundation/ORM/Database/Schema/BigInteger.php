<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d3e38c782d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\x69\147\x69\x6e\x74"); parent::__construct("\142\151\x67\x49\156\164\x65\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
