<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdd41716df             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\147\151\x6e\164"); parent::__construct("\142\151\x67\111\x6e\x74\x65\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
