<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec0bde9d3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x76\x61\x72\143\x68\x61\x72"); parent::__construct("\x73\x74\x72\x69\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
