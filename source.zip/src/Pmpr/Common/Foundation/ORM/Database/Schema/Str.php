<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d3e38c782d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\x61\x72\143\150\141\x72"); parent::__construct("\163\x74\x72\151\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
