<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517460aacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x76\x61\162\143\150\141\x72"); parent::__construct("\x73\164\x72\151\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
