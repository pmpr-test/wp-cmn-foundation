<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             699992963e388             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym('varchar'); parent::__construct('string', $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
