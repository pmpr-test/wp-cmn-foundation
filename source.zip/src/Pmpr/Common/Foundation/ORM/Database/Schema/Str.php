<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8ad41a06             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\x61\162\x63\150\141\x72"); parent::__construct("\x73\164\162\151\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
