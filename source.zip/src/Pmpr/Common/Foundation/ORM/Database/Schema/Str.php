<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec7e2db2b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x76\x61\x72\x63\x68\x61\162"); parent::__construct("\x73\x74\162\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
