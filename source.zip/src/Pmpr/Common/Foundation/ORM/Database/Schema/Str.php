<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791524c10e10             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\x61\x72\143\x68\141\x72"); parent::__construct("\x73\164\x72\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
