<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6806c79d4c8c3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Traits; use Pmpr\Common\Foundation\ORM\Database\Entity; trait EntityTrait { protected Entity $entity; public function gssiscqyqsacmeca() : Entity { return $this->entity; } public function ugokaokywkkqisqe(Entity $oikmcqwkmsyiicqs) : self { $this->entity = $oikmcqwkmsyiicqs; return $this; } }
