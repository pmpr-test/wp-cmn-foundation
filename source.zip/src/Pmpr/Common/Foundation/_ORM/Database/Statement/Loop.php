<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6af0adcff6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Statement; use Illuminate\Database\Query\Builder; class Loop extends Statement { protected function run(Builder $siykeiywomwwuoiw) : Builder { return $this->igyyscwegckkkkya($siykeiywomwwuoiw); } }
