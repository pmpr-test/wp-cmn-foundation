<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Statement; use Illuminate\Database\Query\Builder; class Loop extends Statement { protected function run(Builder $siykeiywomwwuoiw) : Builder { return $this->igyyscwegckkkkya($siykeiywomwwuoiw); } }
