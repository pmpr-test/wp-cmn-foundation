<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19cd8e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Statement; use Illuminate\Database\Query\Builder; class Loop extends Statement { protected function run(Builder $siykeiywomwwuoiw) : Builder { return $this->igyyscwegckkkkya($siykeiywomwwuoiw); } }
