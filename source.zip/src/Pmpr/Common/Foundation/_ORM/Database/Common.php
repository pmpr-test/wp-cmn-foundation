<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database; use Pmpr\Common\Foundation\_ORM\Common as BaseClass; class Common extends BaseClass { }
