<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database; use Pmpr\Common\Foundation\_ORM\Common as BaseClass; class Common extends BaseClass { }
