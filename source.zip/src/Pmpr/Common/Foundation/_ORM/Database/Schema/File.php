<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae859a8f03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; use Pmpr\Common\Foundation\_ORM\Model; use Pmpr\Common\Foundation\Interfaces\Constants; class File extends Integer { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct($aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie, $mksyucucyswaukig, ?Model $meywaqqsugaoeyys) { if (!(is_numeric($eqgoocgaqwqcimie) && $meywaqqsugaoeyys && ($meywaqqsugaoeyys->qcaekwgmiswccowk(Constants::ieioeisgwcgysukw) || $meywaqqsugaoeyys->qcaekwgmiswccowk(Constants::weiosaewqequuyuq)))) { goto mcsucqagsqysgieu; } $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->iqsmaqoiukeasukw()->qaeeusqkgwagwaqc($eqgoocgaqwqcimie, Constants::meugkwqwuyoyeeqs); mcsucqagsqysgieu: return $eqgoocgaqwqcimie; }); } }
