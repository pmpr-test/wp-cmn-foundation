<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b04f73b21             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x76\141\162\x63\150\141\162"); parent::__construct("\163\x74\162\x69\x6e\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
