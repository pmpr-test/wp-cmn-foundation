<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\141\x72\143\150\141\x72"); parent::__construct("\163\x74\162\x69\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
