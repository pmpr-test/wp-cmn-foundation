<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77d1b4081             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\x61\x72\x63\x68\141\x72"); parent::__construct("\163\x74\x72\151\156\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
