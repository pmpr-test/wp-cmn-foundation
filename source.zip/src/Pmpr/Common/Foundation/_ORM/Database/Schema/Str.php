<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\166\141\x72\143\150\x61\x72"; parent::__construct("\x73\x74\162\151\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
