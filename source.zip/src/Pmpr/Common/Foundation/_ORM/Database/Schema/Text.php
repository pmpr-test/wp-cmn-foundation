<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d8187bb66             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; use Pmpr\Common\Foundation\_ORM\Model; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\164\x65\x78\164"); parent::__construct("\164\x65\x78\x74", $aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie, $mksyucucyswaukig, ?Model $meywaqqsugaoeyys) { if (!(is_string($eqgoocgaqwqcimie) && $meywaqqsugaoeyys && $meywaqqsugaoeyys->qcaekwgmiswccowk(Constants::ieioeisgwcgysukw))) { goto iyawqekeeawqkymm; } $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->nl2br($eqgoocgaqwqcimie); iyawqekeeawqkymm: return $eqgoocgaqwqcimie; }); } }
