<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\147\151\x6e\164"); parent::__construct("\142\151\147\111\156\164\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
