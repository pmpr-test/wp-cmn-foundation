<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f4306668ee2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\147\x69\156\x74"); parent::__construct("\x62\151\x67\111\x6e\x74\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
