<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6052e08a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\x67\x69\x6e\x74"); parent::__construct("\142\151\x67\111\x6e\164\145\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
