<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\x69\147\151\156\164"); parent::__construct("\142\x69\147\111\x6e\164\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
