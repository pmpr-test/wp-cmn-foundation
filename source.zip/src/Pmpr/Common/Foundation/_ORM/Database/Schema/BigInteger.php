<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\x69\147\151\156\164"); parent::__construct("\x62\151\147\x49\x6e\164\x65\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
