<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c61c8485             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\151\x67\151\x6e\164"); parent::__construct("\142\x69\147\x49\156\164\x65\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
