<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\x67\151\x6e\x74"); parent::__construct("\142\x69\147\x49\156\x74\145\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
