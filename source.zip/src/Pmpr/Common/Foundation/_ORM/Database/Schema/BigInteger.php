<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19cd8e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\147\151\156\164"); parent::__construct("\142\x69\x67\111\156\x74\x65\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
