<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\x69\147\151\x6e\x74"); parent::__construct("\142\x69\147\111\156\x74\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
