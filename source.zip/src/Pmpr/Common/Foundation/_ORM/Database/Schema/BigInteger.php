<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da680f9db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\147\x69\x6e\164"); parent::__construct("\142\151\x67\x49\x6e\x74\145\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
