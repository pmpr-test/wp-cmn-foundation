<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6052e08a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\x61\x6c\154\151\156\164"); parent::__construct("\x73\155\141\x6c\154\x49\x6e\x74\145\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
