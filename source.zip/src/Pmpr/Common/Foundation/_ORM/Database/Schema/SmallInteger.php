<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76ba63557             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\x6d\141\154\x6c\151\x6e\164"); parent::__construct("\x73\x6d\141\154\x6c\111\156\164\x65\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
