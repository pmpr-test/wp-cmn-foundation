<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\155\141\154\x6c\151\x6e\x74"; parent::__construct("\x73\155\x61\x6c\154\x49\156\164\x65\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
