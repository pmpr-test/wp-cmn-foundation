<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\x6d\141\x6c\154\151\156\x74"); parent::__construct("\x73\155\141\154\x6c\x49\156\164\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
