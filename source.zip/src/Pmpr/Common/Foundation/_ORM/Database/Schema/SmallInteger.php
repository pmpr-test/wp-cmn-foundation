<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d8187bb66             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\x61\154\154\151\156\164"); parent::__construct("\163\x6d\141\x6c\x6c\111\x6e\164\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
