<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\View; class Index extends View { protected ?ListTable $listTable = null; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\143\x75\162\162\145\x6e\x74\x5f\163\143\x72\x65\x65\x6e", [$this, "\155\143\x6d\x73\143\x63\x69\x79\165\153\x61\x75\145\x73\141\x75"]); } public function waeasakssissiuqg() : ListTable { if (!empty($this->listTable)) { goto ugoqkakikayagkmm; } $this->listTable = new ListTable(); ugoqkakikayagkmm: return $this->listTable; } }
