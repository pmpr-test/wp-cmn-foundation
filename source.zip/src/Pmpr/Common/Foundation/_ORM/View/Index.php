<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e76cb0010             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\View; class Index extends View { protected ?ListTable $listTable = null; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\143\x75\162\x72\145\x6e\164\137\x73\x63\x72\x65\145\x6e", [$this, "\x6d\143\155\x73\x63\x63\151\x79\x75\153\x61\165\x65\x73\141\165"]); } public function waeasakssissiuqg() : ListTable { if (!empty($this->listTable)) { goto ugoqkakikayagkmm; } $this->listTable = new ListTable(); ugoqkakikayagkmm: return $this->listTable; } }
