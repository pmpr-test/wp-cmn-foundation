<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM; class ORM extends Common { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::PREFIX)) { goto kosaqwikueyksqmw; } Ajax::symcgieuakksimmu(); kosaqwikueyksqmw: } }
