<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM; class ORM extends Common { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::PREFIX)) { goto kosaqwikueyksqmw; } Ajax::symcgieuakksimmu(); kosaqwikueyksqmw: } }
