<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Traits; use Pmpr\Common\Foundation\_ORM\ORMObject; trait ORMTrait { protected ORMObject $ORMObject; public function aqaqiqcucamsygaq() : ORMObject { return $this->ORMObject; } public function uqcykecycmgqkssy(ORMObject $eqygaqsaqgiwokyo) : self { $this->ORMObject = $eqygaqsaqgiwokyo; return $this; } }
