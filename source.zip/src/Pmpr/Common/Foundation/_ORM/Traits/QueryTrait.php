<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da680f9db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Traits; use Pmpr\Common\Foundation\_ORM\Database\Query; use Pmpr\Common\Foundation\_ORM\Database\Statement; trait QueryTrait { public function megqywqeuquawkim(string $qgoqiacsiccwoawi = '', $eqgoocgaqwqcimie = '') : Statement\Where { return new Statement\Where($qgoqiacsiccwoawi, $eqgoocgaqwqcimie); } public function ucugosowycikeecc() : Statement\Loop { return new Statement\Loop(); } public function kyckwuuiqwmyoqma() : Query { return new Query(); } }
