<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { }
