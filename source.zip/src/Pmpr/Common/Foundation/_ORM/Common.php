<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { }
