<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { }
