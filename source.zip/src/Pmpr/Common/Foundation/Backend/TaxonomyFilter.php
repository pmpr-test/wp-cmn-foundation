<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7c471feb6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class TaxonomyFilter extends AbstractFilter { public function ikcgmcycisiccyuc() { $this->type = Constants::gmmygyiecgmggaam; } function egkeamycaysqsoma(array $tsuauommsquiesmk, $gqgemcmoicmgaqie, $eqgoocgaqwqcimie) { } }
