<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6052e08a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\x6e\x5f\146\x6f\x6f\x74\145\162", [$this, "\147\x67\163\x6b\143\147\147\141\141\145\x61\153\147\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\x75\x6e\x64\141\x74\x69\157\156\137\x62\x61\x63\153\x65\156\144\137\x67\145\156\x65\162\141\x74\145\137\x6d\x6f\144\x61\x6c\137\x61\143\x74\x69\157\156", [$this, "\151\x67\151\141\x77\x6b\157\x71\151\x6f\x67\157\x63\163\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\137\x67\x65\x6e\x65\162\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
