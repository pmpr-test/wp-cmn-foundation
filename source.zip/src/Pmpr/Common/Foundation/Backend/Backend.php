<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580c648b6e4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\151\156\137\x66\157\x6f\164\145\x72", [$this, "\x67\x67\163\153\143\147\x67\x61\141\145\x61\153\147\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\x75\156\x64\141\x74\151\x6f\156\137\x62\x61\x63\x6b\145\x6e\144\x5f\147\145\156\145\x72\141\x74\145\137\155\x6f\x64\x61\x6c\137\x61\x63\x74\151\157\x6e", [$this, "\151\x67\151\x61\x77\x6b\157\161\151\157\x67\x6f\x63\x73\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\147\x65\x6e\145\162\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
