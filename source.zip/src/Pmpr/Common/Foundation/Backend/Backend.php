<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671269d6639fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\156\x5f\x66\157\157\x74\x65\162", [$this, "\x67\x67\x73\153\x63\147\147\x61\x61\145\x61\x6b\x67\x61\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\x75\x6e\144\x61\164\151\157\156\137\x62\141\x63\153\145\x6e\144\x5f\x67\x65\156\145\162\x61\x74\145\x5f\x6d\x6f\x64\x61\x6c\137\x61\143\164\x69\157\156", [$this, "\151\147\x69\x61\x77\153\x6f\x71\151\157\x67\157\x63\x73\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\x5f\x67\145\156\145\x72\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
