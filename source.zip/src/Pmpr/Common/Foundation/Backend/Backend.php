<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c61c8485             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\x5f\x66\157\157\164\x65\x72", [$this, "\147\147\x73\153\x63\147\x67\x61\141\145\x61\153\x67\141\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\x6e\144\141\164\x69\x6f\156\x5f\x62\141\x63\153\145\x6e\144\x5f\147\145\x6e\x65\162\x61\164\x65\x5f\x6d\x6f\x64\x61\x6c\x5f\x61\x63\164\151\x6f\156", [$this, "\151\x67\151\x61\x77\x6b\x6f\x71\151\x6f\147\x6f\143\x73\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\x5f\x67\x65\156\145\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
