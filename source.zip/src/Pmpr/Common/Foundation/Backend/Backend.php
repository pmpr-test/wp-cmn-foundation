<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\156\137\146\157\157\x74\145\x72", [$this, "\147\x67\163\153\143\x67\x67\x61\141\145\x61\153\147\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\165\156\x64\141\x74\151\157\x6e\x5f\x62\x61\x63\153\145\156\144\137\x67\x65\x6e\145\x72\x61\x74\145\x5f\x6d\157\x64\141\x6c\x5f\141\x63\x74\x69\x6f\156", [$this, "\151\147\x69\141\x77\153\x6f\x71\x69\x6f\147\157\x63\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\147\145\x6e\x65\x72\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
