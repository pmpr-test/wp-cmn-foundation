<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192c055a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\137\x66\157\x6f\164\x65\x72", [$this, "\147\x67\163\x6b\143\147\147\141\141\145\141\x6b\x67\141\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\x75\156\144\141\164\151\157\156\137\142\141\x63\153\145\156\x64\x5f\147\145\156\145\162\x61\164\145\x5f\x6d\x6f\x64\141\154\x5f\141\143\x74\x69\x6f\156", [$this, "\x69\147\x69\141\167\x6b\157\161\x69\157\x67\x6f\x63\163\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\x5f\147\145\x6e\145\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
