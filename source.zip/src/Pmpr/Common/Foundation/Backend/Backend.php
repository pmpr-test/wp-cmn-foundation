<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a37bcbb1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\x5f\146\157\x6f\164\145\162", [$this, "\x67\147\x73\153\143\147\147\x61\x61\145\x61\153\147\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\x75\x6e\x64\141\164\x69\x6f\x6e\x5f\142\x61\x63\153\145\x6e\144\x5f\x67\x65\156\x65\x72\x61\x74\x65\137\x6d\157\x64\x61\x6c\137\141\x63\164\x69\x6f\156", [$this, "\x69\147\151\x61\x77\153\157\x71\x69\157\147\x6f\143\163\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\x5f\147\145\x6e\145\162\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
