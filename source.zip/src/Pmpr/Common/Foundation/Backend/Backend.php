<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2ce2062a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\x6e\137\146\157\x6f\x74\145\162", [$this, "\147\147\x73\x6b\143\x67\x67\141\141\145\141\153\147\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\x75\x6e\x64\141\164\x69\157\156\x5f\x62\x61\x63\x6b\x65\156\x64\137\x67\x65\156\145\x72\x61\164\x65\137\155\x6f\x64\141\154\137\x61\143\x74\151\157\x6e", [$this, "\x69\x67\151\141\x77\x6b\x6f\x71\x69\x6f\147\157\x63\163\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\x67\x65\x6e\145\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
