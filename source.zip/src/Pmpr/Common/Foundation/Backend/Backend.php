<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522a8f9030b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\137\146\x6f\x6f\164\x65\162", [$this, "\147\147\x73\153\143\x67\x67\141\x61\145\141\x6b\147\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\x75\x6e\144\141\x74\151\x6f\156\x5f\x62\141\143\x6b\x65\156\144\137\x67\x65\156\x65\162\x61\x74\x65\x5f\x6d\x6f\x64\x61\x6c\x5f\x61\x63\164\x69\157\156", [$this, "\x69\x67\x69\x61\167\153\x6f\161\151\x6f\x67\157\143\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\147\x65\156\x65\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
