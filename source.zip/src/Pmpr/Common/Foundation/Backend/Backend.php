<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791524c10e10             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\151\156\137\146\157\157\x74\145\x72", [$this, "\x67\x67\163\153\143\x67\147\x61\141\x65\141\153\147\x61\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\x6e\144\141\x74\151\x6f\156\x5f\142\x61\x63\x6b\x65\x6e\x64\x5f\x67\x65\x6e\145\162\141\164\x65\x5f\x6d\x6f\144\x61\154\137\x61\x63\164\x69\157\156", [$this, "\x69\147\x69\x61\x77\153\x6f\161\x69\157\147\x6f\143\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\137\147\x65\x6e\145\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
