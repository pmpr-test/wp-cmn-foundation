<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\156\x5f\146\157\x6f\164\145\162", [$this, "\x67\x67\x73\153\x63\147\x67\x61\x61\x65\141\x6b\x67\x61\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\165\x6e\144\141\x74\151\x6f\x6e\137\142\141\143\x6b\x65\x6e\x64\137\x67\x65\156\x65\x72\141\164\145\137\155\157\144\141\154\x5f\x61\x63\164\151\x6f\x6e", [$this, "\x69\147\151\x61\167\153\x6f\161\151\x6f\147\x6f\x63\x73\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\137\x67\145\156\145\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
