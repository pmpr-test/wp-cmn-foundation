<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff7768f0b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\x6e\x5f\x66\157\x6f\x74\145\x72", [$this, "\x67\x67\x73\153\143\147\147\141\x61\145\x61\153\147\x61\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\165\156\144\x61\x74\x69\x6f\156\x5f\142\141\x63\x6b\145\156\144\137\x67\x65\156\x65\162\141\x74\x65\x5f\155\157\x64\x61\x6c\x5f\x61\143\164\x69\157\156", [$this, "\x69\x67\151\141\x77\153\157\x71\x69\157\147\x6f\143\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\x5f\147\x65\x6e\x65\162\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
