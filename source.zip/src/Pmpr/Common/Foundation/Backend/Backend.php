<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\x6e\137\x66\x6f\157\164\145\162", [$this, "\147\147\x73\153\143\147\147\141\x61\x65\141\x6b\x67\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\x75\156\x64\x61\164\x69\157\156\137\x62\x61\x63\x6b\x65\x6e\144\x5f\x67\x65\x6e\x65\162\141\x74\x65\x5f\x6d\157\144\x61\154\x5f\141\x63\164\x69\x6f\x6e", [$this, "\151\x67\x69\141\167\153\x6f\x71\151\x6f\x67\x6f\143\x73\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\147\x65\156\x65\162\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
