<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d41721935c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\x5f\x66\x6f\157\164\x65\x72", [$this, "\x67\x67\x73\153\x63\147\x67\141\x61\x65\x61\153\147\x61\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\x75\x6e\x64\141\x74\151\157\156\x5f\142\141\x63\x6b\x65\156\144\137\x67\x65\156\x65\162\x61\164\145\137\155\157\144\141\x6c\x5f\x61\143\164\151\157\156", [$this, "\x69\147\151\x61\x77\x6b\x6f\161\151\157\x67\157\143\x73\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\137\147\145\156\x65\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
