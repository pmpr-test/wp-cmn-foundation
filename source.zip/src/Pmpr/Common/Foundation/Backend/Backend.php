<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679574c05515f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\137\x66\157\157\x74\x65\x72", [$this, "\147\147\163\x6b\x63\x67\147\141\x61\x65\x61\153\x67\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\165\x6e\144\141\164\x69\157\x6e\x5f\142\141\143\153\145\x6e\144\137\x67\x65\156\145\x72\x61\x74\x65\137\155\x6f\144\141\x6c\137\x61\143\164\x69\x6f\x6e", [$this, "\151\x67\x69\141\x77\153\157\x71\151\x6f\x67\157\143\163\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\x67\145\156\x65\x72\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
