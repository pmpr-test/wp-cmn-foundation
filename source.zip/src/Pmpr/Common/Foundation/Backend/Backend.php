<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\x6e\137\x66\x6f\x6f\x74\x65\162", [$this, "\x67\147\x73\153\x63\x67\147\141\141\x65\141\153\147\x61\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\x75\x6e\x64\141\164\151\x6f\156\x5f\x62\x61\143\153\x65\x6e\x64\x5f\147\145\x6e\145\x72\x61\164\145\137\x6d\x6f\x64\x61\x6c\x5f\x61\x63\164\151\157\x6e", [$this, "\x69\x67\151\141\x77\153\157\x71\x69\157\x67\157\143\x73\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\x5f\x67\145\156\145\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
