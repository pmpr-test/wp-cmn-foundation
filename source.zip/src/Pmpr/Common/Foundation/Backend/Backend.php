<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\156\x5f\146\x6f\157\164\x65\162", [$this, "\x67\147\x73\153\143\147\x67\x61\x61\145\141\153\147\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\165\156\x64\141\164\151\157\x6e\x5f\142\x61\143\x6b\x65\156\144\x5f\147\145\156\x65\162\141\164\145\137\155\x6f\144\141\x6c\137\x61\x63\164\151\157\x6e", [$this, "\151\x67\x69\141\x77\153\157\161\151\157\x67\157\x63\x73\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\147\x65\x6e\145\x72\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
