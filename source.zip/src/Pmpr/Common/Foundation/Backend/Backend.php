<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e17b763d23d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\x69\x6e\x5f\x66\x6f\157\164\x65\162", [$this, "\x67\x67\x73\x6b\143\147\x67\141\141\145\x61\153\x67\x61\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\165\156\144\x61\164\x69\157\x6e\137\142\141\x63\153\x65\x6e\x64\x5f\147\x65\x6e\145\x72\x61\x74\145\x5f\x6d\157\144\x61\154\137\141\x63\164\x69\x6f\156", [$this, "\151\147\x69\x61\167\153\x6f\161\151\x6f\x67\157\143\x73\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\147\x65\x6e\145\162\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
