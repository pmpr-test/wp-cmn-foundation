<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a6c2def5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\156\137\146\x6f\157\164\x65\162", [$this, "\x67\147\163\x6b\143\x67\x67\141\x61\x65\x61\153\147\141\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\165\x6e\x64\141\x74\151\x6f\x6e\137\x62\141\143\x6b\x65\x6e\144\x5f\x67\145\x6e\145\162\141\164\145\x5f\x6d\x6f\x64\x61\x6c\x5f\x61\x63\164\x69\157\x6e", [$this, "\x69\x67\x69\x61\x77\x6b\x6f\161\x69\x6f\147\x6f\143\163\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\x67\x65\156\x65\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
