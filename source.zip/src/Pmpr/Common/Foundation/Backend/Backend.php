<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6780382025b61             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\x5f\x66\x6f\x6f\164\x65\162", [$this, "\x67\x67\x73\x6b\143\x67\147\141\x61\x65\141\153\x67\141\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\156\144\141\x74\x69\x6f\x6e\x5f\142\141\x63\153\145\x6e\144\x5f\x67\x65\156\x65\162\x61\x74\x65\x5f\x6d\157\144\x61\154\x5f\141\x63\164\x69\157\x6e", [$this, "\x69\147\151\141\167\153\157\161\x69\x6f\x67\157\x63\163\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\x67\x65\156\x65\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
