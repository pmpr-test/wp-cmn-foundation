<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677bb92f8cee3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\x6e\x5f\x66\x6f\157\164\145\x72", [$this, "\147\x67\x73\153\x63\x67\147\x61\141\x65\x61\x6b\147\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\156\x64\141\x74\151\x6f\156\137\x62\x61\143\x6b\145\x6e\x64\x5f\147\x65\x6e\x65\162\x61\164\145\137\155\157\144\141\x6c\x5f\141\143\164\151\x6f\x6e", [$this, "\x69\x67\x69\141\x77\153\x6f\161\x69\157\x67\157\143\x73\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\147\145\x6e\x65\x72\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
