<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\x69\x6e\137\x66\157\157\x74\145\x72", [$this, "\x67\x67\x73\153\x63\147\x67\141\141\x65\141\x6b\x67\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\165\156\x64\x61\164\x69\157\x6e\137\x62\x61\x63\x6b\x65\x6e\144\137\147\145\156\x65\162\141\164\x65\137\155\157\144\x61\x6c\137\x61\x63\x74\x69\157\156", [$this, "\x69\147\x69\x61\167\153\157\161\151\157\147\157\143\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\x67\x65\156\145\x72\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
