<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835e37313             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\x6e\x5f\146\157\157\x74\145\x72", [$this, "\x67\x67\163\x6b\143\147\x67\141\141\x65\141\x6b\x67\x61\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\x75\156\144\x61\164\151\x6f\x6e\137\142\x61\x63\x6b\x65\x6e\144\x5f\x67\x65\x6e\145\x72\x61\x74\145\137\155\157\x64\x61\154\x5f\141\x63\164\151\x6f\x6e", [$this, "\x69\x67\151\x61\167\x6b\157\x71\151\157\x67\x6f\143\163\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\147\x65\156\x65\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
