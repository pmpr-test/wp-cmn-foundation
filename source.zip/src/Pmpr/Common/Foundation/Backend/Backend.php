<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67955288a0e50             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\x6e\x5f\146\x6f\157\x74\x65\x72", [$this, "\x67\147\x73\x6b\x63\x67\147\x61\x61\x65\x61\153\x67\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\x75\x6e\144\141\x74\151\157\156\x5f\142\141\x63\153\x65\156\144\x5f\147\x65\156\x65\162\x61\x74\145\137\x6d\157\x64\x61\154\137\x61\x63\x74\x69\x6f\156", [$this, "\151\x67\x69\141\x77\x6b\x6f\161\x69\x6f\x67\x6f\x63\x73\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\x5f\x67\145\x6e\x65\162\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
