<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\x6e\x5f\146\157\157\x74\145\162", [$this, "\x67\x67\x73\x6b\x63\147\x67\141\x61\145\x61\153\x67\141\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\x75\156\144\x61\164\x69\157\156\137\x62\x61\143\x6b\x65\x6e\144\137\147\x65\x6e\145\x72\141\x74\x65\137\155\157\x64\141\154\x5f\x61\x63\164\x69\x6f\x6e", [$this, "\151\147\151\141\x77\x6b\x6f\x71\151\157\x67\157\x63\163\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\x5f\147\145\156\x65\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
