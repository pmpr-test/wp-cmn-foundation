<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a92bf092             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\156\x5f\x66\x6f\x6f\x74\145\162", [$this, "\x67\x67\163\153\x63\147\147\141\x61\x65\x61\153\x67\x61\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\165\156\144\x61\164\151\x6f\156\x5f\x62\x61\x63\x6b\x65\x6e\144\x5f\x67\x65\x6e\145\x72\x61\x74\145\137\x6d\x6f\x64\x61\154\137\141\x63\164\x69\157\156", [$this, "\151\x67\151\141\167\x6b\x6f\x71\x69\x6f\x67\157\143\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\147\x65\x6e\145\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
