<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d172c3f1f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\x5f\x66\x6f\157\x74\145\162", [$this, "\147\147\x73\153\143\147\147\x61\x61\145\x61\153\147\x61\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\165\x6e\144\141\x74\151\157\156\x5f\142\141\143\x6b\x65\156\144\x5f\x67\x65\156\145\162\141\x74\145\x5f\x6d\x6f\x64\x61\154\x5f\x61\x63\164\151\157\156", [$this, "\151\x67\151\141\167\153\157\161\x69\157\147\157\143\163\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\x5f\147\145\156\x65\x72\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
