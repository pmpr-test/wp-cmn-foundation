<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08edec3b9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\x5f\146\157\157\164\x65\162", [$this, "\147\147\x73\x6b\x63\147\x67\141\x61\x65\x61\x6b\147\141\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\x75\x6e\144\x61\x74\x69\x6f\x6e\137\x62\141\x63\x6b\145\156\x64\137\x67\x65\156\145\162\141\164\x65\x5f\x6d\x6f\x64\x61\x6c\137\141\143\164\x69\x6f\156", [$this, "\151\147\x69\141\167\153\157\x71\151\157\x67\157\x63\x73\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\x5f\147\x65\x6e\x65\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
