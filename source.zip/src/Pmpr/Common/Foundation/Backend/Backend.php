<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356231cfee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\156\137\146\x6f\x6f\164\x65\x72", [$this, "\x67\x67\x73\153\x63\x67\x67\141\x61\145\141\153\x67\x61\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\x75\156\x64\x61\x74\151\157\156\137\x62\x61\143\153\145\x6e\x64\x5f\x67\145\156\x65\162\x61\164\145\x5f\155\157\144\x61\x6c\x5f\141\x63\164\151\x6f\156", [$this, "\x69\x67\151\x61\167\153\157\161\151\157\x67\157\143\x73\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\x67\145\x6e\145\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
