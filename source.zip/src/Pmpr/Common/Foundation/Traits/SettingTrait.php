<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Traits; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; trait SettingTrait { protected ?Setting $settingObj = null; public final function kmuweyayaqoeqiyw() : ?Setting { return $this->settingObj; } public final function aoqykkmokwseeeie() : array { $qeqooyuoiasweuck = []; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto ecoikiciouuikmgs; } $qeqooyuoiasweuck = $mksyucucyswaukig->gkwkqmwweiawigae(); ecoikiciouuikmgs: return $qeqooyuoiasweuck; } public final function weysguygiseoukqw(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { $amakmumgguksgmum = $ggauoeuaesiymgee; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto yawqcawaywkgqkkq; } $amakmumgguksgmum = $mksyucucyswaukig->giiuwsmyumqwwiyq($uusmaiomayssaecw, $ggauoeuaesiymgee); yawqcawaywkgqkkq: return $amakmumgguksgmum; } }
