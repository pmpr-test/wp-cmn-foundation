<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68df9bb783902             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Traits; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; trait SettingTrait { public function kmuweyayaqoeqiyw() : ?Setting { if ($wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->get($this)) { return $wksoawcgagcgoask->mggwieqomgcuskme(); } return null; } public final function weysguygiseoukqw(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null, $gmcgeogogyqsgawk = null) { $amakmumgguksgmum = $ggauoeuaesiymgee; if ($mksyucucyswaukig = $this->kmuweyayaqoeqiyw()) { $amakmumgguksgmum = $mksyucucyswaukig->giiuwsmyumqwwiyq($uusmaiomayssaecw, $ggauoeuaesiymgee, $gmcgeogogyqsgawk); } return $amakmumgguksgmum; } }
