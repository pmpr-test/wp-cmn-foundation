<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Traits; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; trait SettingTrait { protected ?Setting $settingObj = null; public final function kmuweyayaqoeqiyw() : ?Setting { return $this->settingObj; } public final function aoqykkmokwseeeie() : array { $qeqooyuoiasweuck = []; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto wwuoaqqiaaguyyiu; } $qeqooyuoiasweuck = $mksyucucyswaukig->gkwkqmwweiawigae(); wwuoaqqiaaguyyiu: return $qeqooyuoiasweuck; } public final function weysguygiseoukqw(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { $amakmumgguksgmum = $ggauoeuaesiymgee; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto uccmgkcygwcoqqmc; } $amakmumgguksgmum = $mksyucucyswaukig->giiuwsmyumqwwiyq($uusmaiomayssaecw, $ggauoeuaesiymgee); uccmgkcygwcoqqmc: return $amakmumgguksgmum; } }
