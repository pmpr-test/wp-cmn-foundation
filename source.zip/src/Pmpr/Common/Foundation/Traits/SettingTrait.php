<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfc3785             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Traits; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; trait SettingTrait { public function kmuweyayaqoeqiyw() : ?Setting { if (!($wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->get($this))) { goto eeyukwscccmigmuq; } return $wksoawcgagcgoask->mggwieqomgcuskme(); eeyukwscccmigmuq: return null; } public final function weysguygiseoukqw(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null, $gmcgeogogyqsgawk = []) { $amakmumgguksgmum = $ggauoeuaesiymgee; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto oqmwiucmyoiwciws; } $amakmumgguksgmum = $mksyucucyswaukig->giiuwsmyumqwwiyq($uusmaiomayssaecw, $ggauoeuaesiymgee, $gmcgeogogyqsgawk); oqmwiucmyoiwciws: return $amakmumgguksgmum; } }
