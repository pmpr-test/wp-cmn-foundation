<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053bb6ecfdb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Frontend; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function __construct(?string $aokagokqyuysuksm = '', $meqocwsecsywiiqs = '') { $this->title = $meqocwsecsywiiqs; $this->hasLicense = false; $this->igiywquyccyiaucw(Constants::qoquaeuooeycomks, "\x6e\x6f\x2d\x70\x61\162\x65\156\164"); parent::__construct($aokagokqyuysuksm); } }
