<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688743a0185db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Frontend; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function __construct(?string $aokagokqyuysuksm = '', $meqocwsecsywiiqs = '') { $this->title = $meqocwsecsywiiqs; $this->hasLicense = false; $this->igiywquyccyiaucw(Constants::qoquaeuooeycomks, 'no-parent'); parent::__construct($aokagokqyuysuksm); } }
