<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da3200825a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\x72\57\61\57\x62\x72\141\x6e\144\57\x70\155\160\162\x2d\163\155\141\x6c\x6c"; const aoceigukcccyimew = "\x70\155\160\x72\x2f\x31\57\x62\162\x61\156\144\57\x63\154\157\165\x64\146\x6c\x61\x72\x65"; }
