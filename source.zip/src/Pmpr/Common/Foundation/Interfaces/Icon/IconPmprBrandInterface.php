<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\57\x31\57\142\x72\x61\x6e\144\x2f\x70\155\160\x72\55\x73\x6d\141\154\x6c"; const aoceigukcccyimew = "\x70\x6d\160\162\x2f\x31\57\x62\162\x61\x6e\144\x2f\x63\154\x6f\165\144\146\x6c\x61\x72\x65"; }
