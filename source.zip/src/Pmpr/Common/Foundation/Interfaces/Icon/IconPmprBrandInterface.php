<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08edec3b9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\57\x31\x2f\142\x72\141\x6e\144\x2f\x70\x6d\x70\162\55\x73\x6d\141\x6c\154"; const aoceigukcccyimew = "\160\155\x70\162\57\61\57\142\162\141\156\144\57\143\x6c\x6f\x75\144\x66\x6c\141\162\145"; }
