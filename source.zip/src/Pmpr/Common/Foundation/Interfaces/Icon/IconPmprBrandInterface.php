<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6780382025b61             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\57\x31\x2f\x62\162\141\x6e\144\x2f\x70\155\x70\162\55\x73\155\x61\154\x6c"; const aoceigukcccyimew = "\160\155\x70\162\57\x31\x2f\x62\x72\141\x6e\144\x2f\x63\154\x6f\165\x64\146\x6c\x61\x72\x65"; }
