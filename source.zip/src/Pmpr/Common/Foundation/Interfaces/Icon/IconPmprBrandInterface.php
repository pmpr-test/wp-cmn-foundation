<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791545e8b23b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\57\61\x2f\142\162\x61\x6e\144\x2f\160\155\160\162\x2d\163\155\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\160\x72\x2f\61\57\x62\162\141\x6e\144\x2f\143\154\157\165\x64\x66\x6c\141\x72\x65"; }
