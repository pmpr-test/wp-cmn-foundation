<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\x72\x2f\x31\x2f\142\162\141\156\x64\57\160\155\160\x72\x2d\163\155\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\x70\162\x2f\x31\x2f\142\162\141\x6e\144\57\x63\x6c\157\165\144\x66\x6c\141\x72\x65"; }
