<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d172c3f1f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\57\61\57\x62\x72\x61\156\x64\x2f\160\155\160\x72\55\x73\155\141\x6c\154"; const aoceigukcccyimew = "\160\155\x70\162\57\61\57\142\x72\x61\x6e\x64\57\143\x6c\x6f\x75\x64\x66\x6c\141\x72\145"; }
