<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675815b967a0e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\x72\x2f\61\x2f\142\162\x61\156\144\57\160\x6d\160\x72\x2d\x73\x6d\x61\x6c\154"; const aoceigukcccyimew = "\160\155\160\162\57\61\x2f\142\x72\141\156\144\57\143\154\x6f\165\144\x66\154\x61\x72\145"; }
