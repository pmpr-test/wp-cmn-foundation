<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d54c9a6ea1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\57\61\57\x62\x72\141\156\x64\57\160\x6d\x70\162\55\x73\x6d\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\x70\162\x2f\x31\57\x62\162\x61\x6e\x64\57\x63\154\x6f\165\144\146\154\141\x72\145"; }
