<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522aeb59a71             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\x2f\x31\57\142\x72\x61\x6e\x64\57\160\x6d\x70\x72\x2d\163\155\141\154\154"; const aoceigukcccyimew = "\160\155\160\x72\x2f\x31\57\142\x72\x61\156\x64\x2f\x63\x6c\157\x75\144\146\154\x61\x72\145"; }
