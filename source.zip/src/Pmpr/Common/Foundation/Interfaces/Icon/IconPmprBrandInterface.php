<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9fd229d29             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\x72\x2f\61\x2f\142\x72\141\x6e\144\x2f\x70\x6d\x70\162\55\x73\x6d\x61\154\154"; const aoceigukcccyimew = "\160\155\160\x72\57\61\57\x62\x72\141\x6e\x64\x2f\x63\154\157\165\x64\146\154\141\x72\x65"; }
