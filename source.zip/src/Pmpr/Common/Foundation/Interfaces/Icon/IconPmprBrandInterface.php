<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abcde521502             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\57\61\x2f\142\x72\141\x6e\144\57\x70\x6d\160\162\55\163\155\x61\154\154"; const aoceigukcccyimew = "\160\x6d\x70\x72\x2f\x31\x2f\x62\x72\x61\156\x64\x2f\x63\x6c\157\165\x64\146\154\x61\162\x65"; }
