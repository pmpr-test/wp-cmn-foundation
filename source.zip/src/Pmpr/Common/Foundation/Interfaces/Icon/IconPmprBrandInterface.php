<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791512bce1c4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\x72\x2f\61\57\x62\x72\141\156\144\x2f\x70\x6d\160\x72\x2d\x73\155\x61\154\154"; const aoceigukcccyimew = "\x70\155\160\x72\57\61\57\x62\x72\x61\x6e\x64\x2f\x63\154\157\x75\x64\x66\x6c\141\162\x65"; }
