<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beb88b904             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\x2f\61\57\142\162\x61\156\x64\57\x70\155\160\162\55\x73\x6d\x61\x6c\154"; const aoceigukcccyimew = "\x70\155\x70\x72\57\x31\57\142\x72\141\x6e\144\57\x63\154\x6f\x75\x64\x66\x6c\141\162\x65"; }
