<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdd41716df             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\x31\57\142\162\x61\x6e\144\x2f\160\x6d\160\x72\x2d\x73\x6d\141\154\x6c"; const aoceigukcccyimew = "\x70\x6d\160\x72\57\61\57\x62\x72\141\156\144\57\143\154\157\165\x64\146\x6c\141\162\x65"; }
