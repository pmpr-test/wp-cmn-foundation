<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec7e2db2b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\61\57\142\x72\141\156\x64\57\x70\x6d\160\x72\55\163\155\141\x6c\x6c"; const aoceigukcccyimew = "\160\x6d\x70\162\x2f\61\57\142\x72\141\156\144\57\143\154\x6f\165\144\x66\x6c\141\x72\145"; }
