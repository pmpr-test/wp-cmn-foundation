<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6052e08a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\57\x31\x2f\142\x72\141\156\x64\57\160\x6d\x70\x72\x2d\163\155\141\154\x6c"; const aoceigukcccyimew = "\160\155\160\162\57\61\57\142\x72\x61\156\x64\x2f\x63\x6c\157\165\x64\x66\x6c\x61\162\145"; }
