<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbcd2165a5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\x72\57\x31\57\x62\x72\x61\156\144\x2f\x70\x6d\x70\x72\x2d\163\155\141\154\x6c"; const aoceigukcccyimew = "\160\155\x70\162\x2f\61\57\142\x72\x61\x6e\144\x2f\143\x6c\x6f\x75\144\x66\154\141\x72\145"; }
