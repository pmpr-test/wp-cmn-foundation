<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\162\57\x31\x2f\x62\162\x61\156\x64\x2f\x70\155\x70\x72\55\163\155\141\x6c\154"; const aoceigukcccyimew = "\x70\x6d\x70\x72\57\61\x2f\x62\162\x61\156\144\x2f\x63\x6c\x6f\x75\x64\x66\x6c\141\162\145"; }
