<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec064496439             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\57\x31\57\142\x72\141\156\x64\x2f\x70\x6d\160\162\55\163\155\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\x70\x72\x2f\x31\57\142\x72\141\156\144\57\143\x6c\157\x75\144\x66\x6c\x61\x72\145"; }
