<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b58eab716             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\57\x31\x2f\142\162\x61\156\x64\57\x70\155\160\x72\x2d\163\x6d\141\x6c\x6c"; const aoceigukcccyimew = "\x70\155\160\x72\57\61\x2f\142\162\141\156\x64\57\x63\x6c\157\165\144\146\154\x61\x72\x65"; }
