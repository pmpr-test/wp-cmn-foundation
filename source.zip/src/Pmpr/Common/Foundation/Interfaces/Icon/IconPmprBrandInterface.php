<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c9bc679             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\57\61\57\x62\x72\141\156\x64\x2f\x70\155\x70\162\55\x73\155\141\154\x6c"; const aoceigukcccyimew = "\x70\x6d\x70\x72\57\x31\x2f\x62\x72\x61\156\144\57\x63\154\157\x75\144\146\x6c\x61\x72\x65"; }
