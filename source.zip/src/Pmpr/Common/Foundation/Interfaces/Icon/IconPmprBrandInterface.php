<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76ba63557             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\162\57\61\57\142\x72\x61\x6e\144\x2f\160\155\160\x72\55\x73\155\x61\x6c\x6c"; const aoceigukcccyimew = "\160\155\x70\x72\57\61\57\142\x72\x61\x6e\x64\x2f\143\x6c\x6f\165\x64\x66\x6c\x61\x72\x65"; }
