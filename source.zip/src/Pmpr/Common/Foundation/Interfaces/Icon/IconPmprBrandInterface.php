<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356231cfee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\57\61\x2f\x62\x72\141\x6e\x64\57\x70\155\x70\162\55\163\x6d\141\154\x6c"; const aoceigukcccyimew = "\160\x6d\x70\162\x2f\x31\57\142\162\x61\156\x64\57\143\x6c\x6f\x75\x64\146\154\x61\162\145"; }
