<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d13e4bc148             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\x2f\61\x2f\x62\x72\141\x6e\x64\x2f\160\155\x70\x72\55\163\155\x61\x6c\x6c"; const aoceigukcccyimew = "\160\155\x70\x72\57\x31\57\x62\x72\x61\x6e\144\x2f\143\154\157\x75\x64\x66\x6c\x61\162\x65"; }
