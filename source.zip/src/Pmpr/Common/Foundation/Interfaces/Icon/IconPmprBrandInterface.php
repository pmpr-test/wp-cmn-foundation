<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d3e38c782d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\x2f\x31\x2f\142\x72\x61\156\x64\x2f\160\155\160\162\55\x73\155\x61\154\x6c"; const aoceigukcccyimew = "\160\155\x70\162\x2f\x31\x2f\x62\x72\141\x6e\x64\57\143\x6c\x6f\x75\144\146\154\141\x72\x65"; }
