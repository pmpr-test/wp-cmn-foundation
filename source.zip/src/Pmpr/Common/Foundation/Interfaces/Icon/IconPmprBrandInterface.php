<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\162\57\61\57\142\x72\141\x6e\144\x2f\160\155\x70\x72\55\x73\x6d\x61\154\154"; const aoceigukcccyimew = "\160\x6d\x70\162\x2f\61\57\x62\x72\141\156\x64\57\x63\154\x6f\x75\144\146\154\x61\x72\145"; }
