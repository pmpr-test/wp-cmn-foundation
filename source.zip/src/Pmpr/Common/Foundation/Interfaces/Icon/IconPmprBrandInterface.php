<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705a37ba6a79             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\x72\x2f\x31\x2f\142\x72\x61\156\x64\57\160\155\160\x72\x2d\163\x6d\x61\154\x6c"; const aoceigukcccyimew = "\x70\155\160\162\x2f\x31\x2f\142\x72\x61\x6e\144\57\x63\x6c\x6f\x75\144\x66\154\141\x72\145"; }
