<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d585ed47eb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\162\57\61\x2f\x62\x72\x61\156\x64\57\160\155\160\x72\55\163\155\141\154\154"; const aoceigukcccyimew = "\x70\x6d\160\162\57\x31\x2f\142\x72\141\x6e\144\57\x63\154\x6f\x75\144\146\x6c\x61\162\145"; }
