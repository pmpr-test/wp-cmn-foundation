<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977684bcc9f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\57\61\x2f\x62\162\x61\x6e\144\57\160\x6d\x70\162\55\x73\x6d\x61\x6c\x6c"; const aoceigukcccyimew = "\160\155\160\162\57\61\x2f\x62\x72\141\x6e\x64\x2f\x63\x6c\x6f\x75\144\x66\x6c\x61\x72\145"; }
