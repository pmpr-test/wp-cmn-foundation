<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfc3785             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\57\61\57\x62\x72\x61\156\x64\x2f\x70\155\160\x72\x2d\x73\x6d\x61\x6c\154"; const aoceigukcccyimew = "\160\155\160\162\57\x31\x2f\142\x72\141\156\x64\x2f\143\154\157\x75\144\x66\x6c\x61\162\145"; }
