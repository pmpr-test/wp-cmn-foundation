<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\x72\57\x31\x2f\142\x72\141\156\144\x2f\x70\155\x70\x72\55\x73\155\x61\x6c\154"; const aoceigukcccyimew = "\160\x6d\160\x72\57\61\x2f\142\x72\141\156\x64\x2f\143\154\157\165\144\x66\x6c\141\x72\x65"; }
