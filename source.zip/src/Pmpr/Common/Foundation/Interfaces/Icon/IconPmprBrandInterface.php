<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbd402ffa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\57\x31\x2f\142\162\141\156\144\x2f\160\155\x70\162\x2d\163\x6d\141\154\154"; const aoceigukcccyimew = "\x70\155\x70\162\57\x31\57\x62\x72\x61\156\x64\57\143\154\x6f\165\144\146\x6c\141\x72\145"; }
