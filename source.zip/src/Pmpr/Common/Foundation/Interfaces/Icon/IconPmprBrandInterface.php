<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d87febf6a7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\x72\57\61\57\142\x72\141\156\144\x2f\x70\x6d\160\x72\x2d\163\x6d\141\154\x6c"; const aoceigukcccyimew = "\160\x6d\160\x72\57\x31\x2f\x62\x72\x61\156\144\57\x63\x6c\x6f\x75\x64\146\154\x61\162\145"; }
