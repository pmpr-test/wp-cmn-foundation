<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522a8f9030b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\x72\57\x31\x2f\142\162\x61\156\144\57\160\x6d\160\x72\55\x73\x6d\141\154\x6c"; const aoceigukcccyimew = "\x70\155\160\162\x2f\61\x2f\x62\162\141\156\x64\57\x63\154\x6f\x75\x64\146\x6c\x61\162\x65"; }
