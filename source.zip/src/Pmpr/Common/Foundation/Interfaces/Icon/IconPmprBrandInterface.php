<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\57\61\57\142\162\141\156\x64\x2f\160\x6d\160\162\55\x73\155\141\154\x6c"; const aoceigukcccyimew = "\160\x6d\x70\x72\x2f\61\x2f\x62\x72\141\x6e\x64\x2f\x63\154\157\x75\x64\146\154\141\x72\x65"; }
