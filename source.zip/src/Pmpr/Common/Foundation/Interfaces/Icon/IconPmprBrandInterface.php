<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679574c05515f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\162\x2f\61\x2f\142\x72\x61\156\x64\x2f\x70\x6d\x70\162\55\163\x6d\x61\154\x6c"; const aoceigukcccyimew = "\160\155\x70\162\57\61\57\142\x72\141\156\144\x2f\143\x6c\x6f\165\x64\x66\x6c\x61\x72\145"; }
