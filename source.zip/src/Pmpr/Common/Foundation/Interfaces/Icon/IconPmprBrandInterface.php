<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581610eed2f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\57\61\x2f\142\x72\141\x6e\x64\57\x70\x6d\x70\x72\x2d\x73\x6d\x61\154\x6c"; const aoceigukcccyimew = "\160\x6d\160\162\x2f\x31\57\x62\162\x61\x6e\144\57\x63\154\157\x75\x64\x66\x6c\x61\x72\145"; }
