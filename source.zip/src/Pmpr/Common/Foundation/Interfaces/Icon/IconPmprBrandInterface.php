<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a408a2b74             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\57\61\57\142\162\x61\156\x64\x2f\160\155\x70\x72\x2d\163\155\x61\x6c\154"; const aoceigukcccyimew = "\x70\x6d\x70\x72\57\61\57\x62\162\141\156\x64\57\143\x6c\x6f\165\x64\146\x6c\x61\x72\145"; }
