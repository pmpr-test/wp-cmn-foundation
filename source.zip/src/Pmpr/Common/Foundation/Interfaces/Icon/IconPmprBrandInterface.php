<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8ad41a06             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\57\61\57\142\x72\x61\x6e\x64\57\160\155\x70\162\55\x73\155\x61\154\154"; const aoceigukcccyimew = "\x70\x6d\160\162\x2f\x31\57\142\162\x61\x6e\x64\x2f\143\x6c\x6f\x75\144\146\154\x61\x72\145"; }
