<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed815f260e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\x2f\x31\57\x62\x72\141\156\144\57\x70\155\160\x72\55\163\155\x61\154\154"; const aoceigukcccyimew = "\x70\x6d\x70\162\57\x31\57\142\x72\141\156\x64\57\x63\154\x6f\x75\x64\x66\154\141\x72\145"; }
