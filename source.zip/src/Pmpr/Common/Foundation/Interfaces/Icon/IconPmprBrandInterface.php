<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357217e291             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\57\x31\x2f\x62\162\141\x6e\x64\57\160\155\160\162\x2d\x73\155\141\154\154"; const aoceigukcccyimew = "\160\155\160\x72\57\x31\x2f\x62\162\x61\156\x64\57\x63\154\157\x75\x64\x66\154\x61\x72\145"; }
