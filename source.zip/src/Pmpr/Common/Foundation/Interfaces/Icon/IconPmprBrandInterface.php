<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c61c8485             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\x72\x2f\61\57\x62\x72\x61\156\144\x2f\x70\x6d\x70\162\55\x73\x6d\x61\x6c\154"; const aoceigukcccyimew = "\x70\155\160\x72\57\61\57\142\x72\141\156\144\x2f\x63\154\x6f\165\144\146\x6c\141\162\145"; }
