<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e3ee38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\x2f\x31\x2f\142\162\141\x6e\144\x2f\x70\155\x70\162\x2d\x73\155\141\154\x6c"; const aoceigukcccyimew = "\160\x6d\160\162\x2f\x31\x2f\142\162\141\156\x64\57\143\154\x6f\165\x64\146\154\x61\162\x65"; }
