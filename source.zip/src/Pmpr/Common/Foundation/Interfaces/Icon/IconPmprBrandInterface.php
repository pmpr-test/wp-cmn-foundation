<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf5417a8d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\x72\x2f\61\57\142\x72\x61\x6e\144\57\160\155\x70\x72\x2d\x73\155\141\154\154"; const aoceigukcccyimew = "\x70\155\x70\x72\x2f\x31\x2f\142\162\141\x6e\x64\x2f\143\154\157\165\144\146\154\141\x72\145"; }
