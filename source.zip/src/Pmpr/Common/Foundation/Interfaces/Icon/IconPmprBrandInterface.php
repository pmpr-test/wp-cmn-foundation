<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676d4ae089ce3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\x31\57\x62\162\141\156\144\x2f\x70\155\x70\162\x2d\163\155\141\154\154"; const aoceigukcccyimew = "\160\x6d\160\162\57\x31\57\x62\162\x61\156\x64\x2f\143\x6c\157\x75\x64\146\154\141\x72\x65"; }
