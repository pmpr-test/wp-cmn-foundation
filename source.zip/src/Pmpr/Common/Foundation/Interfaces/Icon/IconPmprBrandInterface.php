<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43c6c83e1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\x72\57\x31\x2f\x62\162\x61\x6e\x64\x2f\x70\155\x70\162\55\x73\155\x61\154\154"; const aoceigukcccyimew = "\160\x6d\160\x72\57\61\x2f\142\162\x61\x6e\x64\57\x63\154\x6f\x75\x64\x66\x6c\x61\162\145"; }
