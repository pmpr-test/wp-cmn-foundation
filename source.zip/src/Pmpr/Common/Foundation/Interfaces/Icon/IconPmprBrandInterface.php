<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835e37313             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\x72\x2f\x31\57\x62\162\141\156\x64\x2f\x70\155\160\x72\55\x73\x6d\x61\154\154"; const aoceigukcccyimew = "\160\x6d\160\162\x2f\x31\x2f\142\x72\141\x6e\144\x2f\x63\154\157\165\144\146\154\x61\162\x65"; }
