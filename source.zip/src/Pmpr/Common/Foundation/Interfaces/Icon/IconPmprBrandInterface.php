<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\162\57\x31\57\x62\162\x61\156\x64\57\160\155\x70\162\x2d\x73\155\141\x6c\154"; const aoceigukcccyimew = "\160\155\x70\162\57\x31\57\x62\x72\141\x6e\144\57\x63\x6c\x6f\x75\144\x66\x6c\141\x72\x65"; }
