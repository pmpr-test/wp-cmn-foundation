<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\x2f\x31\57\x62\162\141\156\144\x2f\160\x6d\160\162\x2d\x73\x6d\141\x6c\154"; const aoceigukcccyimew = "\x70\x6d\x70\x72\57\x31\57\142\x72\x61\156\144\57\143\154\157\x75\x64\x66\x6c\141\x72\x65"; }
