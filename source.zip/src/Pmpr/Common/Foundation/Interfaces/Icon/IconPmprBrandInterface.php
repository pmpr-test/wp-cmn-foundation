<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20bada3b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\162\57\61\57\x62\162\x61\156\x64\x2f\160\x6d\x70\162\x2d\163\155\141\154\x6c"; const aoceigukcccyimew = "\160\155\160\162\57\x31\x2f\x62\x72\x61\x6e\144\x2f\x63\154\x6f\x75\x64\x66\154\x61\162\145"; }
