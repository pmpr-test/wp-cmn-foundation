<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051cac7bda7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\x2f\x31\x2f\x62\162\141\x6e\144\57\x70\155\x70\x72\55\163\155\141\x6c\154"; const aoceigukcccyimew = "\160\155\160\x72\57\61\x2f\x62\x72\x61\x6e\144\x2f\143\154\x6f\x75\x64\x66\154\141\x72\145"; }
