<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\57\x31\57\x62\x72\x61\156\x64\57\160\155\160\x72\x2d\163\155\141\154\154"; const aoceigukcccyimew = "\160\155\160\x72\57\61\x2f\142\x72\141\x6e\x64\x2f\143\x6c\x6f\x75\144\146\154\141\x72\145"; }
