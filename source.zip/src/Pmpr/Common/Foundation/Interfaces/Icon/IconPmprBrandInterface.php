<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791524c10e10             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\57\61\x2f\x62\162\x61\x6e\x64\x2f\160\x6d\160\x72\x2d\163\x6d\x61\x6c\154"; const aoceigukcccyimew = "\160\x6d\160\x72\57\x31\x2f\x62\x72\x61\x6e\x64\x2f\x63\154\x6f\x75\144\x66\x6c\x61\x72\145"; }
