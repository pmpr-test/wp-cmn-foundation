<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e295acabc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\162\x2f\61\57\x62\162\x61\156\144\57\160\155\x70\x72\x2d\x73\155\x61\154\x6c"; const aoceigukcccyimew = "\160\x6d\x70\x72\57\61\x2f\142\162\141\x6e\x64\x2f\x63\x6c\x6f\x75\x64\x66\x6c\x61\162\145"; }
