<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679154b81399c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\x72\57\61\57\142\162\141\156\144\57\x70\x6d\160\x72\55\163\155\141\154\154"; const aoceigukcccyimew = "\x70\155\160\162\57\x31\57\142\162\141\156\144\x2f\x63\x6c\x6f\165\x64\x66\154\x61\162\145"; }
