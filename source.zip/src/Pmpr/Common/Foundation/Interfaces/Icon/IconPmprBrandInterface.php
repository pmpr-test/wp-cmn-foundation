<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d8187bb66             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\x72\x2f\x31\57\142\162\x61\x6e\144\57\x70\x6d\160\x72\x2d\163\155\141\154\154"; const aoceigukcccyimew = "\160\155\x70\x72\x2f\x31\x2f\x62\x72\x61\156\144\x2f\143\154\157\x75\144\146\154\141\162\145"; }
