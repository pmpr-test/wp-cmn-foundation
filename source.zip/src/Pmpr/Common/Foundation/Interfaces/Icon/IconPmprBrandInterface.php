<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580c648b6e4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\x72\57\x31\57\142\162\x61\x6e\x64\x2f\x70\155\160\x72\55\163\155\x61\154\x6c"; const aoceigukcccyimew = "\x70\155\x70\162\x2f\x31\x2f\x62\x72\141\156\x64\x2f\x63\154\157\165\144\146\154\x61\162\x65"; }
