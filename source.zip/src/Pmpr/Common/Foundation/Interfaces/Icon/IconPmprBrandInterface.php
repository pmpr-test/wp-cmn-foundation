<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053bb6ecfdb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\x72\x2f\61\x2f\x62\162\x61\156\144\x2f\x70\x6d\x70\162\55\x73\x6d\x61\x6c\x6c"; const aoceigukcccyimew = "\160\155\x70\x72\57\x31\57\x62\x72\x61\x6e\x64\x2f\143\x6c\157\x75\144\x66\x6c\141\162\145"; }
