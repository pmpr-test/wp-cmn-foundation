<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e3816e1675             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\x72\57\61\57\142\162\141\156\144\57\x70\x6d\x70\x72\x2d\163\155\x61\x6c\154"; const aoceigukcccyimew = "\x70\155\160\x72\57\61\57\142\162\x61\x6e\x64\57\x63\x6c\157\x75\x64\146\154\x61\x72\x65"; }
