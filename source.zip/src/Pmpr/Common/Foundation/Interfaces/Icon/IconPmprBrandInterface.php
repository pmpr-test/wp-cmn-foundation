<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77d1b4081             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\57\61\x2f\142\x72\x61\x6e\144\57\x70\155\160\x72\55\x73\155\x61\154\154"; const aoceigukcccyimew = "\x70\155\x70\162\x2f\61\57\x62\x72\141\x6e\144\57\x63\x6c\x6f\165\x64\x66\154\x61\162\145"; }
