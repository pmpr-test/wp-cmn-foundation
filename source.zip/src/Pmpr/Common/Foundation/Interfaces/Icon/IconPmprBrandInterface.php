<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\x72\57\x31\x2f\142\162\141\x6e\x64\57\160\155\x70\x72\55\163\x6d\141\154\154"; const aoceigukcccyimew = "\160\155\160\162\x2f\x31\x2f\142\x72\141\156\x64\57\x63\154\x6f\x75\144\146\x6c\141\162\145"; }
