<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4e36cacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\57\61\57\x62\162\x61\x6e\x64\57\x70\155\160\162\55\163\155\141\x6c\154"; const aoceigukcccyimew = "\x70\155\x70\x72\57\61\x2f\x62\162\141\x6e\144\x2f\x63\154\157\x75\x64\x66\154\141\162\x65"; }
