<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\x72\x2f\61\57\142\162\x61\x6e\x64\57\x70\x6d\x70\x72\55\x73\155\x61\154\154"; const aoceigukcccyimew = "\160\x6d\160\162\57\61\x2f\x62\162\x61\156\x64\x2f\143\x6c\157\165\x64\146\x6c\141\x72\x65"; }
