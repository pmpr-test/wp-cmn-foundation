<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038c53dd59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\57\x31\x2f\x62\162\x61\156\x64\x2f\x70\x6d\x70\x72\x2d\163\x6d\x61\154\154"; const aoceigukcccyimew = "\160\155\160\x72\x2f\x31\57\142\x72\x61\x6e\x64\57\143\154\x6f\x75\x64\x66\154\x61\162\x65"; }
