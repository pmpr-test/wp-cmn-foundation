<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19cd8e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\x72\x2f\61\57\x62\162\141\x6e\x64\57\x70\x6d\160\x72\55\163\155\x61\x6c\154"; const aoceigukcccyimew = "\160\x6d\160\162\57\61\x2f\x62\x72\141\x6e\x64\x2f\143\154\157\165\x64\x66\x6c\141\x72\145"; }
