<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b088f1290             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\x31\57\x62\x72\x61\156\144\57\160\155\x70\x72\55\x73\x6d\141\154\154"; const aoceigukcccyimew = "\160\155\x70\x72\57\x31\57\x62\162\x61\x6e\144\57\x63\154\157\165\144\146\x6c\x61\x72\145"; }
