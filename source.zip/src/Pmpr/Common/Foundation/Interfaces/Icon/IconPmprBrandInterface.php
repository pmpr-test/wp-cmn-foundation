<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d41721935c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\x2f\x31\x2f\142\162\x61\x6e\x64\57\160\155\160\162\x2d\x73\155\141\154\x6c"; const aoceigukcccyimew = "\160\x6d\x70\x72\x2f\x31\57\142\x72\x61\156\x64\57\x63\154\157\x75\x64\146\x6c\141\x72\x65"; }
