<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e55c5a76f1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\x2f\61\x2f\142\162\x61\x6e\x64\57\x70\x6d\x70\x72\55\163\155\141\154\154"; const aoceigukcccyimew = "\x70\155\x70\x72\57\x31\x2f\142\x72\x61\156\x64\57\x63\x6c\157\165\144\146\x6c\x61\x72\145"; }
