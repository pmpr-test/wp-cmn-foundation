<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b645383f9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\57\61\x2f\142\162\x61\156\x64\57\160\155\160\162\x2d\163\155\141\154\154"; const aoceigukcccyimew = "\160\x6d\x70\x72\57\61\x2f\x62\162\x61\156\144\x2f\143\x6c\157\x75\x64\146\x6c\141\x72\x65"; }
