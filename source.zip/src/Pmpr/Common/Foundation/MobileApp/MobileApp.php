<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a37bcbb1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Container { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x68\x74\164\160\x5f\x68\x65\x61\x64\145\x72\x73\x5f\165\x73\x65\162\141\147\x65\x6e\164", [$this, "\155\145\151\x65\x6d\171\151\x6f\x71\x61\151\147\x73\165\143\x73"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
