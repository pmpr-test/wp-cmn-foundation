<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9fd229d29             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Container { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x68\x74\x74\160\x5f\150\145\x61\x64\x65\x72\x73\137\165\x73\x65\x72\x61\x67\145\156\x74", [$this, "\155\x65\151\x65\155\x79\151\x6f\x71\x61\x69\147\163\x75\143\x73"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
