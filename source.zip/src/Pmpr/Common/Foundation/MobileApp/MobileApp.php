<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae859a8f03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Common { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x68\x74\x74\160\137\x68\x65\141\x64\145\x72\163\137\165\163\145\162\141\147\145\156\x74", [$this, "\x6d\145\151\145\155\x79\151\x6f\161\x61\x69\147\x73\x75\143\163"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
