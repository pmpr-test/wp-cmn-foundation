<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679775b18836a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Container { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\150\x74\164\x70\x5f\150\x65\141\144\145\x72\163\x5f\165\163\x65\162\x61\147\145\156\x74", [$this, "\x6d\145\151\145\x6d\171\x69\x6f\x71\x61\151\x67\x73\x75\143\163"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
