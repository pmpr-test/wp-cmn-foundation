<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e295acabc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Traits; trait SettingTrait { public function gsqkwyaueoaeyqqs() { static $qeqooyuoiasweuck; if (!empty($qeqooyuoiasweuck)) { goto aiqouoismmsiakak; } $qeqooyuoiasweuck = $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->get("\164\x69\x63\x6b\x65\164\x5f\x73\145\x74\164\x69\x6e\x67\163", []); aiqouoismmsiakak: return $qeqooyuoiasweuck; } public function qaawomkouwoaoqma(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($this->gsqkwyaueoaeyqqs(), $uusmaiomayssaecw, $ggauoeuaesiymgee); } }
