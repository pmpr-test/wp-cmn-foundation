<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Traits; trait SettingTrait { public function gsqkwyaueoaeyqqs() { static $qeqooyuoiasweuck; if (!empty($qeqooyuoiasweuck)) { goto wiiqigwgyuiuksia; } $qeqooyuoiasweuck = $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->get("\164\151\143\x6b\x65\x74\137\x73\x65\164\164\151\156\147\x73", []); wiiqigwgyuiuksia: return $qeqooyuoiasweuck; } public function qaawomkouwoaoqma(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($this->gsqkwyaueoaeyqqs(), $uusmaiomayssaecw, $ggauoeuaesiymgee); } }
