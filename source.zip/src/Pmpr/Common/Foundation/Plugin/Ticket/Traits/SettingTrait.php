<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Traits; trait SettingTrait { public function gsqkwyaueoaeyqqs() { static $qeqooyuoiasweuck; if (!empty($qeqooyuoiasweuck)) { goto wiiqigwgyuiuksia; } $qeqooyuoiasweuck = $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->get("\164\151\x63\153\x65\x74\137\163\145\x74\164\151\156\147\163", []); wiiqigwgyuiuksia: return $qeqooyuoiasweuck; } public function qaawomkouwoaoqma(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($this->gsqkwyaueoaeyqqs(), $uusmaiomayssaecw, $ggauoeuaesiymgee); } }
