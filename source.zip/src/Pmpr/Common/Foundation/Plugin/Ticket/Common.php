<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132d18d1e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto cskesgswygwiqoim; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ooayswecmkkqgskg; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ooayswecmkkqgskg: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto guyeaeiscmgksacs; cskesgswygwiqoim: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); guyeaeiscmgksacs: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\40\x61\164\x20\45\x73", PR__CMN__FOUNDATION), "\x6a\x20\106\40\x59", "\x48\72\x69"); return $this->iuygowkemiiwqmiw("\143\x6f\156\x76\x65\x72\x73\x61\x74\x69\x6f\156", $iiwuoccgisuaoaka); } }
