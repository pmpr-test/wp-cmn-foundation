<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto acaeigkmigikeuyu; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mciumqyyossyiuyk; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mciumqyyossyiuyk: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto kqyeukywmgismyaq; acaeigkmigikeuyu: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); kqyeukywmgismyaq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\x61\x74\x20\x25\163", PR__CMN__FOUNDATION), "\x6a\x20\106\40\x59", "\110\72\x69"); return $this->iuygowkemiiwqmiw("\143\157\156\166\x65\162\x73\x61\x74\x69\157\x6e", $iiwuoccgisuaoaka); } }
