<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d41721935c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends Container { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); } else { $igwimgwceysgwimw = get_custom_logo(); if (!$igwimgwceysgwimw) { $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); } $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; } $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\40\x61\164\x20\x25\163", PR__CMN__FOUNDATION), "\152\x20\106\x20\131", "\x48\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\157\156\x76\x65\162\163\x61\164\151\x6f\156", $iiwuoccgisuaoaka); } }
