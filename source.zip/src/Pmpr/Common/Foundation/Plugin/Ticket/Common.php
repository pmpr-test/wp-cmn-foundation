<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto cskesgswygwiqoim; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ooayswecmkkqgskg; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ooayswecmkkqgskg: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto guyeaeiscmgksacs; cskesgswygwiqoim: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); guyeaeiscmgksacs: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\x20\x61\x74\40\x25\x73", PR__CMN__FOUNDATION), "\x6a\x20\x46\x20\x59", "\x48\x3a\151"); return $this->iuygowkemiiwqmiw("\143\x6f\x6e\x76\145\162\163\141\x74\x69\157\x6e", $iiwuoccgisuaoaka); } }
