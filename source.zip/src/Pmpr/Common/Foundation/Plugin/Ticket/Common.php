<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705a37ba6a79             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends Container { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); } else { $igwimgwceysgwimw = get_custom_logo(); if (!$igwimgwceysgwimw) { $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); } $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; } $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\x20\141\164\x20\45\163", PR__CMN__FOUNDATION), "\152\40\x46\40\x59", "\110\72\x69"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\166\x65\x72\x73\x61\x74\151\157\156", $iiwuoccgisuaoaka); } }
