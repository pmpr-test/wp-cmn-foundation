<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da680f9db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto agosuskgagmqkcqq; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mqkkmgeccukekuus; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mqkkmgeccukekuus: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto cwuiegmgmaoasqys; agosuskgagmqkcqq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); cwuiegmgmaoasqys: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\141\x74\x20\45\x73", PR__CMN__FOUNDATION), "\x6a\x20\106\40\131", "\110\x3a\x69"); return $this->iuygowkemiiwqmiw("\143\157\156\166\x65\162\163\141\x74\x69\157\x6e", $iiwuoccgisuaoaka); } }
