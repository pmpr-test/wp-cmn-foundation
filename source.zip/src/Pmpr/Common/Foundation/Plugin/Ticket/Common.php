<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77d1b4081             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto cwuiegmgmaoasqys; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto agosuskgagmqkcqq; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); agosuskgagmqkcqq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto oqsgqmmoqoyoicia; cwuiegmgmaoasqys: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); oqsgqmmoqoyoicia: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\x20\141\164\40\45\x73", PR__CMN__FOUNDATION), "\152\x20\x46\x20\131", "\x48\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\x76\x65\x72\163\141\x74\x69\157\x6e", $iiwuoccgisuaoaka); } }
