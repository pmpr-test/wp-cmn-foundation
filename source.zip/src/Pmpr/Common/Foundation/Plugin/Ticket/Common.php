<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b04f73b21             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto mqkkmgeccukekuus; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto oicqseawwmwcgsua; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); oicqseawwmwcgsua: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto agosuskgagmqkcqq; mqkkmgeccukekuus: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); agosuskgagmqkcqq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\40\141\164\40\x25\163", PR__CMN__FOUNDATION), "\152\x20\106\x20\131", "\110\72\x69"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\x76\x65\x72\x73\x61\164\151\157\x6e", $iiwuoccgisuaoaka); } }
