<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ec0c0505             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto cskesgswygwiqoim; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ooayswecmkkqgskg; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ooayswecmkkqgskg: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto guyeaeiscmgksacs; cskesgswygwiqoim: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); guyeaeiscmgksacs: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\x20\x61\164\x20\45\163", PR__CMN__FOUNDATION), "\x6a\40\x46\40\131", "\x48\x3a\x69"); return $this->iuygowkemiiwqmiw("\x63\157\156\x76\x65\x72\x73\x61\x74\151\x6f\x6e", $iiwuoccgisuaoaka); } }
