<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto wsqiqkiucakewgou; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ywsywoumuaykkeaa; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ywsywoumuaykkeaa: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto yaumwqeommqigswq; wsqiqkiucakewgou: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); yaumwqeommqigswq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\x20\141\x74\x20\x25\x73", PR__CMN__FOUNDATION), "\x6a\40\106\40\x59", "\x48\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\x6e\166\145\x72\163\141\164\151\x6f\156", $iiwuoccgisuaoaka); } }
