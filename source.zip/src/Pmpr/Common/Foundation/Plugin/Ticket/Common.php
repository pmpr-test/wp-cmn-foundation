<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d8187bb66             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto imyyokaecggauwca; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mwsogcaisqkoyoyo; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mwsogcaisqkoyoyo: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto iiieosoykaeycaks; imyyokaecggauwca: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); iiieosoykaeycaks: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\x20\141\164\x20\45\163", PR__CMN__FOUNDATION), "\152\x20\106\40\x59", "\x48\72\x69"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\166\x65\x72\163\x61\x74\x69\157\156", $iiwuoccgisuaoaka); } }
