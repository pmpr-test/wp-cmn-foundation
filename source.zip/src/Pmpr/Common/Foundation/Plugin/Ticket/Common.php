<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2e8864db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto aysgkuigyuqqcuae; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto qiygeqkamwuomgie; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); qiygeqkamwuomgie: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto ykyauiwkesygwwyq; aysgkuigyuqqcuae: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); ykyauiwkesygwwyq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\x73\40\x61\x74\x20\x25\x73", PR__CMN__FOUNDATION), "\x6a\x20\106\x20\x59", "\x48\72\x69"); return $this->iuygowkemiiwqmiw("\143\157\156\x76\145\x72\x73\141\164\151\x6f\156", $iiwuoccgisuaoaka); } }
