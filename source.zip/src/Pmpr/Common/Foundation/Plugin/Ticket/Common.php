<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto wsqiqkiucakewgou; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ywsywoumuaykkeaa; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ywsywoumuaykkeaa: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto yaumwqeommqigswq; wsqiqkiucakewgou: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); yaumwqeommqigswq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\x73\x20\141\x74\40\45\163", PR__CMN__FOUNDATION), "\152\x20\x46\40\131", "\110\72\x69"); return $this->iuygowkemiiwqmiw("\143\157\156\166\x65\x72\163\x61\x74\x69\x6f\x6e", $iiwuoccgisuaoaka); } }
