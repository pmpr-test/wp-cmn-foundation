<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19cd8e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto mqkkmgeccukekuus; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto oicqseawwmwcgsua; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); oicqseawwmwcgsua: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto agosuskgagmqkcqq; mqkkmgeccukekuus: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); agosuskgagmqkcqq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\x20\141\164\x20\x25\x73", PR__CMN__FOUNDATION), "\152\40\x46\40\131", "\110\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\166\145\x72\x73\141\164\151\157\156", $iiwuoccgisuaoaka); } }
