<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto gsscqquysycuswow; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto eisoouawyymkasou; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); eisoouawyymkasou: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto uwcgosckamuosimw; gsscqquysycuswow: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); uwcgosckamuosimw: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\x73\x20\x61\x74\x20\x25\163", PR__CMN__FOUNDATION), "\152\40\x46\x20\x59", "\x48\72\x69"); return $this->iuygowkemiiwqmiw("\143\x6f\x6e\166\x65\x72\x73\x61\x74\151\x6f\x6e", $iiwuoccgisuaoaka); } }
