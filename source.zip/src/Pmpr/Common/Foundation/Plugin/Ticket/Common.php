<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto mqkkmgeccukekuus; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto oicqseawwmwcgsua; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); oicqseawwmwcgsua: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto agosuskgagmqkcqq; mqkkmgeccukekuus: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); agosuskgagmqkcqq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\x20\141\x74\40\45\163", PR__CMN__FOUNDATION), "\x6a\x20\x46\40\131", "\110\72\x69"); return $this->iuygowkemiiwqmiw("\143\157\x6e\166\145\162\163\141\x74\151\157\156", $iiwuoccgisuaoaka); } }
