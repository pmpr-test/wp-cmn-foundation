<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6775ab151db83             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends Container { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); } else { $igwimgwceysgwimw = get_custom_logo(); if (!$igwimgwceysgwimw) { $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); } $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; } $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\x20\141\x74\40\x25\x73", PR__CMN__FOUNDATION), "\x6a\40\x46\x20\x59", "\x48\72\151"); return $this->iuygowkemiiwqmiw("\x63\157\x6e\166\x65\162\163\x61\164\x69\157\156", $iiwuoccgisuaoaka); } }
