<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e176fddf2d5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto wsqiqkiucakewgou; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ywsywoumuaykkeaa; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ywsywoumuaykkeaa: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto yaumwqeommqigswq; wsqiqkiucakewgou: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); yaumwqeommqigswq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\x20\141\164\40\x25\x73", PR__CMN__FOUNDATION), "\152\40\106\x20\131", "\110\x3a\x69"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\x76\145\162\x73\141\x74\x69\157\x6e", $iiwuoccgisuaoaka); } }
