<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6052e08a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto oicqseawwmwcgsua; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto iiymmyommkikmyqa; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); iiymmyommkikmyqa: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto mqkkmgeccukekuus; oicqseawwmwcgsua: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); mqkkmgeccukekuus: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\x20\x61\164\x20\x25\x73", PR__CMN__FOUNDATION), "\152\40\106\40\131", "\x48\x3a\x69"); return $this->iuygowkemiiwqmiw("\x63\157\156\x76\x65\x72\x73\141\x74\x69\157\156", $iiwuoccgisuaoaka); } }
