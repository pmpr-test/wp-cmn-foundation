<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517460aacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto moueuekwquacwkok; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto aiiskmcymwiakkgc; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); aiiskmcymwiakkgc: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto cgukcskqwgsmumcy; moueuekwquacwkok: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); cgukcskqwgsmumcy: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\x20\x61\x74\x20\45\x73", PR__CMN__FOUNDATION), "\152\x20\106\40\x59", "\110\72\151"); return $this->iuygowkemiiwqmiw("\143\x6f\x6e\166\x65\162\x73\141\x74\151\157\x6e", $iiwuoccgisuaoaka); } }
