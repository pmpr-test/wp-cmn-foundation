<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto ykyauiwkesygwwyq; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto aysgkuigyuqqcuae; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); aysgkuigyuqqcuae: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto kwacykquqegccocg; ykyauiwkesygwwyq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); kwacykquqegccocg: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\x20\x61\x74\40\x25\163", PR__CMN__FOUNDATION), "\152\x20\x46\40\131", "\110\72\151"); return $this->iuygowkemiiwqmiw("\143\x6f\x6e\166\x65\162\163\x61\164\151\157\156", $iiwuoccgisuaoaka); } }
