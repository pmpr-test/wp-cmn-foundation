<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto uwcgosckamuosimw; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto gsscqquysycuswow; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); gsscqquysycuswow: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto quycsusswssyiqek; uwcgosckamuosimw: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); quycsusswssyiqek: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\141\164\x20\x25\163", PR__CMN__FOUNDATION), "\152\40\x46\x20\x59", "\x48\72\x69"); return $this->iuygowkemiiwqmiw("\143\x6f\156\x76\x65\162\x73\141\x74\x69\x6f\x6e", $iiwuoccgisuaoaka); } }
