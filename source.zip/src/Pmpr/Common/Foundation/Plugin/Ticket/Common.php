<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e76cb0010             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto acaeigkmigikeuyu; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mciumqyyossyiuyk; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mciumqyyossyiuyk: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto kqyeukywmgismyaq; acaeigkmigikeuyu: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); kqyeukywmgismyaq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\40\x61\x74\x20\x25\x73", PR__CMN__FOUNDATION), "\152\x20\106\40\x59", "\110\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\157\x6e\166\145\x72\163\x61\x74\151\x6f\156", $iiwuoccgisuaoaka); } }
