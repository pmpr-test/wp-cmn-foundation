<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43c6c83e1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\160\162\137\164\151\x63\153\145\x74\137\x66\145\164\x63\x68\x5f\143\x6f\156\x66\x69\x67\x75\162\141\164\x69\x6f\156\137\156\157\167"; const gikmesasuuecmiuo = "\x70\x72\137\164\151\143\153\145\164\x5f\146\145\x74\x63\x68\137\143\x6f\156\x66\x69\147\x75\x72\x61\164\151\x6f\156\137\x6d\151\x64\x6e\151\x67\x68\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\160\154\165\147\151\x6e\x5f\x74\151\143\153\x65\x74"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\151\x67\x68\164"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
