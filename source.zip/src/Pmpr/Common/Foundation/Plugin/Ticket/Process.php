<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20bada3b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\160\162\x5f\x74\151\x63\x6b\145\x74\137\146\145\x74\143\x68\x5f\143\157\x6e\146\x69\147\165\x72\x61\x74\x69\157\x6e\137\x6e\x6f\x77"; const gikmesasuuecmiuo = "\x70\x72\137\x74\x69\143\x6b\145\164\137\146\145\x74\x63\150\137\x63\157\156\x66\x69\147\x75\x72\141\164\151\157\156\x5f\155\x69\x64\156\151\x67\x68\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\160\x6c\165\147\151\156\x5f\x74\x69\143\x6b\145\164"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\156\x69\x67\x68\164"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
