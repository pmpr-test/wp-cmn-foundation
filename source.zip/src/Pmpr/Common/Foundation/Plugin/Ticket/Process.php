<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f9903c56c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\x70\162\137\164\x69\143\x6b\x65\164\x5f\x66\145\164\143\x68\137\143\x6f\156\x66\151\147\x75\162\141\x74\x69\157\x6e\137\x6e\x6f\167"; const gikmesasuuecmiuo = "\160\x72\x5f\x74\151\143\153\145\x74\x5f\x66\x65\164\143\x68\x5f\x63\x6f\x6e\x66\x69\x67\x75\162\x61\x74\x69\x6f\156\x5f\155\x69\x64\156\151\x67\150\x74"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\x6c\x75\147\151\156\137\x74\x69\143\x6b\x65\x74"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\147\150\x74"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
