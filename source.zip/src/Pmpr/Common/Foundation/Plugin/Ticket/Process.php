<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791545e8b23b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\160\162\137\164\x69\x63\x6b\145\x74\x5f\x66\145\164\143\150\x5f\x63\x6f\x6e\146\151\x67\165\162\x61\x74\151\157\x6e\x5f\x6e\x6f\x77"; const gikmesasuuecmiuo = "\160\162\x5f\164\151\x63\153\145\x74\137\x66\x65\x74\143\x68\137\x63\x6f\x6e\x66\151\147\x75\x72\x61\164\x69\157\156\x5f\155\151\144\156\x69\x67\x68\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\154\165\x67\x69\156\137\164\x69\x63\x6b\x65\164"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\155\151\144\156\151\x67\x68\x74"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
