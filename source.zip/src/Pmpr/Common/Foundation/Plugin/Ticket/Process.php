<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671248edea456             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\x70\162\137\x74\151\143\153\145\164\x5f\x66\x65\164\x63\150\x5f\143\x6f\x6e\146\151\x67\x75\x72\x61\164\x69\x6f\156\x5f\156\x6f\x77"; const gikmesasuuecmiuo = "\x70\x72\x5f\164\x69\x63\153\145\x74\137\x66\145\x74\x63\150\x5f\x63\x6f\x6e\x66\151\x67\165\x72\x61\x74\x69\x6f\x6e\137\155\x69\x64\x6e\151\x67\x68\x74"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\x6c\x75\x67\151\x6e\x5f\164\x69\143\153\x65\x74"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\x69\x67\x68\164"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
