<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b088f1290             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\x70\x72\x5f\x74\x69\x63\x6b\x65\x74\x5f\x66\145\x74\143\x68\x5f\x63\x6f\x6e\x66\151\147\165\162\x61\164\x69\157\x6e\x5f\x6e\157\167"; const gikmesasuuecmiuo = "\160\x72\x5f\164\x69\x63\153\x65\164\x5f\146\x65\x74\x63\x68\137\x63\x6f\x6e\x66\151\147\165\162\x61\x74\x69\157\x6e\137\155\151\144\x6e\x69\x67\150\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\160\154\165\147\151\x6e\137\164\151\x63\x6b\x65\164"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\x6e\x69\147\x68\164"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
