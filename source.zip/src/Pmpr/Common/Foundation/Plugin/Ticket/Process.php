<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da3200825a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\160\162\137\x74\x69\143\153\x65\164\x5f\x66\145\164\143\x68\x5f\x63\x6f\x6e\146\151\147\x75\162\141\164\151\x6f\x6e\x5f\156\157\167"; const gikmesasuuecmiuo = "\160\x72\x5f\164\151\x63\x6b\145\x74\x5f\x66\x65\164\143\x68\x5f\143\x6f\156\146\151\147\x75\162\x61\x74\151\157\x6e\x5f\x6d\151\144\x6e\x69\147\x68\x74"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\154\165\147\151\156\137\x74\x69\143\153\145\164"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\147\x68\x74"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
