<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835e37313             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\160\162\x5f\x74\151\x63\x6b\x65\x74\137\146\145\x74\x63\150\x5f\143\157\156\x66\151\147\165\x72\141\164\151\x6f\156\x5f\x6e\157\167"; const gikmesasuuecmiuo = "\160\162\x5f\x74\x69\143\x6b\145\x74\x5f\146\x65\x74\143\x68\x5f\143\157\x6e\146\x69\x67\165\x72\141\164\151\x6f\x6e\137\x6d\x69\144\156\151\147\x68\x74"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\160\x6c\x75\147\x69\x6e\137\164\x69\143\153\145\x74"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\156\151\x67\x68\164"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
