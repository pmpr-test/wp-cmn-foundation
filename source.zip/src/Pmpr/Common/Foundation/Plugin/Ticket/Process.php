<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716c8ab6c7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\160\x72\137\x74\151\143\x6b\145\x74\137\x66\x65\164\143\x68\x5f\143\x6f\x6e\x66\x69\147\x75\162\141\164\x69\x6f\156\137\156\157\167"; const gikmesasuuecmiuo = "\x70\x72\137\164\x69\x63\153\x65\164\x5f\x66\145\x74\x63\150\137\x63\157\x6e\146\151\x67\x75\162\x61\164\x69\x6f\156\x5f\155\x69\x64\x6e\x69\147\150\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\160\x6c\165\x67\151\x6e\x5f\x74\x69\143\153\x65\x74"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\156\151\147\150\x74"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
