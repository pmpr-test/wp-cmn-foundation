<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbcd2165a5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\x70\x72\x5f\164\x69\x63\x6b\x65\x74\x5f\146\x65\164\x63\x68\x5f\143\157\156\146\x69\147\165\162\x61\x74\151\x6f\156\x5f\x6e\157\167"; const gikmesasuuecmiuo = "\160\162\x5f\164\x69\x63\x6b\x65\x74\137\x66\x65\x74\143\x68\137\x63\x6f\156\146\151\x67\x75\x72\141\x74\151\x6f\156\x5f\x6d\151\144\x6e\151\147\x68\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\160\x6c\165\x67\x69\156\137\164\151\x63\x6b\145\164"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\156\151\147\x68\164"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
