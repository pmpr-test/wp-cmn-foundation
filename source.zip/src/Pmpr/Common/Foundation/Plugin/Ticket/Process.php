<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a37bcbb1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\x70\x72\137\164\x69\x63\x6b\145\x74\137\146\x65\x74\x63\150\137\143\157\156\146\x69\x67\165\x72\141\x74\x69\157\x6e\x5f\x6e\157\x77"; const gikmesasuuecmiuo = "\x70\x72\x5f\x74\151\143\153\x65\x74\137\x66\x65\x74\x63\x68\x5f\x63\157\x6e\146\x69\147\x75\162\x61\x74\151\157\x6e\137\x6d\x69\144\x6e\x69\147\x68\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\x6c\x75\147\151\x6e\137\164\151\143\153\x65\x74"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\x6e\x69\147\x68\x74"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
