<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c9bc679             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends Model { use SettingTrait; const yeaekcacwwyyqigq = "\164\151\x63\153\145\164"; const asywgyemkouimocw = self::yeaekcacwwyyqigq . Constants::mswocgcucqoaesaa; public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::IDENTIFIER)->gswweykyogmsyawy(__("\x49\144\x65\156\164\x69\146\x69\145\162", PR__CMN__FOUNDATION))->acokiqqgsmoqaeyu()); parent::uwmqacgewuauagai(); } }
