<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abcde521502             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends Model { use SettingTrait; const yeaekcacwwyyqigq = "\x74\151\x63\x6b\x65\x74"; const asywgyemkouimocw = self::yeaekcacwwyyqigq . Constants::mswocgcucqoaesaa; public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::IDENTIFIER)->gswweykyogmsyawy(__("\x49\144\145\x6e\x74\x69\x66\x69\145\162", PR__CMN__FOUNDATION))->acokiqqgsmoqaeyu()); parent::uwmqacgewuauagai(); } }
