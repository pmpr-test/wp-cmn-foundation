<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c72e8c2b8c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { public function register() { $this->saemoowcasogykak(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__('Response', PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__('Responses', PR__CMN__FOUNDATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->gswweykyogmsyawy(__('Responder', PR__CMN__FOUNDATION))->acceqyqygswoecwe(8)); } }
