<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fd4e8b59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { public function register() { $this->saemoowcasogykak(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\122\x65\163\x70\157\156\x73\x65", PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__("\122\x65\163\160\x6f\x6e\163\x65\x73", PR__CMN__FOUNDATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->gswweykyogmsyawy(__("\x52\x65\x73\160\157\156\144\145\x72", PR__CMN__FOUNDATION))->acceqyqygswoecwe(8)); } }
