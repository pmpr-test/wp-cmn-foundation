<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9f11bf9d9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { public function register() { $this->saemoowcasogykak(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x52\x65\x73\160\157\156\x73\x65", PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__("\122\x65\x73\160\157\x6e\x73\x65\x73", PR__CMN__FOUNDATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->gswweykyogmsyawy(__("\122\x65\x73\x70\157\156\x64\145\x72", PR__CMN__FOUNDATION))->acceqyqygswoecwe(8)); } }
