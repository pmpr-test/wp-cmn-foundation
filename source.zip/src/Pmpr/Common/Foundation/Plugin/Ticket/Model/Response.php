<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6052e08a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\122\145\163\160\157\x6e\x73\145", PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__("\122\x65\x73\x70\157\156\x73\145\x73", PR__CMN__FOUNDATION)); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\122\145\163\160\x6f\156\144\x65\x72", PR__CMN__FOUNDATION))); } }
