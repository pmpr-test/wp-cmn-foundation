<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class AbstractResponse extends Common { const asywgyemkouimocw = "\x74\151\143\153\145\164" . Constants::mswocgcucqoaesaa; public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->esoauokkgywesoku([Constants::cqycgsyykemiygou => __("\101\x74\x74\141\143\x68\155\x65\x6e\164", PR__CMN__FOUNDATION)]); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\170\x74", PR__CMN__FOUNDATION)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\124\151\x63\153\145\x74", PR__CMN__FOUNDATION))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg)); parent::ewaqwooqoqmcoomi(); } }
