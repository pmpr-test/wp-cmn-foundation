<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522aeb59a71             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class AbstractResponse extends Common { const asywgyemkouimocw = "\x74\151\143\x6b\145\x74" . Constants::mswocgcucqoaesaa; public function register() { $this->esoauokkgywesoku(Constants::cqycgsyykemiygou, __("\x41\x74\164\141\x63\150\x6d\145\x6e\164", PR__CMN__FOUNDATION)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__CMN__FOUNDATION)))->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\x54\x69\x63\153\145\164", PR__CMN__FOUNDATION))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg))->cquokmemekqqywgi($eqwoegegiamegqsm->qwwuoqeeiyuoyogs(Constants::CREATED_AT)->gswweykyogmsyawy(__("\x54\151\143\x6b\x65\164", PR__CMN__FOUNDATION))->qcqeqimisiisswky()); parent::uwmqacgewuauagai(); } }
