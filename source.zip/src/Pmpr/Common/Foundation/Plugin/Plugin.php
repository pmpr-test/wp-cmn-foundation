<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Common { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
