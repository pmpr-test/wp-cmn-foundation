<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692c4d6560c58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Container { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
