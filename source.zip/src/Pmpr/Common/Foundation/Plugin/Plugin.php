<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681a830bb14c7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Container { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
