<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689e5f3b0a1df             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Container { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
