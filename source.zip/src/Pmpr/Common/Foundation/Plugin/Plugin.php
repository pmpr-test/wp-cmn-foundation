<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843e9f78fb1e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Container { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
