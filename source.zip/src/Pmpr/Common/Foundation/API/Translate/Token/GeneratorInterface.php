<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             699079521cb94             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\API\Translate\Token; interface GeneratorInterface { }
