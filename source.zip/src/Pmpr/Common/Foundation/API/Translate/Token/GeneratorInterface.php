<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6879718a795ce             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\API\Translate\Token; interface GeneratorInterface { }
