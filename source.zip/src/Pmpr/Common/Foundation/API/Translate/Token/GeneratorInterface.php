<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687972581cbc2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\API\Translate\Token; interface GeneratorInterface { }
