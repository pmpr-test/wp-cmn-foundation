<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e3ee38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Traits\FieldsTrait; use Pmpr\Common\Foundation\FormGenerator\Traits\StepTrait; class Step extends Component { use StepTrait, FieldsTrait; public function qiccuiwooiquycsg() { $this->templateClass = self::class; $this->esmoocwowesymqma(); parent::qiccuiwooiquycsg(); } private function cyeuiyggkcqmoecc(?string $meqocwsecsywiiqs, ?string $uusmaiomayssaecw) : ?Button { $gskauacumcmekigs = null; if ($meqocwsecsywiiqs) { $gskauacumcmekigs = $this->qoeiescseggagsqs($uusmaiomayssaecw)->gswweykyogmsyawy($meqocwsecsywiiqs)->qiqckusosoksgaua()->ckccqugcgucieugo()->eskgwaywimqcwcyy("\155\165\x6c\164\151\x73\164\145\x70\x2d\164\x79\160\x65", "\141\x63\x74\x69\157\x6e\55{$uusmaiomayssaecw}"); } return $gskauacumcmekigs; } }
