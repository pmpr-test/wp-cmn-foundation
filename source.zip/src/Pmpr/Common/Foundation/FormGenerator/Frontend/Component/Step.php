<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835e37313             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Traits\FieldsTrait; use Pmpr\Common\Foundation\FormGenerator\Traits\StepTrait; class Step extends Component { use StepTrait, FieldsTrait; public function qiccuiwooiquycsg() { $this->templateClass = self::class; $this->esmoocwowesymqma(); parent::qiccuiwooiquycsg(); } private function cyeuiyggkcqmoecc(?string $meqocwsecsywiiqs, ?string $uusmaiomayssaecw) : ?Button { $gskauacumcmekigs = null; if ($meqocwsecsywiiqs) { $gskauacumcmekigs = $this->qoeiescseggagsqs($uusmaiomayssaecw)->gswweykyogmsyawy($meqocwsecsywiiqs)->qiqckusosoksgaua()->ckccqugcgucieugo()->eskgwaywimqcwcyy("\155\x75\x6c\x74\151\163\164\145\x70\55\x74\171\160\x65", "\x61\x63\164\151\157\x6e\x2d{$uusmaiomayssaecw}"); } return $gskauacumcmekigs; } }
