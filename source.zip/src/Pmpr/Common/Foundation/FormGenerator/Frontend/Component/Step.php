<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689bb2a7583a7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Traits\FieldsTrait; use Pmpr\Common\Foundation\FormGenerator\Traits\StepTrait; class Step extends Component { use StepTrait, FieldsTrait; public function qiccuiwooiquycsg() { $this->templateClass = self::class; $this->esmoocwowesymqma(); parent::qiccuiwooiquycsg(); } private function cyeuiyggkcqmoecc(?string $meqocwsecsywiiqs, ?string $uusmaiomayssaecw) : ?Button { $gskauacumcmekigs = null; if ($meqocwsecsywiiqs) { $gskauacumcmekigs = $this->qoeiescseggagsqs($uusmaiomayssaecw)->gswweykyogmsyawy($meqocwsecsywiiqs)->qiqckusosoksgaua()->ckccqugcgucieugo()->eskgwaywimqcwcyy('multistep-type', "action-{$uusmaiomayssaecw}"); } return $gskauacumcmekigs; } }
