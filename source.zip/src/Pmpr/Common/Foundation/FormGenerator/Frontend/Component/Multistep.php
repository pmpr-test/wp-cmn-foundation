<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\154\x74\151\x73\x74\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\x2d\x6d\x75\x6c\164\151\163\164\145\160\55\167\162\141\x70"); parent::qiccuiwooiquycsg(); } }
