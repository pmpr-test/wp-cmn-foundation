<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d08e0f3960             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\x74\x69\163\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\x6d\165\x6c\x74\x69\x73\x74\145\160\x2d\167\x72\141\160"); parent::qiccuiwooiquycsg(); } }
