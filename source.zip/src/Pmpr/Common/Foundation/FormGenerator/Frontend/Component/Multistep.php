<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\154\x74\151\163\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\x2d\155\x75\154\164\x69\x73\164\x65\x70\55\x77\x72\141\160"); parent::qiccuiwooiquycsg(); } }
