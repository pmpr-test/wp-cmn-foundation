<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20bada3b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\164\151\163\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\x2d\x6d\x75\154\x74\151\163\x74\x65\160\55\167\x72\x61\x70"); parent::qiccuiwooiquycsg(); } }
