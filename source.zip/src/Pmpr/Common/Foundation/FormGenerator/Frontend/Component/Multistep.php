<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb8ecec23             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\164\151\163\x74\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\x2d\x6d\165\x6c\x74\151\163\164\x65\x70\x2d\167\x72\141\x70"); parent::qiccuiwooiquycsg(); } }
