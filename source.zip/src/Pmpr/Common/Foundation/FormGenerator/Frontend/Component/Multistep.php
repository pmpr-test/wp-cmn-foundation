<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\x6c\164\151\x73\x74\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\x6d\165\154\164\x69\163\164\145\x70\55\167\162\x61\x70"); parent::qiccuiwooiquycsg(); } }
