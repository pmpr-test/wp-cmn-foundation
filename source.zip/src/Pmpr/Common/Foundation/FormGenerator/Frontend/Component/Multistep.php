<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da3806785e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\154\164\x69\x73\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\55\155\165\154\x74\x69\x73\164\145\160\55\167\x72\141\x70"); parent::qiccuiwooiquycsg(); } }
