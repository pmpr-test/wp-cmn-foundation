<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192c055a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\154\164\x69\x73\x74\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\x2d\x6d\x75\x6c\x74\x69\163\x74\145\160\x2d\x77\x72\141\160"); parent::qiccuiwooiquycsg(); } }
