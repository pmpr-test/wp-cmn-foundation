<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d87febf6a7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\x6c\x74\151\x73\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\55\x6d\x75\x6c\x74\x69\163\x74\145\160\55\x77\162\x61\x70"); parent::qiccuiwooiquycsg(); } }
