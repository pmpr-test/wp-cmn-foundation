<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791545e8b23b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\x6c\164\x69\163\164\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\55\x6d\x75\154\x74\x69\x73\x74\x65\160\55\167\x72\x61\x70"); parent::qiccuiwooiquycsg(); } }
