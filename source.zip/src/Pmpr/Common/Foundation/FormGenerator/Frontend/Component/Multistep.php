<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c8774d14             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\154\164\151\163\164\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\x2d\x6d\x75\154\164\x69\x73\x74\x65\x70\x2d\167\x72\141\x70"); parent::qiccuiwooiquycsg(); } }
