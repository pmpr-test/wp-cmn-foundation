<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\154\x74\x69\163\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\x6d\x75\x6c\x74\151\x73\164\x65\160\55\x77\162\x61\160"); parent::qiccuiwooiquycsg(); } }
