<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8540fef             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\154\164\151\163\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\55\155\165\x6c\164\x69\163\164\x65\160\55\167\162\x61\160"); parent::qiccuiwooiquycsg(); } }
