<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522aeb59a71             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\x6c\x74\151\x73\164\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\155\165\x6c\x74\151\163\x74\145\160\x2d\x77\x72\141\160"); parent::qiccuiwooiquycsg(); } }
