<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053bb6ecfdb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\x74\x69\x73\164\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\x2d\x6d\x75\x6c\164\151\x73\x74\x65\160\55\x77\x72\x61\160"); parent::qiccuiwooiquycsg(); } }
