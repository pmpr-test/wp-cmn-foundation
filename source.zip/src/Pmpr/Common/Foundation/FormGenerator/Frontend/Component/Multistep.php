<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\154\164\151\x73\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\55\155\165\x6c\x74\x69\x73\x74\145\x70\x2d\167\162\141\160"); parent::qiccuiwooiquycsg(); } }
