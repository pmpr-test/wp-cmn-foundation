<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2ce2062a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\x74\151\x73\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\55\155\165\x6c\164\151\x73\164\145\160\x2d\x77\162\141\160"); parent::qiccuiwooiquycsg(); } }
