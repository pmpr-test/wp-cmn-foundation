<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132d18d1e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\x6c\x74\151\x73\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\55\x6d\x75\x6c\x74\151\x73\164\x65\x70\55\x77\x72\x61\x70"); parent::qiccuiwooiquycsg(); } }
