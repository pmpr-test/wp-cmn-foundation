<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdd41716df             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\x74\x69\163\164\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\155\x75\154\164\x69\163\164\145\x70\x2d\167\162\x61\x70"); parent::qiccuiwooiquycsg(); } }
