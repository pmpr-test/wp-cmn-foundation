<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6776ec4d79b1c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\154\164\151\163\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\155\165\154\x74\x69\163\164\145\160\55\x77\162\x61\x70"); parent::qiccuiwooiquycsg(); } }
