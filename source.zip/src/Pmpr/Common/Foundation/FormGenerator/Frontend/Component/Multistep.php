<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\x6c\164\151\x73\164\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\x2d\x6d\165\x6c\x74\x69\x73\164\145\x70\55\x77\x72\141\x70"); parent::qiccuiwooiquycsg(); } }
