<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e17b763d23d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\x6c\x74\151\163\x74\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\x2d\155\x75\x6c\164\x69\163\x74\145\x70\x2d\x77\162\x61\x70"); parent::qiccuiwooiquycsg(); } }
