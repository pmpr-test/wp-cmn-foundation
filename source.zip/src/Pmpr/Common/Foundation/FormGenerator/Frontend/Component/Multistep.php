<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\x6c\164\x69\x73\x74\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\x2d\x6d\x75\x6c\x74\x69\163\x74\x65\x70\x2d\x77\x72\141\160"); parent::qiccuiwooiquycsg(); } }
