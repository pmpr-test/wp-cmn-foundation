<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f9903c56c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\x6c\164\x69\163\x74\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\x6d\x75\154\164\x69\x73\x74\145\160\55\x77\x72\x61\160"); parent::qiccuiwooiquycsg(); } }
