<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b088f1290             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\x6c\x74\x69\163\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\55\155\x75\154\164\x69\x73\164\x65\160\55\x77\162\141\x70"); parent::qiccuiwooiquycsg(); } }
