<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beb88b904             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\x6c\164\151\163\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\x2d\x6d\165\154\x74\x69\163\x74\145\x70\x2d\x77\162\141\x70"); parent::qiccuiwooiquycsg(); } }
