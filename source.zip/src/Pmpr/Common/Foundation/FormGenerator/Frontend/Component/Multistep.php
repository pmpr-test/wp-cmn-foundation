<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\154\164\x69\x73\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\155\x75\154\164\151\x73\164\145\x70\x2d\x77\162\141\160"); parent::qiccuiwooiquycsg(); } }
