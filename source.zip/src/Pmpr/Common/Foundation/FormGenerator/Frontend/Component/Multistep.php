<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052a91f300e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\x6c\164\151\163\x74\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\x2d\155\x75\x6c\x74\x69\163\x74\x65\x70\x2d\167\162\x61\160"); parent::qiccuiwooiquycsg(); } }
