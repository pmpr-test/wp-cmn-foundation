<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d13e4bc148             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\x6c\164\151\x73\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\55\155\165\154\164\151\x73\x74\145\160\x2d\x77\x72\x61\x70"); parent::qiccuiwooiquycsg(); } }
