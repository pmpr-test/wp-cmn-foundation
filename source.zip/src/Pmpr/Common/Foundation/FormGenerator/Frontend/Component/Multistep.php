<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\154\164\x69\x73\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\55\x6d\165\154\x74\151\163\x74\145\160\55\x77\162\x61\160"); parent::qiccuiwooiquycsg(); } }
