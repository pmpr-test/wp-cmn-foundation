<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a6c2def5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\154\x74\x69\x73\164\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\55\155\x75\154\164\x69\163\x74\145\x70\x2d\x77\162\141\160"); parent::qiccuiwooiquycsg(); } }
