<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051cac7bda7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\x6c\164\151\163\x74\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\x2d\155\165\x6c\164\151\x73\164\145\x70\55\x77\162\141\x70"); parent::qiccuiwooiquycsg(); } }
