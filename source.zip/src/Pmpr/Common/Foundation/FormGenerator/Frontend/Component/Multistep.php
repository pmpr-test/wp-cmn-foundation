<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d585ed47eb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\154\x74\x69\x73\164\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\x2d\x6d\x75\154\164\151\x73\164\145\160\x2d\x77\162\141\160"); parent::qiccuiwooiquycsg(); } }
