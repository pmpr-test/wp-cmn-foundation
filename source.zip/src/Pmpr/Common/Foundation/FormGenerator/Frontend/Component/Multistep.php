<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4df75a3df             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\x74\151\x73\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\x2d\x6d\x75\154\164\151\x73\x74\145\x70\x2d\x77\x72\141\160"); parent::qiccuiwooiquycsg(); } }
