<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2bc642b374             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\FormGenerator; use Pmpr\Common\Foundation\Interfaces\Constants; class Radio extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::imigwosicasiemwu); $this->askmmuauqcuuqsea('Radio')->uekikuwmokqsqoga(Constants::soqecysmeyiyyyys)->kakecegieeqyyayu()->qigsyyqgewgskemg('form-group'); $this->enqueue(); } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) : self { $this->qcgocuceocquqcuw(Constants::ciyoccqkiamemcmm, $eqgoocgaqwqcimie); return parent::iygyugseyaqwywyg($eqgoocgaqwqcimie); } public function enqueue() { $this->caokeucsksukesyo()->usugyumcgeaaowsi()->asqsuswyqyoecwcc(); } }
