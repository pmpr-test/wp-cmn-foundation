<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac859a97153             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\FieldsTrait; class Collection extends Field { use FieldsTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'collection'); $this->askmmuauqcuuqsea('Collection'); } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) : self { if (is_string($eqgoocgaqwqcimie) && str_contains($eqgoocgaqwqcimie, self::wcmoyuggmesegmcy)) { $eqgoocgaqwqcimie = []; } return parent::iygyugseyaqwywyg($eqgoocgaqwqcimie); } public function oockkqiqsssakuug(array $ywmkwiwkosakssii = []) : string { return ''; } }
