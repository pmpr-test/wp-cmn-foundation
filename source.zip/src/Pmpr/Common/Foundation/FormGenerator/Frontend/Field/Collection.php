<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687f52d68f1ed             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\FieldsTrait; class Collection extends Field { use FieldsTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'collection'); $this->askmmuauqcuuqsea('Collection'); } }
