<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             699992963e388             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\OptionsTrait; class OptionAware extends Field { use OptionsTrait; }
