<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a385ff8460c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Markup extends Field { protected ?string $content = null; public function __construct(string $aokagokqyuysuksm = '', string $sqeykgyoooqysmca = '') { if (!$sqeykgyoooqysmca) { $sqeykgyoooqysmca = Constants::kicoscymgmgqeqgy; } if (!$aokagokqyuysuksm) { $aokagokqyuysuksm = $sqeykgyoooqysmca . '_' . $this->caokeucsksukesyo()->owgcciayoweymuws()->uniqid(); } $this->askmmuauqcuuqsea('Markup'); $this->storable = false; parent::__construct($aokagokqyuysuksm, $sqeykgyoooqysmca); } public function oguessuismosauuu(?string $ewgwqamkygiqaawc) : self { $this->content = $ewgwqamkygiqaawc; return $this; } }
