<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a408a2b74             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Markup extends Field { protected ?string $content = null; public function __construct(string $aokagokqyuysuksm = '', string $sqeykgyoooqysmca = '') { if ($aokagokqyuysuksm) { goto wskuiymiemyqssui; } $aokagokqyuysuksm = "\155\141\162\153\x75\160\x5f" . $this->caokeucsksukesyo()->owgcciayoweymuws()->uniqid(); wskuiymiemyqssui: if ($sqeykgyoooqysmca) { goto muoaaecywcccquoa; } $sqeykgyoooqysmca = Constants::kicoscymgmgqeqgy; muoaaecywcccquoa: $this->storable = false; parent::__construct($aokagokqyuysuksm, $sqeykgyoooqysmca); } public function oguessuismosauuu(?string $ewgwqamkygiqaawc) : self { $this->content = $ewgwqamkygiqaawc; return $this; } }
