<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Markup extends Field { protected ?string $content = null; public function __construct(string $aokagokqyuysuksm = '', string $sqeykgyoooqysmca = '') { if ($aokagokqyuysuksm) { goto toacieymkgsmouum; } $aokagokqyuysuksm = "\x6d\141\162\153\165\160\137" . $this->caokeucsksukesyo()->owgcciayoweymuws()->uniqid(); toacieymkgsmouum: if ($sqeykgyoooqysmca) { goto uooyycimwyiscwik; } $sqeykgyoooqysmca = Constants::kicoscymgmgqeqgy; uooyycimwyiscwik: $this->storable = false; parent::__construct($aokagokqyuysuksm, $sqeykgyoooqysmca); } public function oguessuismosauuu(?string $ewgwqamkygiqaawc) : self { $this->content = $ewgwqamkygiqaawc; return $this; } }
