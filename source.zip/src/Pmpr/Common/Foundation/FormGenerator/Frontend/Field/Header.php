<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4dd44a5fc0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Header extends Markup { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'header'); $this->askmmuauqcuuqsea('Header'); } }
