<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687f52d68f1ed             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Header extends Markup { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'header'); $this->askmmuauqcuuqsea('Header'); } }
