<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679775b18836a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); $this->qigsyyqgewgskemg("\x66\157\x72\155\55\143\157\x6e\164\x72\x6f\x6c")->askmmuauqcuuqsea("\x54\145\x78\164\x61\162\x65\141")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\162\155\55\x67\x72\x6f\x75\160"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->igmaewykumgwoaoy("\162\157\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function uqamgcwceyasmoki(int $essikcmqiyqaqoaq = 2) : self { $this->qigsyyqgewgskemg(sprintf("\x68\55\x25\x64\x70\x78", 100 * $essikcmqiyqaqoaq)); return parent::uqamgcwceyasmoki(); } }
