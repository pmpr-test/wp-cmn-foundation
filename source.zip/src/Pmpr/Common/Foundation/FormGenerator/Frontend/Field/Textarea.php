<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a92bf092             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); $this->qigsyyqgewgskemg("\146\x6f\162\x6d\55\143\157\156\164\162\157\154")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\x72\155\x2d\x67\162\157\165\x70"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->igmaewykumgwoaoy("\162\157\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function uqamgcwceyasmoki(int $essikcmqiyqaqoaq = 2) : self { $this->qigsyyqgewgskemg(sprintf("\x68\x2d\45\x64\160\x78", 100 * $essikcmqiyqaqoaq)); return parent::uqamgcwceyasmoki(); } }
