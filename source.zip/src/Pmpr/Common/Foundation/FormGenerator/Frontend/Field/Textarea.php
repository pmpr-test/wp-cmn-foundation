<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671269d6639fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); $this->qigsyyqgewgskemg("\146\x6f\x72\x6d\x2d\143\157\156\x74\162\157\x6c")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\162\x6d\55\x67\162\157\x75\x70"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->igmaewykumgwoaoy("\x72\157\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function uqamgcwceyasmoki(int $essikcmqiyqaqoaq = 2) : self { $this->qigsyyqgewgskemg(sprintf("\x68\55\x25\144\x70\170", 100 * $essikcmqiyqaqoaq)); return parent::uqamgcwceyasmoki(); } }
