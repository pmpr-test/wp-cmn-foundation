<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689a2357e3efe             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Hidden extends Input { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); $this->ssseuumiskesuiss(); } public function mawcogsqogkauasq(?string $aiamqeawckcsuaou = null) : self { if (!$aiamqeawckcsuaou) { $aiamqeawckcsuaou = $this->aakmagwggmkoiiyu(); } $this->iygyugseyaqwywyg($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ikkqcccaweckukug($aiamqeawckcsuaou)); return $this; } }
