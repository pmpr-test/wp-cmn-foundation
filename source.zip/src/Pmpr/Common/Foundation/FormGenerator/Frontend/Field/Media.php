<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692d5bd30521c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Media extends File { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->askmmuauqcuuqsea('Media'); } public function kogekgsaaqoeosuc(array $yemgmmgogcwccuky = []) : self { return $this->hsgemasguekogiui(['jpg', 'jpeg', 'webp'], 'image', $yemgmmgogcwccuky); } }
