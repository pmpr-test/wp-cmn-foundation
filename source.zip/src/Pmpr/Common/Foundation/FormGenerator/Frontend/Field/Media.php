<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Media extends File { public function scmsukieucuekmki() : self { $this->ycueqsmmommygueu(); return $this->askmmuauqcuuqsea("\x41\166\x61\164\141\162"); } public function ycueqsmmommygueu(array $yemgmmgogcwccuky = []) : self { return $this->hsgemasguekogiui(["\x6a\160\x67", "\152\160\145\x67", "\x77\145\x62\x70"], "\x69\x6d\x61\147\x65", $yemgmmgogcwccuky); } }
