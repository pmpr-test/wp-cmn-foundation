<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67955288a0e50             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg("\x66\157\x72\155\x2d\x63\157\156\x74\x72\157\x6c")->askmmuauqcuuqsea("\x54\x72\145\145\x53\x65\x6c\x65\x63\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\162\x6d\55\x67\x72\157\x75\160"); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw("\155\165\x6c\x74\x69\x70\154\145", "\155\x75\x6c\164\151\x70\x6c\x65"); return $this->igiywquyccyiaucw("\x6d\x75\x6c\x74\151\160\154\145", true); } }
