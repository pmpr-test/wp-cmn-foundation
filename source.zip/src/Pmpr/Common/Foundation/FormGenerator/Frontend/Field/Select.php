<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6794e7648968d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg("\146\157\162\155\x2d\x63\157\x6e\x74\162\157\x6c")->askmmuauqcuuqsea("\124\x72\145\145\123\x65\x6c\145\143\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\x72\155\x2d\x67\x72\x6f\x75\160"); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw("\155\165\x6c\164\x69\160\x6c\x65", "\x6d\165\154\164\151\x70\154\145"); return $this->igiywquyccyiaucw("\155\165\x6c\164\151\160\154\x65", true); } }
