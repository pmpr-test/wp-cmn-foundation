<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977684bcc9f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg("\x66\157\x72\x6d\x2d\143\157\x6e\x74\x72\157\x6c")->askmmuauqcuuqsea("\124\x72\x65\145\x53\145\x6c\145\x63\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\x72\x6d\x2d\x67\162\x6f\165\x70"); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw("\155\165\154\164\151\x70\x6c\145", "\x6d\165\154\164\151\x70\x6c\145"); return $this->igiywquyccyiaucw("\155\x75\154\x74\151\160\154\145", true); } }
