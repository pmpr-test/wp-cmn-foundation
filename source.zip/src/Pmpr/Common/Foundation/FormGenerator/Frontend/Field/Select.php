<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffe229367             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg("\x66\x6f\162\155\55\143\157\x6e\164\x72\157\x6c")->askmmuauqcuuqsea("\124\x72\x65\x65\123\x65\x6c\145\143\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\x6f\162\155\55\x67\162\157\x75\160"); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw("\x6d\165\154\x74\151\x70\154\x65", "\155\x75\x6c\x74\151\x70\154\145"); return $this->igiywquyccyiaucw("\x6d\165\x6c\164\x69\x70\154\145", true); } }
