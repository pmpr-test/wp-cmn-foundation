<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679775b18836a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg("\146\x6f\162\155\x2d\143\x6f\x6e\164\162\x6f\x6c")->askmmuauqcuuqsea("\124\x72\x65\x65\123\x65\x6c\145\143\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\162\x6d\55\x67\162\x6f\165\x70"); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw("\x6d\165\x6c\164\x69\160\x6c\x65", "\155\165\x6c\x74\x69\x70\154\145"); return $this->igiywquyccyiaucw("\x6d\x75\154\x74\x69\x70\154\x65", true); } }
