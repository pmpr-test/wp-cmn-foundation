<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e3ee38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg("\x66\x6f\162\x6d\x2d\x63\157\156\164\x72\x6f\x6c")->askmmuauqcuuqsea("\124\x72\x65\x65\123\145\x6c\145\143\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\162\155\55\147\162\x6f\165\160"); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw("\x6d\165\x6c\x74\151\160\x6c\145", "\155\165\x6c\164\x69\x70\154\145"); return $this->igiywquyccyiaucw("\155\x75\154\164\151\160\x6c\x65", true); } }
