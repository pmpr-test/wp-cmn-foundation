<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a66ea14a389             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Nonce extends Input { public function __construct(?string $aokagokqyuysuksm) { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); } public function uwaiagiwycmiokqi(?string $aiamqeawckcsuaou = '', ?string $ymqmyyeuycgmigyo = '') : self { $this->kakecegieeqyyayu()->eskgwaywimqcwcyy(Constants::NAME, $ymqmyyeuycgmigyo)->eskgwaywimqcwcyy(Constants::uqgcmmosieyimiku, $aiamqeawckcsuaou)->qigsyyqgewgskemg('nonce-container'); return $this; } public function vkwmugmaqcawygqm(string $aiamqeawckcsuaou, string $ymqmyyeuycgmigyo = Constants::icwieiwoqeocywss, bool $emaumsqyoyqcimcm = true) : self { $gwgqcsmomamyqsmy = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc($aiamqeawckcsuaou, $ymqmyyeuycgmigyo, $emaumsqyoyqcimcm, false); $this->igiywquyccyiaucw(Constants::oomaageiyqkaiekk, $gwgqcsmomamyqsmy); return $this; } }
