<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581610eed2f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\157\162\155\55\143\x6f\156\x74\x72\x6f\154")->askmmuauqcuuqsea("\x54\145\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\162\155\55\x67\x72\157\165\x70"); } }
