<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\162\155\55\x63\x6f\x6e\164\x72\157\154")->askmmuauqcuuqsea("\124\x65\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\x72\x6d\x2d\x67\x72\x6f\165\x70"); } }
