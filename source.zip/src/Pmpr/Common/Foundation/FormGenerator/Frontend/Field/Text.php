<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\x72\155\55\143\x6f\x6e\164\x72\157\x6c")->askmmuauqcuuqsea("\124\145\170\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\x6f\x72\155\55\x67\162\157\x75\160"); } }
