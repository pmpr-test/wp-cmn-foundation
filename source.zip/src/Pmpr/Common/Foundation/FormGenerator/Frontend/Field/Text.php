<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\x6f\162\x6d\55\143\x6f\156\164\x72\x6f\x6c")->askmmuauqcuuqsea("\124\x65\170\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\x72\155\x2d\x67\x72\157\165\160"); } }
