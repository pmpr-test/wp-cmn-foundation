<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\157\x72\x6d\55\x63\x6f\156\x74\x72\x6f\154")->askmmuauqcuuqsea("\x54\145\170\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\x6f\x72\155\x2d\147\162\x6f\165\160"); } }
