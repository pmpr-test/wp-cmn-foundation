<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\157\x72\x6d\x2d\143\157\156\x74\162\x6f\x6c")->askmmuauqcuuqsea("\124\145\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\x72\155\x2d\147\162\157\165\x70"); } }
