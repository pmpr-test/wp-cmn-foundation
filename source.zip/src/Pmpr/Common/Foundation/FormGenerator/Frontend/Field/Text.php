<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679775b18836a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\157\162\x6d\55\143\x6f\x6e\164\162\157\x6c")->askmmuauqcuuqsea("\124\145\170\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\x72\x6d\55\x67\162\157\x75\160"); } }
