<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9f11bf9d9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\162\x6d\55\x63\157\x6e\164\x72\x6f\154")->askmmuauqcuuqsea("\x54\x65\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\x72\155\55\x67\162\157\x75\x70"); } }
