<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac859a97153             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg('form-control')->askmmuauqcuuqsea('Text')->kakecegieeqyyayu()->qigsyyqgewgskemg('form-group'); } }
