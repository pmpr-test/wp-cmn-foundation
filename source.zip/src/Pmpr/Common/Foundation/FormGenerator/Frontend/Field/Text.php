<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e84f05bca             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\157\x72\155\55\143\157\156\164\x72\157\154")->askmmuauqcuuqsea("\x54\145\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\162\155\x2d\147\x72\157\165\x70"); } }
