<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da3806785e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\x72\155\x2d\143\x6f\156\x74\x72\157\x6c")->askmmuauqcuuqsea("\x54\x65\170\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\162\x6d\x2d\x67\162\157\x75\x70"); } }
