<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc48145c0e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\x72\x6d\x2d\x63\x6f\x6e\164\x72\157\x6c")->askmmuauqcuuqsea("\124\x65\170\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\x72\155\55\147\162\157\x75\x70"); } }
