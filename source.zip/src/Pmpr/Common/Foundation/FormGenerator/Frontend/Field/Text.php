<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0611cd07             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\x6f\162\x6d\55\143\x6f\x6e\164\x72\x6f\x6c")->askmmuauqcuuqsea("\x54\145\170\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\x72\155\55\147\162\157\165\160"); } }
