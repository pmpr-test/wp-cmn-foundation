<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\x6f\x72\x6d\55\143\x6f\156\164\162\157\x6c")->askmmuauqcuuqsea("\124\x65\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\162\x6d\x2d\x67\x72\x6f\x75\x70"); } }
