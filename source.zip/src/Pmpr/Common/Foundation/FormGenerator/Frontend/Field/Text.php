<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a37bcbb1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\x6f\x72\155\55\x63\157\156\x74\x72\x6f\x6c")->askmmuauqcuuqsea("\124\145\170\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\162\155\55\147\162\157\165\x70"); } }
