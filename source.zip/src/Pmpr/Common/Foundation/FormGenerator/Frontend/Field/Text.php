<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132d18d1e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\x6f\162\155\55\143\x6f\x6e\164\162\157\x6c")->askmmuauqcuuqsea("\x54\x65\x78\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\x72\155\x2d\x67\x72\157\165\x70"); } }
