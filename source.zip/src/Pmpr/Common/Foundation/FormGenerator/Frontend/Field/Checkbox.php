<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6780382025b61             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\x75\163\164\157\155\x2d\143\157\156\x74\162\157\x6c\55\x69\156\160\165\164")->askmmuauqcuuqsea("\103\150\x65\143\153\142\157\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\x65\154\144\x5f\143\157\x6e\x74\141\151\156\x65\162\x5f\143\154\x61\x73\163"] = "\x63\x75\163\x74\157\155\x2d\x63\x6f\156\164\162\x6f\x6c\40\143\165\163\164\157\155\55\x63\150\145\143\153\142\x6f\170"; return $ywmkwiwkosakssii; } }
