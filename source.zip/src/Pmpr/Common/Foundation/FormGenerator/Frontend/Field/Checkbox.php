<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f9903c56c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\157\x6d\55\x63\157\156\x74\162\x6f\154\55\x69\x6e\160\x75\x74")->askmmuauqcuuqsea("\103\x68\x65\x63\x6b\x62\x6f\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\145\154\x64\x5f\x63\x6f\x6e\164\x61\151\x6e\145\162\137\x63\x6c\141\163\163"] = "\143\165\x73\x74\x6f\155\x2d\x63\x6f\x6e\164\x72\x6f\154\x20\143\x75\x73\164\157\155\55\x63\x68\x65\x63\153\x62\157\x78"; return $ywmkwiwkosakssii; } }
