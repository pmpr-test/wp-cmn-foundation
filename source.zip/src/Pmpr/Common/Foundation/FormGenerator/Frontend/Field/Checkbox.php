<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\x74\157\155\55\x63\x6f\x6e\x74\x72\x6f\x6c\55\151\x6e\x70\165\164")->askmmuauqcuuqsea("\103\150\145\x63\153\142\157\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\145\154\144\137\x63\157\x6e\x74\x61\x69\156\x65\162\137\x63\x6c\141\163\x73"] = "\x63\165\163\164\157\155\55\x63\157\156\164\162\x6f\x6c\x20\x63\x75\163\164\x6f\x6d\55\x63\150\145\x63\153\x62\x6f\170"; return $ywmkwiwkosakssii; } }
