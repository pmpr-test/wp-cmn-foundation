<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\x73\164\x6f\155\55\143\157\156\x74\x72\x6f\154\x2d\x69\156\160\x75\164")->askmmuauqcuuqsea("\x43\x68\145\x63\153\142\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\x69\145\154\x64\137\x63\x6f\x6e\164\x61\x69\156\x65\x72\137\143\154\x61\163\x73"] = "\143\165\163\x74\157\155\55\143\157\156\x74\x72\157\154\40\x63\x75\163\164\x6f\155\x2d\143\x68\x65\143\x6b\x62\157\x78"; return $ywmkwiwkosakssii; } }
