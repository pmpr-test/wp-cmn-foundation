<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\165\163\x74\157\x6d\55\143\x6f\x6e\x74\x72\157\x6c\x2d\151\156\x70\165\164")->askmmuauqcuuqsea("\x43\150\x65\143\x6b\142\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\x65\154\144\137\143\x6f\x6e\x74\x61\151\156\x65\x72\x5f\143\154\141\x73\x73"] = "\x63\165\163\164\157\155\x2d\x63\157\156\164\162\x6f\154\40\143\x75\163\x74\157\x6d\55\143\x68\145\143\x6b\142\x6f\x78"; return $ywmkwiwkosakssii; } }
