<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791524c10e10             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\x74\x6f\155\x2d\143\x6f\156\164\x72\x6f\154\55\151\156\160\165\164")->askmmuauqcuuqsea("\x43\x68\145\143\153\x62\x6f\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\145\154\x64\x5f\x63\x6f\x6e\x74\141\x69\x6e\145\x72\137\143\154\x61\163\x73"] = "\143\x75\163\164\157\x6d\x2d\x63\x6f\156\x74\x72\x6f\x6c\40\x63\165\x73\x74\x6f\155\x2d\x63\150\145\x63\153\x62\x6f\x78"; return $ywmkwiwkosakssii; } }
