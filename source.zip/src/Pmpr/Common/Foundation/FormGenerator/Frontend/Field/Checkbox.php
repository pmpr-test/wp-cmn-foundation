<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d30e2de1d6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\x6f\155\x2d\x63\157\156\164\162\157\x6c\x2d\x69\156\160\x75\x74")->askmmuauqcuuqsea("\x43\x68\145\x63\x6b\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\145\154\144\x5f\x63\x6f\156\164\x61\x69\x6e\x65\x72\137\x63\x6c\x61\x73\163"] = "\143\x75\x73\x74\157\155\55\143\157\x6e\x74\162\x6f\x6c\x20\143\165\163\164\157\155\55\x63\150\x65\143\x6b\142\157\170"; return $ywmkwiwkosakssii; } }
