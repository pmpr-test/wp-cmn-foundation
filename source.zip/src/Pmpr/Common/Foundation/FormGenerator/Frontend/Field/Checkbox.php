<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77d1b4081             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\x75\163\x74\157\x6d\55\x63\157\156\x74\x72\x6f\x6c\x2d\x69\x6e\x70\x75\164")->askmmuauqcuuqsea("\103\x68\145\143\x6b\142\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\x65\154\x64\x5f\143\157\x6e\x74\x61\151\x6e\145\x72\x5f\143\x6c\x61\163\163"] = "\x63\165\x73\x74\x6f\155\55\143\157\156\x74\162\157\154\x20\143\x75\163\164\x6f\x6d\55\143\150\x65\x63\x6b\x62\157\170"; return $ywmkwiwkosakssii; } }
