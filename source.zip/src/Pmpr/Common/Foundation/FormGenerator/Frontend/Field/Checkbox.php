<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76ba63557             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\x74\x6f\x6d\x2d\143\x6f\156\164\162\x6f\154\x2d\x69\x6e\x70\165\x74")->askmmuauqcuuqsea("\x43\x68\x65\143\153\x62\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\145\154\x64\137\143\157\x6e\164\x61\151\x6e\x65\162\x5f\x63\x6c\141\163\x73"] = "\143\165\x73\x74\157\155\x2d\x63\157\156\x74\162\157\154\40\x63\x75\x73\x74\x6f\x6d\x2d\x63\x68\145\143\x6b\x62\x6f\x78"; return $ywmkwiwkosakssii; } }
