<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbd402ffa1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\165\163\164\157\x6d\55\x63\x6f\x6e\x74\x72\x6f\154\55\151\x6e\x70\x75\x74")->askmmuauqcuuqsea("\103\150\x65\143\153\x62\x6f\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\145\x6c\144\x5f\x63\157\x6e\x74\141\151\156\x65\162\x5f\143\x6c\x61\163\163"] = "\143\x75\x73\164\157\155\x2d\143\x6f\156\x74\162\157\154\40\143\x75\163\164\157\x6d\55\x63\x68\x65\143\153\142\157\x78"; return $ywmkwiwkosakssii; } }
