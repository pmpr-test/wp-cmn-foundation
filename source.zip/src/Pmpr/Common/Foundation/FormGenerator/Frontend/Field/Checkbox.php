<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\x73\164\x6f\155\x2d\x63\157\156\164\162\157\x6c\55\x69\x6e\x70\165\x74")->askmmuauqcuuqsea("\x43\150\x65\143\153\x62\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\x65\x6c\x64\137\x63\x6f\156\164\141\151\x6e\x65\162\137\x63\x6c\x61\163\x73"] = "\143\165\163\164\x6f\155\x2d\x63\x6f\x6e\x74\162\157\x6c\x20\143\165\163\164\x6f\155\x2d\x63\x68\145\x63\153\x62\157\170"; return $ywmkwiwkosakssii; } }
