<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038c53dd59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\163\164\x6f\x6d\55\x63\x6f\x6e\x74\x72\x6f\154\x2d\x69\x6e\x70\165\x74")->askmmuauqcuuqsea("\103\150\145\x63\153\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\145\x6c\x64\137\143\x6f\156\164\141\151\156\145\162\x5f\143\x6c\x61\163\163"] = "\143\x75\163\x74\157\155\x2d\143\x6f\156\x74\162\x6f\154\40\143\x75\163\164\x6f\x6d\55\143\x68\145\143\153\x62\157\170"; return $ywmkwiwkosakssii; } }
