<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec7e2db2b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\x75\163\164\x6f\155\x2d\143\157\156\164\x72\157\154\x2d\151\156\160\x75\x74")->askmmuauqcuuqsea("\x43\150\x65\143\x6b\142\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\145\154\144\x5f\x63\x6f\x6e\164\141\151\x6e\145\162\x5f\143\x6c\141\163\x73"] = "\x63\165\163\164\157\155\x2d\x63\157\x6e\x74\x72\157\154\40\x63\x75\x73\164\x6f\x6d\x2d\143\150\145\x63\153\142\x6f\x78"; return $ywmkwiwkosakssii; } }
