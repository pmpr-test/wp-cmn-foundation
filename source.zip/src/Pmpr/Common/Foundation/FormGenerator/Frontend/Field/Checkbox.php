<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051cac7bda7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\165\163\164\157\155\x2d\143\157\156\x74\x72\157\x6c\55\151\156\x70\x75\x74")->askmmuauqcuuqsea("\103\x68\145\143\x6b\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\x69\145\x6c\x64\137\x63\157\156\x74\141\x69\x6e\x65\162\x5f\143\x6c\x61\163\163"] = "\x63\x75\x73\164\x6f\x6d\55\x63\x6f\x6e\164\x72\x6f\x6c\x20\x63\165\163\x74\x6f\x6d\55\x63\x68\x65\143\x6b\x62\x6f\x78"; return $ywmkwiwkosakssii; } }
