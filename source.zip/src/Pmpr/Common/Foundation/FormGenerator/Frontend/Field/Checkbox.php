<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20bada3b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\163\x74\157\x6d\55\x63\157\156\164\162\157\x6c\x2d\x69\156\160\x75\164")->askmmuauqcuuqsea("\103\150\145\x63\x6b\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\145\154\x64\x5f\x63\157\x6e\164\x61\151\x6e\x65\162\137\x63\x6c\x61\x73\163"] = "\143\x75\163\164\x6f\155\x2d\143\157\156\164\x72\157\x6c\x20\143\x75\x73\x74\x6f\x6d\55\143\x68\x65\x63\153\x62\157\170"; return $ywmkwiwkosakssii; } }
