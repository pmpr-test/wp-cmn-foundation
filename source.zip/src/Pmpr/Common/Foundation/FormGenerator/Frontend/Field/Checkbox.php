<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053bb6ecfdb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\163\164\x6f\x6d\55\x63\x6f\156\164\162\x6f\x6c\55\x69\x6e\160\x75\164")->askmmuauqcuuqsea("\103\x68\145\x63\153\142\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\145\x6c\x64\137\x63\157\x6e\164\x61\151\156\x65\x72\x5f\143\154\x61\163\163"] = "\143\165\x73\x74\157\x6d\55\x63\157\156\x74\x72\x6f\x6c\x20\143\165\163\164\x6f\x6d\55\x63\150\145\x63\153\x62\x6f\170"; return $ywmkwiwkosakssii; } }
