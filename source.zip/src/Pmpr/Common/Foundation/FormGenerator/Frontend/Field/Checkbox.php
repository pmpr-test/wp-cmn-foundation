<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581610eed2f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\x73\164\157\155\x2d\143\157\x6e\164\x72\157\x6c\x2d\151\x6e\x70\x75\164")->askmmuauqcuuqsea("\103\x68\145\143\x6b\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\145\154\x64\x5f\143\157\x6e\164\141\x69\156\x65\162\137\x63\x6c\x61\163\163"] = "\143\165\163\164\157\x6d\55\143\x6f\x6e\x74\x72\x6f\x6c\40\x63\165\x73\x74\x6f\x6d\55\x63\150\x65\143\x6b\142\x6f\170"; return $ywmkwiwkosakssii; } }
