<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c47480ec             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\x75\163\x74\157\x6d\55\x63\157\156\x74\162\157\x6c\x2d\x69\x6e\160\165\x74")->askmmuauqcuuqsea("\x43\x68\145\x63\153\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\x65\154\x64\x5f\143\x6f\156\164\141\151\x6e\x65\162\137\x63\x6c\141\163\x73"] = "\143\165\163\164\x6f\x6d\55\143\157\156\164\162\x6f\x6c\x20\x63\165\163\164\x6f\x6d\55\x63\150\x65\x63\153\x62\x6f\170"; return $ywmkwiwkosakssii; } }
