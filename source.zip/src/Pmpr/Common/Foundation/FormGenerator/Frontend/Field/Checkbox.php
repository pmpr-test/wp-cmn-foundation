<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522a8f9030b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\163\164\157\x6d\55\x63\157\156\164\x72\x6f\154\55\151\x6e\x70\x75\164")->askmmuauqcuuqsea("\x43\150\x65\143\153\x62\157\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\145\154\x64\x5f\x63\157\x6e\164\141\151\156\145\x72\137\x63\154\x61\x73\x73"] = "\143\x75\x73\x74\157\155\55\x63\x6f\x6e\x74\162\x6f\x6c\x20\143\165\163\x74\157\x6d\x2d\143\x68\x65\143\153\142\157\x78"; return $ywmkwiwkosakssii; } }
