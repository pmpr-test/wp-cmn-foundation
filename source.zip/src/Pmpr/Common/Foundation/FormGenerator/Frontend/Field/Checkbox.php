<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\x73\164\157\155\55\143\157\x6e\x74\x72\x6f\x6c\55\151\156\x70\165\164")->askmmuauqcuuqsea("\103\x68\x65\x63\x6b\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\x65\x6c\144\137\x63\x6f\156\164\x61\151\x6e\145\162\137\x63\154\x61\163\163"] = "\x63\165\x73\x74\157\155\55\x63\x6f\156\164\162\x6f\154\40\143\x75\163\x74\x6f\155\x2d\143\x68\145\x63\153\x62\x6f\170"; return $ywmkwiwkosakssii; } }
