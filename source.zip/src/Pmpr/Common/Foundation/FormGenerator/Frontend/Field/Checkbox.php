<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679154b81399c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\x6f\155\x2d\143\157\x6e\x74\x72\157\x6c\x2d\151\156\160\x75\164")->askmmuauqcuuqsea("\103\x68\x65\x63\153\x62\x6f\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\x65\x6c\144\137\x63\157\x6e\164\x61\x69\x6e\x65\x72\137\143\x6c\141\163\163"] = "\143\x75\x73\x74\x6f\x6d\55\143\x6f\156\x74\162\x6f\x6c\x20\x63\165\163\x74\157\155\55\x63\150\145\143\x6b\x62\x6f\170"; return $ywmkwiwkosakssii; } }
