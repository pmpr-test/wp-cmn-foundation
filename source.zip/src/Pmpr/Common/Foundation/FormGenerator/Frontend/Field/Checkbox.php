<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e3ee38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\157\x6d\x2d\x63\157\156\x74\162\x6f\154\55\151\x6e\160\x75\164")->askmmuauqcuuqsea("\x43\x68\145\x63\153\x62\157\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\145\x6c\x64\137\143\157\x6e\164\141\x69\x6e\x65\x72\x5f\x63\x6c\141\163\x73"] = "\x63\165\x73\x74\x6f\x6d\x2d\143\157\x6e\164\162\157\154\40\x63\165\163\x74\157\x6d\x2d\x63\x68\145\143\x6b\x62\x6f\170"; return $ywmkwiwkosakssii; } }
