<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689bafc3c576f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Element; class Div extends Element { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'div'); } }
