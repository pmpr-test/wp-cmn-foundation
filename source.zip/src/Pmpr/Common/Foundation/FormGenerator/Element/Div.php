<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c7243e06be             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Element; class Div extends Element { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'div'); } }
