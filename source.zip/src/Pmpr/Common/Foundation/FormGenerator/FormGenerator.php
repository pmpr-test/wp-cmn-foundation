<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6af0adcff6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator; use Pmpr\Common\Foundation\FormGenerator\Backend\Backend; class FormGenerator extends Common { public function mameiwsayuyquoeq() { Backend::ksyueceqagwomguk(); } }
