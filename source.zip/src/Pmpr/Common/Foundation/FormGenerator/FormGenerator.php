<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator; use Pmpr\Common\Foundation\FormGenerator\Backend\Backend; class FormGenerator extends Common { public function mameiwsayuyquoeq() { Backend::ksyueceqagwomguk(); } }
