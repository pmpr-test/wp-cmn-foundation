<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68b461e8ad9e3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Component; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Traits\StepTrait; class Step extends Component { use StepTrait; public function qiccuiwooiquycsg() { $this->templateClass = self::class; $this->esmoocwowesymqma(); parent::qiccuiwooiquycsg(); } public function cyeuiyggkcqmoecc(?string $meqocwsecsywiiqs, ?string $uusmaiomayssaecw) : Button { $gskauacumcmekigs = null; if ($meqocwsecsywiiqs) { $gskauacumcmekigs = $this->caokeucsksukesyo()->wmkogisswkckmeua()->qoeiescseggagsqs($uusmaiomayssaecw)->gswweykyogmsyawy($meqocwsecsywiiqs)->ckccqugcgucieugo(); } return $gskauacumcmekigs; } }
