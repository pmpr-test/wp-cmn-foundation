<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6940431ebfcfc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Component; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; class Panel extends Page { use SegmentsTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->template = Constants::ismwwqmwgmqqocke; $this->templateClass = self::class; } public function iumcsgkcwwwsyggc() { $this->ykwqaukkycogooii(); $this->wumseguyiucgkiuq(); parent::iumcsgkcwwwsyggc(); } public function ykwqaukkycogooii() { } }
