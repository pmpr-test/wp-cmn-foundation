<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7033cd112             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ShortcutsTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { use ShortcutsTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); } public function qsecygiycssgacqs(int $essikcmqiyqaqoaq) : self { return $this->qcgocuceocquqcuw('rows', $essikcmqiyqaqoaq); } public function akaoeeiaokeaoiii($qssueowgqeqkyqeq = null, $gkyokgakscwikuky = null) : self { $this->qigsyyqgewgskemg('pr-code-editor'); if ($qssueowgqeqkyqeq) { $this->eskgwaywimqcwcyy(Constants::wsiyuewcsugmoqam, $qssueowgqeqkyqeq); } if ($gkyokgakscwikuky) { $this->eskgwaywimqcwcyy('language-selector', $gkyokgakscwikuky); } $this->caokeucsksukesyo()->usugyumcgeaaowsi()->ousmawwywumikwwc(); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->cosayasseegkqiii(); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
