<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16ccfaa782             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Hidden extends Input { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); } public function mawcogsqogkauasq(?string $aiamqeawckcsuaou = null) : self { if ($aiamqeawckcsuaou) { goto amoygaweoeymiuiy; } $aiamqeawckcsuaou = $this->aakmagwggmkoiiyu(); amoygaweoeymiuiy: $this->iygyugseyaqwywyg($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ikkqcccaweckukug($aiamqeawckcsuaou)); return $this; } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) : self { $this->qcgocuceocquqcuw(Constants::ciyoccqkiamemcmm, $eqgoocgaqwqcimie); return parent::iygyugseyaqwywyg($eqgoocgaqwqcimie); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { if (!(Constants::soqecysmeyiyyyys === $this->gueasuouwqysmomu())) { goto kcomueysiyyqagus; } $this->kakecegieeqyyayu()->qigsyyqgewgskemg("\160\162\55\x66\151\145\x6c\144\55\x69\x6e\x76\x69\x73\151\142\x6c\x65"); kcomueysiyyqagus: parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
