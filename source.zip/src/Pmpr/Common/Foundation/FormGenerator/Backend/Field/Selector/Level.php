<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835e37313             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field\Selector; use Pmpr\Common\Foundation\FormGenerator\Traits\OptionsTrait; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Level extends Common { use OptionsTrait; public function oeewiaacscgyamai(Option $omkysikckkcieckq) : self { if ($this->ygqycmmkoiuocoia() && !$this->myacgeeekqcmemge()) { $wkaqekwwgqsqwcoi = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->gqesusmmigggsqai() ? IconInterface::qcamuqyiycioumkm : IconInterface::ygeoyikieuqggmka; $gcwmggyqgiuyogkw = $this->caokeucsksukesyo()->wmkogisswkckmeua()->qyiqwoqimqmsggkm($this->ygqycmmkoiuocoia()); $gcwmggyqgiuyogkw->gswweykyogmsyawy(__("\102\141\x63\x6b\x20\x50\x72\x65\x76\x69\157\x75\x73\40\114\x65\x76\x65\x6c", PR__CMN__FOUNDATION))->saemoowcasogykak($wkaqekwwgqsqwcoi)->cgywqomcsaqkswgi(Constants::sokiwgiwgagukgsg); $this->kesomeowemmyygey($this->ygqycmmkoiuocoia(), $gcwmggyqgiuyogkw); } $this->kesomeowemmyygey($omkysikckkcieckq->mwikyscisascoeea(), $omkysikckkcieckq); return $this; } }
