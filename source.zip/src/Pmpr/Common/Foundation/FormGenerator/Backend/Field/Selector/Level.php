<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169c5071bcd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field\Selector; use Pmpr\Common\Foundation\FormGenerator\Traits\OptionsTrait; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Level extends Common { use OptionsTrait; public function oeewiaacscgyamai(Option $omkysikckkcieckq) : self { if ($this->ygqycmmkoiuocoia() && !$this->myacgeeekqcmemge()) { $wkaqekwwgqsqwcoi = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->gqesusmmigggsqai() ? IconInterface::qcamuqyiycioumkm : IconInterface::ygeoyikieuqggmka; $gcwmggyqgiuyogkw = $this->caokeucsksukesyo()->wmkogisswkckmeua()->qyiqwoqimqmsggkm($this->ygqycmmkoiuocoia()); $gcwmggyqgiuyogkw->gswweykyogmsyawy(__('Back Previous Level', PR__CMN__FOUNDATION))->saemoowcasogykak($wkaqekwwgqsqwcoi)->cgywqomcsaqkswgi(Constants::sokiwgiwgagukgsg); $this->kesomeowemmyygey($this->ygqycmmkoiuocoia(), $gcwmggyqgiuyogkw); } $this->kesomeowemmyygey($omkysikckkcieckq->mwikyscisascoeea(), $omkysikckkcieckq); return $this; } }
