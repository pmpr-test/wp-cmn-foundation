<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d41721935c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field\Selector; use Pmpr\Common\Foundation\FormGenerator\Traits\OptionsTrait; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Level extends Common { use OptionsTrait; public function oeewiaacscgyamai(Option $omkysikckkcieckq) : self { if ($this->ygqycmmkoiuocoia() && !$this->myacgeeekqcmemge()) { $wkaqekwwgqsqwcoi = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->gqesusmmigggsqai() ? IconInterface::qcamuqyiycioumkm : IconInterface::ygeoyikieuqggmka; $gcwmggyqgiuyogkw = $this->caokeucsksukesyo()->wmkogisswkckmeua()->qyiqwoqimqmsggkm($this->ygqycmmkoiuocoia()); $gcwmggyqgiuyogkw->gswweykyogmsyawy(__("\102\141\143\153\40\x50\x72\145\166\151\157\x75\163\x20\114\x65\x76\145\154", PR__CMN__FOUNDATION))->saemoowcasogykak($wkaqekwwgqsqwcoi)->cgywqomcsaqkswgi(Constants::sokiwgiwgagukgsg); $this->kesomeowemmyygey($this->ygqycmmkoiuocoia(), $gcwmggyqgiuyogkw); } $this->kesomeowemmyygey($omkysikckkcieckq->mwikyscisascoeea(), $omkysikckkcieckq); return $this; } }
