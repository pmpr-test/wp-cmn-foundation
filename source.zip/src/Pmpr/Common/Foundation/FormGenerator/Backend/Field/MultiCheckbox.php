<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77d1b4081             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class MultiCheckbox extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, "\155\x75\154\164\x69\x63\150\145\143\153\x62\x6f\x78"); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); } public function yiiiqewsseywemqu($eqgoocgaqwqcimie) : array { $ksaameoqigiaoigg = []; if (!(is_string($eqgoocgaqwqcimie) && $eqgoocgaqwqcimie)) { goto akiuyguwqaukuugs; } $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->queuakuqucciemcc($eqgoocgaqwqcimie); akiuyguwqaukuugs: if (!is_array($eqgoocgaqwqcimie)) { goto emiyocoiuwcucuwu; } $ksaameoqigiaoigg = array_keys($eqgoocgaqwqcimie); emiyocoiuwcucuwu: return $ksaameoqigiaoigg; } }
