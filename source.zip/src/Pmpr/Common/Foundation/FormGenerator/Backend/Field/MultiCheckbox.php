<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c8774d14             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class MultiCheckbox extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, "\x6d\x75\154\x74\x69\143\150\x65\x63\153\142\x6f\x78"); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); } public function yiiiqewsseywemqu($eqgoocgaqwqcimie) : array { $ksaameoqigiaoigg = []; if (is_string($eqgoocgaqwqcimie) && $eqgoocgaqwqcimie) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->queuakuqucciemcc($eqgoocgaqwqcimie); } if (is_array($eqgoocgaqwqcimie)) { $ksaameoqigiaoigg = array_keys($eqgoocgaqwqcimie); } return $ksaameoqigiaoigg; } }
