<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class MultiCheckbox extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, "\155\x75\x6c\164\x69\x63\x68\145\x63\153\142\x6f\170"); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); } public function yiiiqewsseywemqu($eqgoocgaqwqcimie) : array { $ksaameoqigiaoigg = []; if (!(is_string($eqgoocgaqwqcimie) && $eqgoocgaqwqcimie)) { goto kgeggsckmgcgwcqm; } $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->queuakuqucciemcc($eqgoocgaqwqcimie); kgeggsckmgcgwcqm: if (!is_array($eqgoocgaqwqcimie)) { goto qimieogaimwmukmu; } $ksaameoqigiaoigg = array_keys($eqgoocgaqwqcimie); qimieogaimwmukmu: return $ksaameoqigiaoigg; } }
