<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c72e8c2b8c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; class SwitchCheckbox extends Checkbox { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->aseocggwwegcmqes('switch'); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->igiywquyccyiaucw('active-title', __('ON', PR__CMN__FOUNDATION))->igiywquyccyiaucw('inactive-title', __('OFF', PR__CMN__FOUNDATION)); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
