<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ff7768f0b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; class SwitchCheckbox extends Checkbox { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->aseocggwwegcmqes("\x73\167\x69\x74\x63\x68"); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->igiywquyccyiaucw("\x61\x63\x74\151\x76\x65\55\164\x69\x74\x6c\x65", __("\x4f\x4e", PR__CMN__FOUNDATION))->igiywquyccyiaucw("\x69\x6e\141\x63\164\151\166\145\55\164\x69\164\154\x65", __("\117\106\106", PR__CMN__FOUNDATION)); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
