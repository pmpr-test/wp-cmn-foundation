<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d720531f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; class SwitchCheckbox extends Checkbox { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->aseocggwwegcmqes("\x73\167\151\x74\143\x68"); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->igiywquyccyiaucw("\141\143\x74\151\x76\x65\x2d\x74\x69\164\x6c\x65", __("\x4f\x4e", PR__CMN__FOUNDATION))->igiywquyccyiaucw("\151\x6e\141\x63\x74\x69\166\x65\55\164\x69\164\x6c\145", __("\117\106\106", PR__CMN__FOUNDATION)); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
