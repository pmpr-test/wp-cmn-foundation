<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791524c10e10             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; class SwitchCheckbox extends Checkbox { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->aseocggwwegcmqes("\x73\167\x69\x74\x63\150"); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->igiywquyccyiaucw("\x61\143\164\151\x76\145\x2d\164\151\x74\154\145", __("\x4f\116", PR__CMN__FOUNDATION))->igiywquyccyiaucw("\151\x6e\x61\143\x74\x69\166\x65\x2d\x74\151\164\x6c\145", __("\x4f\x46\106", PR__CMN__FOUNDATION)); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
