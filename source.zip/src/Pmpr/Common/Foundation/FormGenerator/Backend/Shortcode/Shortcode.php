<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63e3347d2a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Shortcode; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Component\Modal; class Shortcode extends Modal { public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->type = 'shortcode'; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('media_buttons', [$this, 'sewqswegcwywamuw']); parent::wigskegsqequoeks(); } public function uqwgsuysegkweago($ccamueccusigaaio = null) : bool { $seumokooiykcomco = $this->caokeucsksukesyo()->ayueggmoqeeukqmq(); if (!$ccamueccusigaaio) { $ccamueccusigaaio = $seumokooiykcomco->gueasuouwqysmomu(); } return $seumokooiykcomco->uqwgsuysegkweago($ccamueccusigaaio); } public function sewqswegcwywamuw($igwkwmgowquoucyk) { if (Constants::ssmskyqgcmeiayco === $igwkwmgowquoucyk && $this->uqwgsuysegkweago() && $this->skgwcckoyoqsascq()) { $this->caokeucsksukesyo()->wmkogisswkckmeua()->qoeiescseggagsqs($this->cisyiemkeykgkomc())->gswweykyogmsyawy($this->qcgakseyaikigqco())->render([Constants::qaacaqioeyiuakeu => true]); } } }
