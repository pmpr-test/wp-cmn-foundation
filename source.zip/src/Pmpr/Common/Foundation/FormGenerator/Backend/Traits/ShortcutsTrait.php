<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Traits; trait ShortcutsTrait { protected $placeholders = []; public function auqyiaissiuomqgs() { return $this->placeholders; } public function uokyeqicycwwikwi(string $uusmaiomayssaecw, string $meqocwsecsywiiqs) : self { $this->placeholders[$uusmaiomayssaecw] = $meqocwsecsywiiqs; return $this; } public function euokiigekgwygigi(array $iyuoemwqumwyekia) : self { foreach ($iyuoemwqumwyekia as $uusmaiomayssaecw => $meqocwsecsywiiqs) { $this->uokyeqicycwwikwi($uusmaiomayssaecw, $meqocwsecsywiiqs); gsimucysiuikweme: } ekimmsiekwwoawym: return $this; } public function cosayasseegkqiii() : self { $iyuoemwqumwyekia = $this->auqyiaissiuomqgs(); if (!is_array($iyuoemwqumwyekia)) { goto ukicwqcoggwiskgo; } $this->placeholders = $this->caokeucsksukesyo()->wmkogisswkckmeua()->cosayasseegkqiii($iyuoemwqumwyekia); ukicwqcoggwiskgo: return $this; } }
