<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517460aacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Traits; trait ShortcutsTrait { protected $placeholders = []; public function auqyiaissiuomqgs() { return $this->placeholders; } public function uokyeqicycwwikwi(string $uusmaiomayssaecw, string $meqocwsecsywiiqs) : self { $this->placeholders[$uusmaiomayssaecw] = $meqocwsecsywiiqs; return $this; } public function euokiigekgwygigi(array $iyuoemwqumwyekia) : self { foreach ($iyuoemwqumwyekia as $uusmaiomayssaecw => $meqocwsecsywiiqs) { $this->uokyeqicycwwikwi($uusmaiomayssaecw, $meqocwsecsywiiqs); ysusaysykymegguk: } emgssiqceagusgyg: return $this; } public function cosayasseegkqiii() : self { $iyuoemwqumwyekia = $this->auqyiaissiuomqgs(); if (!is_array($iyuoemwqumwyekia)) { goto yskswskmsgoouyco; } $this->placeholders = $this->caokeucsksukesyo()->wmkogisswkckmeua()->cosayasseegkqiii($iyuoemwqumwyekia); yskswskmsgoouyco: return $this; } }
