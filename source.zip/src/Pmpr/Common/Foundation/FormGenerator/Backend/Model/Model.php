<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\FormGenerator\Backend\Common; class Model extends Common { public function aqyikqugcomoqqqi() { Origin::symcgieuakksimmu(); Option::symcgieuakksimmu(); } }
