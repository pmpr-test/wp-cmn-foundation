<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\FormGenerator\Backend\Common; class Model extends Common { public function aqyikqugcomoqqqi() { Origin::symcgieuakksimmu(); Option::symcgieuakksimmu(); } }
