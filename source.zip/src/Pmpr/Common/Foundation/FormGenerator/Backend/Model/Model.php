<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\FormGenerator\Backend\Common; class Model extends Common { public function aqyikqugcomoqqqi() { Origin::symcgieuakksimmu(); Option::symcgieuakksimmu(); } }
