<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76ba63557             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\FormGenerator\Backend\Common; class Model extends Common { public function aqyikqugcomoqqqi() { Origin::symcgieuakksimmu(); Option::symcgieuakksimmu(); } }
