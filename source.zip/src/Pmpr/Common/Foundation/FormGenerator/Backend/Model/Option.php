<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ec0c0505             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\Interfaces\Constants; class Option extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4f\x70\x74\151\x6f\x6e", PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__("\x4f\160\x74\151\x6f\156\x73", PR__CMN__FOUNDATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::ascagqcquwgmygkm)->gswweykyogmsyawy(__("\113\x65\171", PR__CMN__FOUNDATION)))->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__("\x56\141\x6c\x75\x65", PR__CMN__FOUNDATION)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(Constants::yocqkmeouaamomke)->wuuqgaekqeymecag(Origin::class)->gswweykyogmsyawy(__("\117\160\164\151\157\x6e\163", PR__CMN__FOUNDATION))->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg)); parent::ewaqwooqoqmcoomi(); } }
