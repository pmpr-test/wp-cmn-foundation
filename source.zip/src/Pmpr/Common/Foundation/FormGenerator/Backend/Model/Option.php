<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692c64f6ea6d2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; class Option extends Model { public function register() { $this->guiaswksukmgageq(__('Option', PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__('Options', PR__CMN__FOUNDATION)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::ascagqcquwgmygkm)->gswweykyogmsyawy(__('Key', PR__CMN__FOUNDATION)))->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__('Value', PR__CMN__FOUNDATION)))->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(Constants::yocqkmeouaamomke)->wuuqgaekqeymecag(Origin::class)->gswweykyogmsyawy(__('Origin', PR__CMN__FOUNDATION))->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg)); parent::uwmqacgewuauagai(); } }
