<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6885580ee1615             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Component\Component; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ButtonsTrait; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SettingTrait; use Pmpr\Common\Foundation\Traits\CacheTrait; class AjaxSetting extends Component { use CacheTrait, ButtonsTrait, SettingTrait, SegmentsTrait; public function qiccuiwooiquycsg() { $this->kwcoiysqqkqsugqo(); parent::qiccuiwooiquycsg(); } }
