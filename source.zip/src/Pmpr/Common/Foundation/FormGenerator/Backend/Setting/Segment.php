<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda1c872568             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; abstract class Segment extends Component { use SegmentsTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq()), [$this, 'wiecgqcmaasiaeow']); parent::kgquecmsgcouyaya(); } public final function wiecgqcmaasiaeow($wsqkgswwooewwekw) { if ($this->skgwcckoyoqsascq()) { $wsqkgswwooewwekw = array_merge($wsqkgswwooewwekw, $this->gsesiocqciggmauo()); } return $wsqkgswwooewwekw; } }
