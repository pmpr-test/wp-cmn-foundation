<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; abstract class Segment extends Component { use SegmentsTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq()), [$this, "\x77\x69\x65\x63\x67\x71\143\x6d\x61\x61\x73\151\141\145\157\x77"]); parent::kgquecmsgcouyaya(); } public final function wiecgqcmaasiaeow($wsqkgswwooewwekw) { if (!$this->skgwcckoyoqsascq()) { goto akkmaiaiamyaikqe; } $wsqkgswwooewwekw = array_merge($wsqkgswwooewwekw, $this->gsesiocqciggmauo()); akkmaiaiamyaikqe: return $wsqkgswwooewwekw; } }
