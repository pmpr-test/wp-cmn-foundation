<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2ce2062a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq(), $this->eooumquaoewwauoo()), [$this, "\147\167\x67\x75\x79\x71\x79\151\155\141\147\x69\161\163\143\x79"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if (!$this->mgwewyykukaawcmo()) { goto qqcusuaqmyukwyqk; } $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); qqcusuaqmyukwyqk: return $mgiqqesweuqmsymo; } public function qmgcisuuikgmqcsu() : string { return $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo(["\163\x65\147\155\145\x6e\164" => $this->eooumquaoewwauoo()], $this->mggwieqomgcuskme()->oiucukewkckkwiqc()); } public function eooumquaoewwauoo() : string { return $this->segment; } }
