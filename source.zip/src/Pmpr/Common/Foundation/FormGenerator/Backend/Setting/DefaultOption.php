<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6879718a795ce             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\Data\Data; class DefaultOption extends Data { protected ?string $key = null; protected array $options = []; protected ?string $title = null; protected bool $default = false; public function wcosmascwoyyuimi() : bool { return $this->default; } public function wwocyigoyasocsik() : self { $this->default = true; return $this; } public function cisyiemkeykgkomc() : ?string { return $this->key; } public function gcgmwakaoecqcuwo(?string $uusmaiomayssaecw) : self { $this->key = $uusmaiomayssaecw; return $this; } public function qcgakseyaikigqco() : ?string { return $this->title; } public function gswweykyogmsyawy(?string $meqocwsecsywiiqs) : self { $this->title = $meqocwsecsywiiqs; return $this; } public function gkwkqmwweiawigae() : array { return $this->options; } public function acauweqyyugwisqc($qiouiwasaauyaaue) : self { $this->options = $qiouiwasaauyaaue; return $this; } }
