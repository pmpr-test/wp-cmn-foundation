<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9f11bf9d9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\TabsTrait; class Tab extends Component { use TabsTrait; protected string $segment = ''; protected $section = false; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq(), $this->eooumquaoewwauoo(), $this->kosacuuaeuweoqau(), true), [$this, "\x77\161\x6d\x73\x61\155\x77\x61\153\x75\x79\161\x6b\157\171\x79"]); parent::kgquecmsgcouyaya(); } public function wqmsamwakuyqkoyy($ywoucyskcquysiwc) { if ($this->myomgmiksogoikuc()) { $ywoucyskcquysiwc = array_merge($ywoucyskcquysiwc, $this->equiyaoamqmaeckc()); } return $ywoucyskcquysiwc; } public function kosacuuaeuweoqau() { return $this->section; } public function eooumquaoewwauoo() : string { return $this->segment; } }
