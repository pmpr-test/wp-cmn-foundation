<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a37bcbb1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\TabsTrait; class Tab extends Component { use TabsTrait; protected string $segment = ''; protected $section = false; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq(), $this->eooumquaoewwauoo(), $this->kosacuuaeuweoqau(), true), [$this, "\167\x71\155\x73\x61\155\x77\x61\x6b\x75\171\x71\x6b\x6f\x79\x79"]); parent::kgquecmsgcouyaya(); } public function wqmsamwakuyqkoyy($ywoucyskcquysiwc) { if ($this->myomgmiksogoikuc()) { $ywoucyskcquysiwc = array_merge($ywoucyskcquysiwc, $this->equiyaoamqmaeckc()); } return $ywoucyskcquysiwc; } public function kosacuuaeuweoqau() { return $this->section; } public function eooumquaoewwauoo() : string { return $this->segment; } }
