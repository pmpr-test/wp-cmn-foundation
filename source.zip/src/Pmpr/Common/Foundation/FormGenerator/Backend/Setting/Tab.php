<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dbbceded7dc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\TabsTrait; class Tab extends Component { use TabsTrait; protected string $segment = ''; protected $section = false; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq(), $this->eooumquaoewwauoo(), $this->kosacuuaeuweoqau(), true), [$this, 'wqmsamwakuyqkoyy']); parent::kgquecmsgcouyaya(); } public function wqmsamwakuyqkoyy($ywoucyskcquysiwc) { if ($this->myomgmiksogoikuc()) { $ywoucyskcquysiwc = array_merge($ywoucyskcquysiwc, $this->equiyaoamqmaeckc()); } return $ywoucyskcquysiwc; } public function kosacuuaeuweoqau() { return $this->section; } public function eooumquaoewwauoo() : string { return $this->segment; } }
