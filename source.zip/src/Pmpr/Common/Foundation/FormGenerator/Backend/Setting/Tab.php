<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356231cfee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\TabsTrait; class Tab extends Component { use TabsTrait; protected string $segment = ''; protected $section = false; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq(), $this->eooumquaoewwauoo(), $this->kosacuuaeuweoqau(), true), [$this, "\x77\161\155\x73\141\155\167\141\x6b\x75\x79\x71\x6b\157\171\x79"]); parent::kgquecmsgcouyaya(); } public function wqmsamwakuyqkoyy($ywoucyskcquysiwc) { if ($this->myomgmiksogoikuc()) { $ywoucyskcquysiwc = array_merge($ywoucyskcquysiwc, $this->equiyaoamqmaeckc()); } return $ywoucyskcquysiwc; } public function kosacuuaeuweoqau() { return $this->section; } public function eooumquaoewwauoo() : string { return $this->segment; } }
