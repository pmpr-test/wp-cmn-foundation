<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6ea7f40             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\Container\Traits\SingletonTrait; use Pmpr\Common\Foundation\Container\Traits\CommonTrait; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ObjectTrait; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use Pmpr\Common\Foundation\Template\Traits\TemplateTrait; use Pmpr\Common\Foundation\Traits\HookTrait; abstract class Component { use SingletonTrait, TemplateTrait, WrapperTrait, CommonTrait, HelperTrait, ObjectTrait, HookTrait; protected string $tool; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("\141\146\164\x65\162\x5f\147\x65\156\145\162\x61\x74\x65\137{$this->asgqmkcukouykiie()}\x5f\x70\141\x6e\145\154"), [$this, "\171\153\167\x71\x61\165\x6b\x6b\171\x63\157\x67\157\157\x69\x69"]); } public function asgqmkcukouykiie() : string { return $this->tool; } public function ykwqaukkycogooii() { } }
