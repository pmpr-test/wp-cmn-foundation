<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8ad41a06             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\Container\Traits\SingletonTrait; use Pmpr\Common\Foundation\Container\Traits\CommonTrait; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ObjectTrait; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use Pmpr\Common\Foundation\Template\Traits\TemplateTrait; use Pmpr\Common\Foundation\Traits\HookTrait; abstract class Component { use SingletonTrait, TemplateTrait, WrapperTrait, CommonTrait, HelperTrait, ObjectTrait, HookTrait; protected string $tool; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("\x61\146\164\145\x72\x5f\147\145\x6e\145\162\141\x74\145\137{$this->asgqmkcukouykiie()}\x5f\160\141\156\x65\x6c"), [$this, "\x79\153\167\x71\141\165\153\x6b\x79\x63\x6f\147\x6f\x6f\151\x69"]); } public function asgqmkcukouykiie() : string { return $this->tool; } public function ykwqaukkycogooii() { } }
