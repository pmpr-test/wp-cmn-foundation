<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581610eed2f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; abstract class Segment extends Component { use SegmentsTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\x5f\163\145\x67\155\145\x6e\x74\163"), [$this, "\x77\x69\x65\143\x67\x71\143\x6d\x61\141\x73\x69\141\145\x6f\167"]); parent::kgquecmsgcouyaya(); } public final function wiecgqcmaasiaeow($wsqkgswwooewwekw) { if ($this->skgwcckoyoqsascq()) { $wsqkgswwooewwekw = array_merge($wsqkgswwooewwekw, $this->gsesiocqciggmauo()); } return $wsqkgswwooewwekw; } }
