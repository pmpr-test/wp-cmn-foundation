<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b088f1290             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Component\Panel; abstract class Tool extends Panel { public function qiccuiwooiquycsg() { $this->type = "\x74\x6f\157\x6c\x73"; $this->kwcoiysqqkqsugqo()->mcacmissyeeqkeak(Constants::kekcgssiyagioocg, 99)->mcacmissyeeqkeak(Constants::qoquaeuooeycomks, "\x74\157\x6f\154\x73\56\160\x68\160"); parent::qiccuiwooiquycsg(); } }
