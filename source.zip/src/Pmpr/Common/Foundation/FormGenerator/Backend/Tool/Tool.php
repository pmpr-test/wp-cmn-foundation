<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f9903c56c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Component\Panel; abstract class Tool extends Panel { public function qiccuiwooiquycsg() { $this->type = "\x74\157\x6f\154\x73"; $this->kwcoiysqqkqsugqo()->mcacmissyeeqkeak(Constants::kekcgssiyagioocg, 99)->mcacmissyeeqkeak(Constants::qoquaeuooeycomks, "\x74\157\157\x6c\163\x2e\160\150\160"); parent::qiccuiwooiquycsg(); } }
