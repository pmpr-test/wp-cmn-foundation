<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687f55a6c76a3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Component\Panel; abstract class Tool extends Panel { public function qiccuiwooiquycsg() { $this->type = 'tools'; $this->kwcoiysqqkqsugqo()->mcacmissyeeqkeak(Constants::kekcgssiyagioocg, 99)->mcacmissyeeqkeak(Constants::qoquaeuooeycomks, 'tools.php'); parent::qiccuiwooiquycsg(); } }
