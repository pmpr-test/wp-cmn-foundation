<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c61c8485             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\137\x73\145\x67\155\145\156\x74\137{$this->eooumquaoewwauoo()}\x5f\x73\x65\x63\x74\x69\157\x6e\163"), [$this, "\147\x77\x67\x75\x79\x71\171\151\155\x61\x67\151\161\x73\143\171"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if (!$this->mgwewyykukaawcmo()) { goto eqmcakqmqkqkweww; } $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); eqmcakqmqkqkweww: return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
