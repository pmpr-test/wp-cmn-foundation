<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbcd2165a5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\137\x73\145\x67\155\145\156\164\x5f{$this->eooumquaoewwauoo()}\137\x73\x65\x63\x74\x69\157\156\163"), [$this, "\x67\x77\147\x75\171\x71\x79\151\155\141\x67\151\161\163\x63\171"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if ($this->mgwewyykukaawcmo()) { $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); } return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
