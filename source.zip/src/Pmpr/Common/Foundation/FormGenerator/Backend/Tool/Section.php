<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d16a012f73             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\x5f\163\145\147\155\x65\x6e\x74\x5f{$this->eooumquaoewwauoo()}\x5f\x73\x65\143\164\x69\x6f\156\x73"), [$this, "\x67\x77\147\165\x79\x71\x79\151\155\x61\x67\x69\x71\x73\x63\171"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if ($this->mgwewyykukaawcmo()) { $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); } return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
