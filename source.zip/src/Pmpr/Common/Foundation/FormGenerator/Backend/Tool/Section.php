<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6de30612             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\x5f\163\145\x67\x6d\x65\156\x74\x5f{$this->eooumquaoewwauoo()}\137\163\x65\x63\164\151\x6f\156\163"), [$this, "\147\x77\147\165\x79\161\171\x69\x6d\141\x67\x69\161\163\x63\171"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if (!$this->mgwewyykukaawcmo()) { goto ummgomwmsqygiqcy; } $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); ummgomwmsqygiqcy: return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
