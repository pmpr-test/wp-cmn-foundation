<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\x5f\163\145\147\x6d\x65\x6e\x74\x5f{$this->eooumquaoewwauoo()}\137\163\145\143\164\x69\157\156\x73"), [$this, "\147\167\x67\165\x79\x71\171\x69\155\141\x67\151\161\163\x63\171"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if (!$this->mgwewyykukaawcmo()) { goto gcgckeksyymcgays; } $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); gcgckeksyymcgays: return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
