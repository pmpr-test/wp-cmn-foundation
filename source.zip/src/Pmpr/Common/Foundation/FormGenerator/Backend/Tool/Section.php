<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d83a968b15             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\x5f\163\x65\147\155\145\156\x74\137{$this->eooumquaoewwauoo()}\x5f\x73\x65\x63\164\151\157\x6e\163"), [$this, "\147\x77\147\x75\x79\161\171\151\155\141\147\151\x71\163\x63\x79"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if ($this->mgwewyykukaawcmo()) { $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); } return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
