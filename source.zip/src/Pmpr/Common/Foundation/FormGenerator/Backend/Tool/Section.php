<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d8187bb66             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\x5f\x73\x65\x67\155\145\x6e\164\137{$this->eooumquaoewwauoo()}\137\x73\145\143\x74\x69\x6f\x6e\x73"), [$this, "\147\x77\x67\165\x79\x71\x79\151\155\x61\x67\x69\x71\163\x63\x79"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if (!$this->mgwewyykukaawcmo()) { goto keygauyiuaycggcw; } $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); keygauyiuaycggcw: return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
