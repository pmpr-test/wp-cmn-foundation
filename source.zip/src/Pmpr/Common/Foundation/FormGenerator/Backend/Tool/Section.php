<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\137\163\x65\x67\155\x65\x6e\164\137{$this->eooumquaoewwauoo()}\x5f\x73\145\x63\164\151\x6f\x6e\x73"), [$this, "\147\167\147\x75\x79\161\x79\151\x6d\141\147\151\161\x73\x63\171"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if (!$this->mgwewyykukaawcmo()) { goto skuykkqcgakewusu; } $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); skuykkqcgakewusu: return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
