<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791545e8b23b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Ajax; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Ajax extends Container { public function mameiwsayuyquoeq() { Icon::ksyueceqagwomguk(); User::ksyueceqagwomguk(); Term::ksyueceqagwomguk(); Post::ksyueceqagwomguk(); Model::ksyueceqagwomguk(); Theme::ksyueceqagwomguk(); Plugin::ksyueceqagwomguk(); Comment::ksyueceqagwomguk(); StaticImage::ksyueceqagwomguk(); $this->iqkqummseggmikgo("\160\x72\x5f\146\162\x6f\x6e\x74\x65\x6e\144\137\x67\145\164\x5f\156\157\x6e\143\x65", [$this, "\153\x67\x67\x73\165\145\x79\165\x79\161\145\161\145\x75\x73\x63"]); } public function kggsueyuyqeqeusc() { $keccaugmemegoimu = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc(Constants::waoywqksqecymesy, Constants::xwwaeweqegiqeqkm, true, false); $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uaggqsoeugksgooc($keccaugmemegoimu); } }
