<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953da91d73c6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Ajax; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Ajax extends Container { public function mameiwsayuyquoeq() { Icon::ksyueceqagwomguk(); User::ksyueceqagwomguk(); Term::ksyueceqagwomguk(); Post::ksyueceqagwomguk(); Model::ksyueceqagwomguk(); Theme::ksyueceqagwomguk(); Plugin::ksyueceqagwomguk(); Comment::ksyueceqagwomguk(); StaticImage::ksyueceqagwomguk(); $this->iqkqummseggmikgo('pr_frontend_get_nonce', [$this, 'kggsueyuyqeqeusc']); } public function kggsueyuyqeqeusc() { $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uaggqsoeugksgooc([Constants::oomaageiyqkaiekk => $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ikkqcccaweckukug(Constants::waoywqksqecymesy), Constants::syueuegaeqikiyuq => $this->caokeucsksukesyo()->sgqicqeoumwmsmyw()->gwgmymsuwsceguce()]); } }
