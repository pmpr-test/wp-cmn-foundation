<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b645383f9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Ajax; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Ajax extends Container { public function mameiwsayuyquoeq() { Icon::ksyueceqagwomguk(); User::ksyueceqagwomguk(); Term::ksyueceqagwomguk(); Post::ksyueceqagwomguk(); Model::ksyueceqagwomguk(); Theme::ksyueceqagwomguk(); Plugin::ksyueceqagwomguk(); Comment::ksyueceqagwomguk(); StaticImage::ksyueceqagwomguk(); $this->iqkqummseggmikgo("\160\162\137\x66\x72\x6f\156\164\x65\x6e\144\137\x67\x65\x74\x5f\156\157\x6e\x63\145", [$this, "\153\x67\147\x73\x75\145\171\165\171\x71\145\161\145\x75\163\x63"]); } public function kggsueyuyqeqeusc() { $keccaugmemegoimu = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc(Constants::waoywqksqecymesy, Constants::xwwaeweqegiqeqkm, true, false); $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uaggqsoeugksgooc($keccaugmemegoimu); } }
