<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689e5f3b0a1df             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Convert; abstract class Convert { }
