<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             695a9495e6a1e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Convert; abstract class Convert { }
