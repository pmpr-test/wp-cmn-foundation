<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689a24683422f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Convert; abstract class Convert { }
