<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689bafc3c576f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Convert\Type; use Pmpr\Common\Foundation\Convert\Convert; abstract class Common extends Convert { }
