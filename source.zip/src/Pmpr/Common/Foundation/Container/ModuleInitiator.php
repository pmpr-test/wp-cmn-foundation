<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69999156dae20             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class ModuleInitiator extends ComponentInitiator { }
