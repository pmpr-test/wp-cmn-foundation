<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843e9f78fb1e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container\Traits; use Pmpr\Common\Foundation\Asset\Manager; trait CommonTrait { protected bool $canRunSetup = true; public function __construct() { $this->ikcgmcycisiccyuc(); if ($this->kwyscakayqgsqosc()) { $this->gyqeoeemeemicgqi(); } } public function kwyscakayqgsqosc() : bool { return $this->canRunSetup; } public function ikcgmcycisiccyuc() { } public function gyqeoeemeemicgqi() { $this->mameiwsayuyquoeq(); $this->eogyyugasomygcma(); $this->kgewmaycsoykyaso(); $this->wigskegsqequoeks(); $this->kgquecmsgcouyaya(); if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, 'componentsLoaded')) { $this->qcsmikeggeemccuu('components_loaded', [$this, $qgciuiagkkguykgs])->qcsmikeggeemccuu('modules_loaded', [$this, $qgciuiagkkguykgs]); } } public function mameiwsayuyquoeq() { } public function wigskegsqequoeks() { } public function kgquecmsgcouyaya() { } public function kgewmaycsoykyaso() { } public function eogyyugasomygcma() { } }
