<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffe229367             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container\Traits; use Pmpr\Common\Foundation\Asset\Manager; trait CommonTrait { protected bool $canRunSetup = true; public function __construct() { $this->ikcgmcycisiccyuc(); if ($this->kwyscakayqgsqosc()) { $this->gyqeoeemeemicgqi(); } } public function kwyscakayqgsqosc() : bool { return $this->canRunSetup; } public function ikcgmcycisiccyuc() { } public function gyqeoeemeemicgqi() { $this->mameiwsayuyquoeq(); $this->eogyyugasomygcma(); $this->kgewmaycsoykyaso(); $this->wigskegsqequoeks(); $this->kgquecmsgcouyaya(); if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\143\157\155\160\157\156\x65\156\164\163\x4c\157\141\x64\145\144")) { $this->qcsmikeggeemccuu("\x63\x6f\x6d\160\x6f\156\145\156\x74\163\137\x6c\157\x61\x64\x65\144", [$this, $qgciuiagkkguykgs])->qcsmikeggeemccuu("\x6d\157\x64\x75\154\x65\x73\x5f\x6c\x6f\141\x64\x65\x64", [$this, $qgciuiagkkguykgs]); } } public function mameiwsayuyquoeq() { } public function wigskegsqequoeks() { } public function kgquecmsgcouyaya() { } public function kgewmaycsoykyaso() { } public function eogyyugasomygcma() { } }
