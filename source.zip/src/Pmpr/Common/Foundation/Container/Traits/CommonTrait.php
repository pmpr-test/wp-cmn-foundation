<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977684bcc9f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container\Traits; use Pmpr\Common\Foundation\Asset\Manager; trait CommonTrait { protected bool $canRunSetup = true; public function __construct() { $this->ikcgmcycisiccyuc(); if ($this->kwyscakayqgsqosc()) { $this->gyqeoeemeemicgqi(); } } public function kwyscakayqgsqosc() : bool { return $this->canRunSetup; } public function ikcgmcycisiccyuc() { } public function gyqeoeemeemicgqi() { $this->mameiwsayuyquoeq(); $this->eogyyugasomygcma(); $this->kgewmaycsoykyaso(); $this->wigskegsqequoeks(); $this->kgquecmsgcouyaya(); if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\143\157\155\x70\x6f\x6e\145\x6e\x74\x73\x4c\x6f\x61\x64\x65\144")) { $this->qcsmikeggeemccuu("\143\x6f\155\160\157\156\145\156\164\x73\137\154\157\x61\x64\x65\144", [$this, $qgciuiagkkguykgs])->qcsmikeggeemccuu("\x6d\x6f\x64\x75\154\145\163\137\154\x6f\141\144\145\144", [$this, $qgciuiagkkguykgs]); } } public function mameiwsayuyquoeq() { } public function wigskegsqequoeks() { } public function kgquecmsgcouyaya() { } public function kgewmaycsoykyaso() { } public function eogyyugasomygcma() { } }
