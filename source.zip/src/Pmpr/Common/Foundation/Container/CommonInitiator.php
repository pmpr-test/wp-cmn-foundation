<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             695a9495e6a1e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class CommonInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
