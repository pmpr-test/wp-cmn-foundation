<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843e9f78fb1e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class CoverInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
