<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2a0e89b3c8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class CoverInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
