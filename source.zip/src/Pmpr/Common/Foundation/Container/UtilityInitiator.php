<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a4e17b10cc7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class UtilityInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
