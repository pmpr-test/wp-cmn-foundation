<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68175e485b5ec             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class UtilityInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
