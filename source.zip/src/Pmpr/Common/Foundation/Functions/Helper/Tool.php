<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680156f35b43a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; use Pmpr\Common\Foundation\Interfaces\Constants; class Tool extends Common { public function iyiccksyewqymmqg($sogksuscggsicmac, $gwmokccqwwksmwye) : bool { $ymiyawysimukkoso = $sogksuscggsicmac[Constants::ycuusiweasqygwiw] ?? []; return (int) ($ymiyawysimukkoso[Constants::yusuiaeueqwieqqq] ?? 1) <= (int) $gwmokccqwwksmwye; } }
