<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a0b3b3e911f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\Plugin; class Dokan extends Common { public function ggocakcisguuokai() : bool { return $this->caokeucsksukesyo()->essaugkeosgskqme()->ggocakcisguuokai('dokan-lite/dokan.php'); } public function hwkgqyskyockkoay() : bool { $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); return $eiicaiwgqkgsekce->ggcoyemwouwsqouy('dokan') || $eiicaiwgqkgsekce->ggcoyemwouwsqouy('dokan-dashboard'); } }
