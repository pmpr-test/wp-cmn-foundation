<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf5417a8d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto cseucimaukwaskwk; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\x72\137\x5f\143\x6d\x6e\137\x5f\146\x6f\165\x6e\144\x61\x74\151\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\150\x74\x6d\154\x2e\164\x77\x69\x67", $qookweymeqawmcwo); cseucimaukwaskwk: return $nsmgceoqaqogqmuw; } }
