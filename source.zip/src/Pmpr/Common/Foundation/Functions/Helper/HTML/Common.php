<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b04f73b21             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mgkikasuaseesumm; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\x72\x5f\x5f\143\155\156\x5f\x5f\146\x6f\x75\156\x64\x61\x74\x69\157\156\x2f{$qqscaoyqikuyeoaw}\56\150\x74\155\154\x2e\x74\167\151\x67", $qookweymeqawmcwo); mgkikasuaseesumm: return $nsmgceoqaqogqmuw; } }
