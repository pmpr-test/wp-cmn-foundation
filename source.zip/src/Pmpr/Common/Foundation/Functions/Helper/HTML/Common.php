<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a6c2def5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mgkikasuaseesumm; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\x5f\137\x63\155\156\137\x5f\x66\x6f\165\156\x64\x61\164\151\157\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\150\x74\x6d\154\56\x74\167\151\x67", $qookweymeqawmcwo); mgkikasuaseesumm: return $nsmgceoqaqogqmuw; } }
