<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfc3785             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto sucquwgiacwooomw; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\162\137\x5f\143\x6d\x6e\137\x5f\146\157\165\x6e\x64\141\164\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\56\150\x74\x6d\154\x2e\164\x77\151\x67", $qookweymeqawmcwo); sucquwgiacwooomw: return $nsmgceoqaqogqmuw; } }
