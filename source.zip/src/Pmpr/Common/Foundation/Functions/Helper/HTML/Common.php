<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mcyamakgwewogwqi; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\x72\137\x5f\143\x6d\156\x5f\x5f\146\x6f\x75\156\144\x61\164\151\157\x6e\57{$qqscaoyqikuyeoaw}\x2e\150\164\155\x6c\56\x74\167\151\x67", $qookweymeqawmcwo); mcyamakgwewogwqi: return $nsmgceoqaqogqmuw; } }
