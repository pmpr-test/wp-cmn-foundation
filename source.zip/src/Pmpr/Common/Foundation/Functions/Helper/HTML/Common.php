<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f4306668ee2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mgkikasuaseesumm; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\162\x5f\137\143\x6d\156\137\137\x66\x6f\165\156\x64\x61\164\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\155\154\x2e\164\x77\151\147", $qookweymeqawmcwo); mgkikasuaseesumm: return $nsmgceoqaqogqmuw; } }
