<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec064496439             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto kucymsiiugmiooyo; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\160\x72\137\137\x63\x6d\x6e\x5f\137\x66\x6f\165\156\144\141\x74\x69\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\150\x74\155\154\x2e\164\167\x69\x67", $qookweymeqawmcwo); kucymsiiugmiooyo: return $nsmgceoqaqogqmuw; } }
