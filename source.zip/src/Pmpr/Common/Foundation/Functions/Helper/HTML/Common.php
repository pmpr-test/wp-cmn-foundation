<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192c055a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto cseucimaukwaskwk; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\162\x5f\137\x63\x6d\x6e\x5f\137\x66\x6f\165\x6e\144\x61\x74\x69\157\x6e\x2f{$qqscaoyqikuyeoaw}\56\150\164\x6d\154\56\164\x77\x69\x67", $qookweymeqawmcwo); cseucimaukwaskwk: return $nsmgceoqaqogqmuw; } }
