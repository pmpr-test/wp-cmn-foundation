<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mcyamakgwewogwqi; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\x72\x5f\x5f\x63\x6d\156\x5f\137\x66\157\x75\156\x64\x61\164\151\157\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\x68\164\155\154\x2e\164\167\151\147", $qookweymeqawmcwo); mcyamakgwewogwqi: return $nsmgceoqaqogqmuw; } }
