<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae859a8f03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto kmikysaiomgcocuq; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\162\137\137\x63\155\156\x5f\137\x66\x6f\165\156\144\x61\164\151\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\150\164\x6d\x6c\x2e\164\x77\151\147", $qookweymeqawmcwo); kmikysaiomgcocuq: return $nsmgceoqaqogqmuw; } }
