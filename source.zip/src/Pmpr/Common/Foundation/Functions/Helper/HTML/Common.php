<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto gqqeucaekwcskwqm; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\137\137\143\155\156\x5f\137\x66\157\165\156\144\141\164\x69\x6f\x6e\57{$qqscaoyqikuyeoaw}\56\x68\x74\155\154\x2e\164\167\151\147", $qookweymeqawmcwo); gqqeucaekwcskwqm: return $nsmgceoqaqogqmuw; } }
