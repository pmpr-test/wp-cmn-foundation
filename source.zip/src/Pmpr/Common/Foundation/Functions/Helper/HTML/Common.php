<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto kimusawigieceeai; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\x72\137\x5f\143\x6d\x6e\x5f\137\x66\x6f\x75\x6e\144\141\x74\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\x6d\x6c\x2e\164\x77\x69\147", $qookweymeqawmcwo); kimusawigieceeai: return $nsmgceoqaqogqmuw; } }
