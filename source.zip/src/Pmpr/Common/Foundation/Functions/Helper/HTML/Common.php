<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffe229367             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\x40\160\162\x5f\x5f\x63\x6d\x6e\x5f\137\146\x6f\165\x6e\x64\x61\164\151\157\x6e\57{$qqscaoyqikuyeoaw}\56\150\164\x6d\154\56\x74\167\151\x67", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
