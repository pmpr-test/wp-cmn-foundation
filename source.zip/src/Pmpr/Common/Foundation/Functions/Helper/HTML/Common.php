<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f5710e7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto iceweuyyswquiiea; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\137\137\143\155\156\137\137\x66\157\165\156\144\x61\x74\x69\x6f\x6e\57{$qqscaoyqikuyeoaw}\56\150\164\155\x6c\56\164\167\x69\x67", $qookweymeqawmcwo); iceweuyyswquiiea: return $nsmgceoqaqogqmuw; } }
