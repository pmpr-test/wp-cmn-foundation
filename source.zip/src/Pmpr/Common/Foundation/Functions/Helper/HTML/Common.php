<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6794e7648968d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\x40\160\x72\x5f\x5f\143\x6d\x6e\x5f\137\146\x6f\165\156\x64\141\164\x69\157\156\57{$qqscaoyqikuyeoaw}\x2e\x68\x74\x6d\154\56\x74\x77\x69\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
