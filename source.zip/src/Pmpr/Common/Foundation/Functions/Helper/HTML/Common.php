<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto cseucimaukwaskwk; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\x72\x5f\137\143\x6d\156\x5f\x5f\x66\157\165\156\144\141\x74\x69\157\156\x2f{$qqscaoyqikuyeoaw}\56\x68\164\x6d\x6c\x2e\x74\167\x69\147", $qookweymeqawmcwo); cseucimaukwaskwk: return $nsmgceoqaqogqmuw; } }
