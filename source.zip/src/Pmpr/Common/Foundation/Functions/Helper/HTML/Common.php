<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76ba63557             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto awkgycqimgayoaiy; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\x72\x5f\x5f\x63\x6d\x6e\x5f\x5f\146\157\165\x6e\144\x61\x74\151\157\x6e\57{$qqscaoyqikuyeoaw}\56\150\x74\x6d\x6c\56\164\x77\151\147", $qookweymeqawmcwo); awkgycqimgayoaiy: return $nsmgceoqaqogqmuw; } }
