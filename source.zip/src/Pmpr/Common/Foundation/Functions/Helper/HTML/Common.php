<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6af0adcff6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mgkikasuaseesumm; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\x72\137\x5f\143\155\156\137\137\x66\x6f\x75\x6e\x64\141\x74\x69\157\x6e\57{$qqscaoyqikuyeoaw}\x2e\150\164\155\x6c\x2e\164\x77\x69\147", $qookweymeqawmcwo); mgkikasuaseesumm: return $nsmgceoqaqogqmuw; } }
