<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522a8f9030b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\100\x70\x72\x5f\137\x63\155\x6e\137\x5f\146\x6f\x75\156\x64\x61\x74\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\155\154\56\164\167\x69\x67", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
