<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a92bf092             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\x40\160\162\x5f\137\143\155\x6e\x5f\137\x66\x6f\x75\x6e\x64\141\x74\x69\x6f\x6e\57{$qqscaoyqikuyeoaw}\x2e\150\x74\x6d\x6c\56\x74\x77\151\x67", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
