<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4e36cacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\100\x70\162\137\x5f\x63\155\156\137\137\x66\157\x75\x6e\144\141\x74\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\56\x68\x74\x6d\x6c\56\x74\x77\x69\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
