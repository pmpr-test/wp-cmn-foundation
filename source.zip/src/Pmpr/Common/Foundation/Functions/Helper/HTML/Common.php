<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517460aacd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto wwuiwkkgqescsyyw; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\162\137\137\x63\x6d\156\x5f\x5f\x66\x6f\165\156\x64\141\x74\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\56\150\164\x6d\154\56\x74\x77\x69\x67", $qookweymeqawmcwo); wwuiwkkgqescsyyw: return $nsmgceoqaqogqmuw; } }
