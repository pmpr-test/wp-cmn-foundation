<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e3ee38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\x40\x70\162\x5f\137\x63\x6d\156\x5f\137\146\157\x75\x6e\x64\141\x74\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\56\x68\x74\155\x6c\56\x74\167\x69\x67", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
