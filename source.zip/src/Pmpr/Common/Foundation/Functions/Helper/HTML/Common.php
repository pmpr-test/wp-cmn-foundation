<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c4949867             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto kucymsiiugmiooyo; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\137\x5f\143\155\156\x5f\x5f\x66\157\x75\x6e\144\x61\x74\151\157\x6e\57{$qqscaoyqikuyeoaw}\x2e\150\164\155\x6c\56\x74\167\x69\147", $qookweymeqawmcwo); kucymsiiugmiooyo: return $nsmgceoqaqogqmuw; } }
