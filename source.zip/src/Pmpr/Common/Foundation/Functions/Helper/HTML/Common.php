<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto iceweuyyswquiiea; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\160\162\x5f\x5f\x63\x6d\156\x5f\137\x66\157\x75\x6e\144\141\164\x69\x6f\x6e\57{$qqscaoyqikuyeoaw}\x2e\x68\164\155\x6c\56\x74\x77\x69\147", $qookweymeqawmcwo); iceweuyyswquiiea: return $nsmgceoqaqogqmuw; } }
