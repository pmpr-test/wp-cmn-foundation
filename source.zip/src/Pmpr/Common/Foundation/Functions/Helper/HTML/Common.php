<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a408a2b74             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto kimusawigieceeai; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\162\x5f\137\x63\x6d\x6e\137\x5f\x66\x6f\165\x6e\x64\141\164\151\157\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\150\164\x6d\154\x2e\164\167\151\x67", $qookweymeqawmcwo); kimusawigieceeai: return $nsmgceoqaqogqmuw; } }
