<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670598d3a6ee7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\100\160\162\x5f\137\x63\x6d\x6e\x5f\x5f\x66\x6f\x75\156\x64\141\164\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\56\x68\x74\x6d\154\x2e\x74\x77\151\x67", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
