<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto ugiuakmiswagycwy; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\162\137\137\x63\155\x6e\137\x5f\146\157\x75\156\144\141\164\151\157\156\57{$qqscaoyqikuyeoaw}\x2e\150\164\155\154\56\x74\x77\151\x67", $qookweymeqawmcwo); ugiuakmiswagycwy: return $nsmgceoqaqogqmuw; } }
