<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da680f9db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto uossiqykiaouimca; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\x72\x5f\137\143\x6d\156\137\137\x66\x6f\165\x6e\144\x61\x74\151\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\150\164\155\154\56\164\x77\x69\x67", $qookweymeqawmcwo); uossiqykiaouimca: return $nsmgceoqaqogqmuw; } }
