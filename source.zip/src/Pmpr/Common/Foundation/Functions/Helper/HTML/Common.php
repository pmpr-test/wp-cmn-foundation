<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e17b763d23d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mcyamakgwewogwqi; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\x72\137\x5f\x63\155\x6e\137\137\x66\157\x75\156\144\x61\164\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\56\x68\x74\155\154\56\164\x77\x69\147", $qookweymeqawmcwo); mcyamakgwewogwqi: return $nsmgceoqaqogqmuw; } }
