<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791524c10e10             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\x40\x70\x72\x5f\x5f\143\155\156\x5f\x5f\x66\157\165\x6e\x64\141\x74\x69\x6f\156\57{$qqscaoyqikuyeoaw}\56\x68\164\155\x6c\x2e\x74\167\151\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
