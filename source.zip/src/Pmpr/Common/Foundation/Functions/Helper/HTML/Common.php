<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2e8864db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto omkwqeiacwosgskq; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\162\x5f\x5f\x63\155\156\x5f\x5f\x66\x6f\x75\x6e\144\141\164\x69\157\x6e\x2f{$qqscaoyqikuyeoaw}\56\150\164\155\154\56\x74\x77\x69\147", $qookweymeqawmcwo); omkwqeiacwosgskq: return $nsmgceoqaqogqmuw; } }
