<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68174a1e87cdd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class Regex extends Common { }
