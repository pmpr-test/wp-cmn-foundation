<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68821138ddb03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class Regex extends Common { }
