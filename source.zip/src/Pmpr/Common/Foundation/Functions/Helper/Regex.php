<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68855d4d90b7d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class Regex extends Common { }
