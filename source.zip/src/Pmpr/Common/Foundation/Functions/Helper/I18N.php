<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132d18d1e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class I18N extends Common { public function eusockqasqqmoess($eusockqasqqmoess, $locale = null) { $kcqgsouywoiekwak = $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\x72\141\x6e\163\x5f\156\x75\x6d\x62\145\162", $eusockqasqqmoess, $locale); if (!(is_numeric($eusockqasqqmoess) && (string) $kcqgsouywoiekwak === (string) $eusockqasqqmoess)) { goto ueeuassqywswigaq; } $kcqgsouywoiekwak = number_format_i18n((float) $eusockqasqqmoess); ueeuassqywswigaq: return $kcqgsouywoiekwak; } public function aoaesiikusqamcqc($cmwygeyygwqaemaq, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x74\162\141\156\163\x5f\x77\x6f\x72\x64", $cmwygeyygwqaemaq, $locale); } public function ekasyoagocygouom($ocogsiouoiuuguym, $saqmwwmqiwmkiwaa = null, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x74\x72\x61\x6e\x73\137\144\141\164\x65\x74\151\x6d\145", $ocogsiouoiuuguym, $saqmwwmqiwmkiwaa, $locale); } }
