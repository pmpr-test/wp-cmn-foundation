<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0000cbc1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class I18N extends Common { public function eusockqasqqmoess($eusockqasqqmoess, $locale = null) { $kcqgsouywoiekwak = $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x74\162\141\156\163\x5f\156\165\x6d\142\145\x72", $eusockqasqqmoess, $locale); if (is_numeric($eusockqasqqmoess) && (string) $kcqgsouywoiekwak === (string) $eusockqasqqmoess) { $kcqgsouywoiekwak = number_format_i18n((float) $eusockqasqqmoess); } return $kcqgsouywoiekwak; } public function aoaesiikusqamcqc($cmwygeyygwqaemaq, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\162\141\x6e\x73\137\167\x6f\x72\144", $cmwygeyygwqaemaq, $locale); } public function ekasyoagocygouom($ocogsiouoiuuguym, $saqmwwmqiwmkiwaa = null, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\x72\141\156\x73\x5f\144\141\x74\145\x74\x69\155\145", $ocogsiouoiuuguym, $saqmwwmqiwmkiwaa, $locale); } }
