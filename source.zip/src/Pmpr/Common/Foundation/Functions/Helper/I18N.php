<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class I18N extends Common { public function eusockqasqqmoess($eusockqasqqmoess, $locale = null) { $kcqgsouywoiekwak = $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\162\141\156\x73\x5f\156\165\x6d\142\145\162", $eusockqasqqmoess, $locale); if (!(is_numeric($eusockqasqqmoess) && (string) $kcqgsouywoiekwak === (string) $eusockqasqqmoess)) { goto quyumosiyumgeqao; } $kcqgsouywoiekwak = number_format_i18n((float) $eusockqasqqmoess); quyumosiyumgeqao: return $kcqgsouywoiekwak; } public function aoaesiikusqamcqc($cmwygeyygwqaemaq, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\x72\141\156\163\137\x77\157\x72\x64", $cmwygeyygwqaemaq, $locale); } public function ekasyoagocygouom($ocogsiouoiuuguym, $saqmwwmqiwmkiwaa = null, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x74\162\141\x6e\x73\137\144\x61\x74\145\x74\151\x6d\145", $ocogsiouoiuuguym, $saqmwwmqiwmkiwaa, $locale); } }
