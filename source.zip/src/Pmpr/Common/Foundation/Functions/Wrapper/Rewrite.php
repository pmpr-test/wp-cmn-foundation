<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7c471feb6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper; class Rewrite extends Common { public function ggqucmukcaycuckk(bool $wqgoeumkaeyqaiqu = true) { flush_rewrite_rules($wqgoeumkaeyqaiqu); } public function aimosgcaukumakge(string $ucccueqywigcukcc, $gqgemcmoicmgaqie, string $miisqgccsqqcscia = 'bottom') : self { add_rewrite_rule($ucccueqywigcukcc, $gqgemcmoicmgaqie, $miisqgccsqqcscia); return $this; } public function oqcysukiikmcoemm(string $scwiymciagumsuiw, string $ucccueqywigcukcc, string $gqgemcmoicmgaqie = '') { add_rewrite_tag($scwiymciagumsuiw, $ucccueqywigcukcc, $gqgemcmoicmgaqie); } public function sqwyuucgyowmqcgc(string $ymqmyyeuycgmigyo, int $wwqoakwweuiyqgco, $emmugacswycqccku = true) { add_rewrite_endpoint($ymqmyyeuycgmigyo, $wwqoakwweuiyqgco, $emmugacswycqccku); } }
