<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d54c9a6ea1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper; class Rewrite extends Common { public function ggqucmukcaycuckk(bool $wqgoeumkaeyqaiqu = true) { flush_rewrite_rules($wqgoeumkaeyqaiqu); } public function aimosgcaukumakge(string $ucccueqywigcukcc, $gqgemcmoicmgaqie, string $miisqgccsqqcscia = "\x62\157\164\x74\157\x6d") { add_rewrite_rule($ucccueqywigcukcc, $gqgemcmoicmgaqie, $miisqgccsqqcscia); } public function oqcysukiikmcoemm(string $scwiymciagumsuiw, string $ucccueqywigcukcc, string $gqgemcmoicmgaqie = '') { add_rewrite_tag($scwiymciagumsuiw, $ucccueqywigcukcc, $gqgemcmoicmgaqie); } public function sqwyuucgyowmqcgc(string $ymqmyyeuycgmigyo, int $wwqoakwweuiyqgco, $emmugacswycqccku = true) { add_rewrite_endpoint($ymqmyyeuycgmigyo, $wwqoakwweuiyqgco, $emmugacswycqccku); } }
