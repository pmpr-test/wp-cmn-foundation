<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693022bb3e0cc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; class Dokan extends Common { public function usgmmimoysimeueu() : bool { return $this->call('dokan_is_seller_dashboard', false); } public function kegwcamycygyqkgk() { return $this->call('dokan_current_datetime', ''); } }
