<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693893a838b1e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; class Dokan extends Common { public function usgmmimoysimeueu() : bool { return $this->call('dokan_is_seller_dashboard', false); } public function kegwcamycygyqkgk() { return $this->call('dokan_current_datetime', ''); } public function mwiecsoawewcsuim(string $ymqmyyeuycgmigyo = '', bool $gowwokmucauqoeko = false) { return $this->call('dokan_get_navigation_url', '', $ymqmyyeuycgmigyo, $gowwokmucauqoeko); } }
