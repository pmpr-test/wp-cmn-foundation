<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a0b3200e3f8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; class Dokan extends Common { public function usgmmimoysimeueu() : bool { return $this->call('dokan_is_seller_dashboard', false); } public function kegwcamycygyqkgk() { return $this->call('dokan_current_datetime', ''); } public function ioukiqsgoygcgmma($kkcmysmouoyqaiyu) { return $this->call('dokan_count_orders', [], $kkcmysmouoyqaiyu); } public function caousskaeqikuegw() { return $this->call('dokan_get_current_user_id', 0); } public function qacceiuuqmiekaeo($kkcmysmouoyqaiyu, $gkkgcoiwayaccqgm) { return $this->call('dokan_is_seller_has_order', false, $kkcmysmouoyqaiyu, $gkkgcoiwayaccqgm); } public function giiuwsmyumqwwiyq($omkysikckkcieckq, $awcmekyiwwkeyisq, $ggauoeuaesiymgee = '') { return $this->call('dokan_get_option', null, $omkysikckkcieckq, $awcmekyiwwkeyisq, $ggauoeuaesiymgee); } public function mwiecsoawewcsuim(string $ymqmyyeuycgmigyo = '', bool $gowwokmucauqoeko = false) { return $this->call('dokan_get_navigation_url', '', $ymqmyyeuycgmigyo, $gowwokmucauqoeko); } }
