<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6776ec4d79b1c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\x65\162\x79\137\x70\154\x75\x67\151\x6e\x73") { if (!function_exists("\160\154\x75\x67\x69\156\163\137\141\x70\x69")) { include_once ABSPATH . "\167\x70\x2d\x61\x64\155\151\156\x2f\x69\x6e\143\x6c\165\x64\145\163\57\x70\154\165\147\x69\x6e\55\151\x6e\163\164\x61\x6c\154\56\x70\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\x5f\160\154\x75\147\151\156\x5f\x61\143\164\151\166\x65")) { include_once ABSPATH . "\x77\160\55\141\144\155\x69\156\57\x69\x6e\143\x6c\165\144\x65\163\57\x70\x6c\165\147\151\156\x2e\x70\x68\160"; } return $this->call("\x69\163\x5f\160\154\165\x67\151\156\x5f\x61\x63\164\151\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\x70\x6c\x75\147\x69\x6e\x5f\x61\x63\164\x69\166\x65\137\x66\157\162\137\156\145\x74\167\157\x72\x6b", false, $mkysicwccoeicumg); } }
