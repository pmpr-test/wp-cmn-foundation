<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6780382025b61             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\145\x72\x79\x5f\160\154\165\x67\x69\156\x73") { if (!function_exists("\160\x6c\x75\147\x69\156\x73\137\x61\x70\x69")) { include_once ABSPATH . "\167\x70\x2d\141\x64\x6d\x69\x6e\x2f\151\x6e\143\x6c\165\x64\145\163\x2f\160\x6c\x75\147\151\156\55\x69\x6e\x73\164\x61\154\x6c\x2e\x70\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\x5f\160\154\165\147\151\x6e\137\x61\x63\164\151\x76\x65")) { include_once ABSPATH . "\167\x70\55\x61\144\x6d\x69\x6e\x2f\151\x6e\143\x6c\x75\x64\145\x73\x2f\x70\x6c\165\147\x69\156\x2e\x70\150\160"; } return $this->call("\151\163\137\160\x6c\x75\x67\x69\156\137\x61\143\x74\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\x70\154\165\147\151\156\x5f\x61\x63\164\x69\166\x65\137\146\x6f\x72\137\x6e\145\164\x77\157\162\153", false, $mkysicwccoeicumg); } }
