<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675815b967a0e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\145\162\x79\137\160\154\x75\x67\151\156\163") { if (!function_exists("\x70\x6c\x75\x67\151\x6e\x73\x5f\x61\160\x69")) { include_once ABSPATH . "\x77\x70\55\141\x64\155\x69\x6e\57\151\156\143\154\x75\144\145\x73\57\x70\154\x75\147\151\156\55\x69\x6e\x73\164\x61\x6c\154\56\x70\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\160\x6c\x75\x67\x69\156\137\141\x63\164\x69\x76\145")) { include_once ABSPATH . "\167\160\55\141\144\155\x69\x6e\x2f\151\x6e\x63\x6c\x75\144\x65\x73\57\x70\154\165\x67\151\156\x2e\x70\x68\160"; } return $this->call("\151\163\x5f\160\x6c\165\x67\x69\x6e\x5f\141\x63\164\151\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\x70\x6c\165\x67\x69\156\x5f\141\x63\x74\151\166\145\137\146\157\162\137\156\145\164\167\157\162\x6b", false, $mkysicwccoeicumg); } }
