<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d585ed47eb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\145\162\171\x5f\160\154\165\147\x69\x6e\x73") { if (!function_exists("\160\x6c\165\147\x69\x6e\x73\137\x61\160\x69")) { include_once ABSPATH . "\167\160\55\141\x64\155\x69\156\57\x69\x6e\143\x6c\x75\x64\x65\x73\x2f\160\154\165\x67\x69\x6e\55\x69\156\163\164\141\154\154\x2e\x70\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\137\x70\x6c\x75\x67\151\156\137\141\x63\x74\x69\x76\x65")) { include_once ABSPATH . "\x77\160\x2d\x61\144\x6d\151\x6e\x2f\151\x6e\x63\x6c\x75\x64\145\x73\57\160\154\165\147\151\156\56\160\150\x70"; } return $this->call("\x69\163\x5f\160\x6c\165\x67\x69\x6e\137\141\143\x74\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\x70\x6c\165\147\151\156\137\x61\143\x74\x69\x76\145\x5f\146\157\162\137\156\x65\164\x77\157\x72\153", false, $mkysicwccoeicumg); } }
