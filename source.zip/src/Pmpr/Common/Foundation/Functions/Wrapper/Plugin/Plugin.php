<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b5520cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\x65\x72\171\137\x70\x6c\165\x67\151\x6e\163") { if (!function_exists("\160\154\165\147\151\156\x73\137\x61\160\151")) { include_once ABSPATH . "\167\x70\x2d\x61\x64\x6d\x69\156\x2f\151\156\143\x6c\165\144\x65\163\57\x70\154\165\x67\x69\x6e\55\151\156\163\164\141\154\x6c\x2e\x70\x68\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\x5f\x70\154\165\x67\x69\156\x5f\141\143\164\x69\x76\145")) { include_once ABSPATH . "\167\x70\55\141\144\155\x69\156\x2f\x69\x6e\x63\x6c\165\144\x65\163\57\160\x6c\x75\147\151\x6e\x2e\160\150\160"; } return $this->call("\151\163\x5f\160\154\165\x67\x69\x6e\137\141\x63\x74\x69\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\160\x6c\165\x67\151\x6e\137\141\x63\x74\x69\166\x65\x5f\x66\x6f\162\137\x6e\x65\x74\167\x6f\162\153", false, $mkysicwccoeicumg); } }
