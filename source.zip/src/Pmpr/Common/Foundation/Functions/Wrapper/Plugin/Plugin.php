<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e176fddf2d5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\162\x79\137\160\x6c\165\147\151\x6e\163") { if (!function_exists("\x70\x6c\165\147\x69\x6e\x73\x5f\x61\160\x69")) { include_once ABSPATH . "\167\x70\x2d\141\144\x6d\151\156\57\x69\x6e\x63\154\x75\x64\x65\x73\57\160\x6c\165\x67\x69\x6e\x2d\x69\156\163\x74\x61\154\154\56\x70\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\160\154\165\147\151\156\137\x61\143\x74\x69\166\145")) { include_once ABSPATH . "\167\x70\55\x61\144\155\151\156\x2f\151\156\x63\154\x75\144\145\163\x2f\x70\x6c\x75\x67\x69\156\x2e\160\x68\x70"; } return $this->call("\151\163\x5f\160\154\165\x67\151\x6e\x5f\141\143\164\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\160\x6c\x75\147\151\156\x5f\141\x63\164\151\166\x65\x5f\146\157\x72\x5f\156\x65\x74\x77\x6f\x72\153", false, $mkysicwccoeicumg); } }
