<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfc3785             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\145\x72\x79\x5f\160\154\165\147\x69\x6e\x73") { if (!function_exists("\x70\x6c\x75\147\151\x6e\163\x5f\141\x70\x69")) { include_once ABSPATH . "\x77\160\55\x61\144\x6d\x69\156\x2f\151\x6e\x63\154\x75\144\x65\x73\57\x70\154\x75\x67\151\x6e\x2d\x69\156\x73\164\141\x6c\154\x2e\x70\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\137\x70\154\165\x67\151\x6e\137\141\143\x74\x69\166\x65")) { include_once ABSPATH . "\167\x70\55\141\144\155\x69\156\x2f\151\156\143\154\x75\144\x65\163\57\160\154\x75\147\x69\x6e\x2e\x70\150\x70"; } return $this->call("\x69\163\x5f\x70\154\x75\147\x69\x6e\x5f\x61\143\164\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\x5f\x70\154\165\147\x69\156\137\141\143\164\151\x76\145\x5f\146\x6f\x72\137\x6e\145\164\167\x6f\162\153", false, $mkysicwccoeicumg); } }
