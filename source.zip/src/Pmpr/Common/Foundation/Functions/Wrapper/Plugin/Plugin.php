<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c47480ec             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\x65\162\x79\137\160\x6c\165\x67\151\156\x73") { if (!function_exists("\x70\x6c\165\x67\x69\156\x73\x5f\x61\160\151")) { include_once ABSPATH . "\x77\x70\55\141\x64\x6d\x69\x6e\x2f\151\x6e\143\154\165\x64\145\163\57\160\x6c\x75\x67\x69\x6e\x2d\x69\x6e\163\x74\141\x6c\x6c\56\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\x5f\160\x6c\165\147\x69\156\x5f\x61\143\x74\x69\166\x65")) { include_once ABSPATH . "\x77\160\55\141\144\x6d\x69\x6e\x2f\x69\x6e\x63\x6c\165\x64\x65\163\x2f\x70\154\165\147\x69\x6e\x2e\x70\150\160"; } return $this->call("\x69\163\x5f\x70\x6c\x75\147\x69\x6e\x5f\x61\x63\164\x69\166\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\x5f\160\154\x75\147\x69\156\x5f\x61\x63\x74\151\166\x65\137\x66\157\x72\137\x6e\x65\x74\167\x6f\162\x6b", false, $mkysicwccoeicumg); } }
