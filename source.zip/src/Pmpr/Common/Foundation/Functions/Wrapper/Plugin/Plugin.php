<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4df75a3df             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\x72\x79\x5f\160\x6c\x75\x67\x69\x6e\163") { if (!function_exists("\x70\x6c\x75\x67\151\156\x73\x5f\141\x70\151")) { include_once ABSPATH . "\x77\x70\x2d\x61\x64\x6d\x69\156\x2f\151\156\x63\154\165\x64\145\x73\57\160\154\x75\147\151\156\55\151\x6e\163\164\141\x6c\x6c\56\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\137\x70\154\165\147\151\x6e\x5f\141\143\164\151\166\145")) { include_once ABSPATH . "\167\x70\x2d\141\x64\x6d\151\x6e\x2f\151\x6e\x63\x6c\x75\144\145\x73\x2f\160\154\x75\147\151\x6e\56\160\x68\160"; } return $this->call("\151\163\x5f\160\154\x75\x67\x69\x6e\x5f\141\x63\164\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\x70\x6c\165\x67\151\x6e\137\x61\143\x74\x69\166\145\137\146\157\162\x5f\156\x65\164\167\x6f\x72\x6b", false, $mkysicwccoeicumg); } }
