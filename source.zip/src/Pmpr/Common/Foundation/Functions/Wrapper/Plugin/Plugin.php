<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d08e0f3960             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\x72\x79\137\x70\x6c\165\x67\x69\x6e\163") { if (!function_exists("\160\x6c\165\147\151\156\163\137\x61\x70\151")) { include_once ABSPATH . "\x77\x70\55\x61\144\155\x69\x6e\x2f\151\156\143\154\165\144\x65\163\x2f\160\x6c\x75\x67\x69\x6e\55\x69\156\163\164\x61\x6c\154\x2e\160\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\137\x70\x6c\165\x67\151\156\137\x61\x63\x74\151\x76\x65")) { include_once ABSPATH . "\167\160\x2d\141\144\155\x69\156\57\151\156\x63\154\x75\144\145\163\x2f\160\154\165\147\151\x6e\x2e\160\x68\x70"; } return $this->call("\x69\163\x5f\x70\x6c\165\147\151\156\x5f\x61\143\x74\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\160\x6c\165\x67\x69\x6e\137\x61\143\164\151\166\x65\137\146\x6f\x72\137\x6e\145\164\167\157\x72\x6b", false, $mkysicwccoeicumg); } }
