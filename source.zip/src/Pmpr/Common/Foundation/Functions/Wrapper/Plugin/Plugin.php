<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6af0adcff6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\145\162\171\137\160\x6c\x75\x67\151\x6e\163") { if (!function_exists("\x70\x6c\165\147\x69\156\x73\137\141\160\x69")) { include_once ABSPATH . "\167\160\x2d\141\144\x6d\151\x6e\x2f\151\x6e\143\x6c\x75\x64\x65\x73\x2f\x70\x6c\165\x67\x69\x6e\55\151\156\x73\164\x61\x6c\x6c\56\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\137\160\154\165\147\151\156\x5f\141\143\164\151\x76\145")) { include_once ABSPATH . "\x77\160\55\x61\x64\155\x69\156\57\x69\x6e\143\x6c\x75\144\x65\x73\57\160\x6c\165\x67\151\156\56\x70\x68\x70"; } return $this->call("\x69\x73\x5f\x70\154\x75\x67\x69\156\x5f\x61\143\164\151\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\x5f\160\154\165\x67\x69\x6e\137\x61\x63\164\x69\166\x65\137\x66\x6f\x72\137\156\x65\x74\x77\x6f\x72\153", false, $mkysicwccoeicumg); } }
