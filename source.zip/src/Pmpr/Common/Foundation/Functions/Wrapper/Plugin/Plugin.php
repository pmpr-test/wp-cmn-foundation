<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e17b763d23d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\145\x72\171\137\x70\154\x75\147\x69\156\163") { if (!function_exists("\160\154\x75\147\151\x6e\163\x5f\x61\x70\151")) { include_once ABSPATH . "\x77\x70\55\141\144\x6d\151\156\x2f\151\156\x63\154\165\x64\x65\x73\x2f\160\x6c\165\147\151\156\x2d\151\156\163\164\141\154\154\x2e\160\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\137\x70\x6c\x75\147\151\x6e\137\x61\x63\164\x69\x76\x65")) { include_once ABSPATH . "\167\x70\x2d\x61\x64\x6d\151\156\57\x69\156\x63\154\x75\144\145\x73\x2f\160\154\165\147\x69\156\56\160\150\160"; } return $this->call("\151\163\137\160\x6c\165\x67\151\x6e\x5f\141\x63\x74\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\x70\x6c\165\x67\x69\156\137\x61\x63\x74\151\x76\145\137\146\x6f\162\137\156\145\x74\167\157\162\153", false, $mkysicwccoeicumg); } }
