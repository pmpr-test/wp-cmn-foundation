<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9f11bf9d9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\x72\171\137\x70\154\x75\x67\151\156\163") { if (!function_exists("\160\x6c\165\x67\151\x6e\x73\137\x61\160\x69")) { include_once ABSPATH . "\167\x70\55\141\x64\x6d\x69\x6e\x2f\x69\156\x63\x6c\x75\x64\x65\x73\x2f\x70\154\x75\x67\x69\156\x2d\151\x6e\163\x74\x61\x6c\154\56\160\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\137\160\154\165\147\x69\156\137\141\x63\x74\x69\166\145")) { include_once ABSPATH . "\x77\x70\55\141\144\x6d\151\x6e\57\151\x6e\x63\x6c\x75\x64\145\x73\57\x70\154\x75\147\x69\x6e\x2e\x70\x68\160"; } return $this->call("\151\x73\x5f\x70\154\x75\147\x69\x6e\x5f\141\143\164\151\166\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\137\160\154\x75\147\x69\156\x5f\x61\x63\x74\151\x76\x65\137\x66\x6f\162\x5f\x6e\145\164\x77\x6f\162\153", false, $mkysicwccoeicumg); } }
