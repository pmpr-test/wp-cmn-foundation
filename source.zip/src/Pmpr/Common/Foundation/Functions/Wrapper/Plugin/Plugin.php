<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b645383f9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\145\x72\x79\137\x70\x6c\x75\x67\x69\156\x73") { if (!function_exists("\160\x6c\x75\x67\x69\156\163\x5f\141\x70\151")) { include_once ABSPATH . "\167\160\x2d\141\x64\x6d\x69\x6e\57\x69\x6e\x63\154\x75\144\x65\163\x2f\x70\x6c\165\147\151\156\55\151\156\x73\x74\x61\x6c\x6c\56\160\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\137\x70\x6c\x75\x67\x69\156\x5f\x61\x63\164\151\166\x65")) { include_once ABSPATH . "\x77\x70\x2d\141\x64\155\151\x6e\x2f\x69\156\143\154\165\x64\x65\x73\x2f\x70\x6c\165\x67\x69\x6e\x2e\x70\x68\x70"; } return $this->call("\151\163\137\x70\x6c\x75\147\x69\156\137\x61\x63\x74\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\137\x70\154\165\x67\x69\x6e\x5f\x61\x63\x74\151\166\145\137\x66\157\x72\x5f\156\145\164\167\157\x72\x6b", false, $mkysicwccoeicumg); } }
