<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6775ab151db83             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\162\171\137\x70\154\x75\147\x69\x6e\x73") { if (!function_exists("\160\x6c\x75\147\151\156\163\137\x61\160\151")) { include_once ABSPATH . "\x77\x70\55\x61\x64\x6d\151\x6e\57\151\156\x63\x6c\x75\144\145\163\57\x70\154\165\x67\x69\x6e\x2d\151\x6e\x73\164\x61\154\154\x2e\160\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\137\160\154\165\147\151\x6e\137\x61\x63\164\151\166\145")) { include_once ABSPATH . "\x77\160\55\141\x64\155\151\x6e\x2f\x69\156\x63\x6c\165\x64\x65\163\57\160\154\165\147\x69\x6e\56\x70\150\160"; } return $this->call("\x69\163\x5f\x70\x6c\x75\x67\x69\x6e\137\x61\x63\164\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\160\154\165\x67\x69\x6e\x5f\x61\143\x74\x69\166\145\137\x66\157\x72\x5f\x6e\145\x74\167\x6f\162\x6b", false, $mkysicwccoeicumg); } }
