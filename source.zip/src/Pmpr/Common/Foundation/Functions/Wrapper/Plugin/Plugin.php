<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835e37313             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\x65\162\x79\x5f\160\x6c\165\x67\151\156\x73") { if (!function_exists("\160\x6c\x75\x67\x69\x6e\x73\137\x61\x70\x69")) { include_once ABSPATH . "\x77\x70\55\x61\x64\155\x69\x6e\57\x69\x6e\x63\154\165\144\145\x73\57\x70\154\x75\147\x69\x6e\55\151\156\163\164\x61\154\x6c\x2e\x70\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\x70\154\165\x67\151\156\x5f\x61\x63\x74\151\x76\145")) { include_once ABSPATH . "\167\x70\x2d\141\x64\155\151\x6e\57\151\156\x63\x6c\165\144\x65\163\x2f\160\154\x75\147\151\156\56\160\x68\160"; } return $this->call("\151\x73\x5f\x70\x6c\x75\x67\x69\156\137\x61\x63\164\x69\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\x5f\160\x6c\165\x67\x69\156\137\141\143\x74\151\x76\x65\137\146\x6f\162\x5f\156\x65\x74\x77\157\x72\x6b", false, $mkysicwccoeicumg); } }
