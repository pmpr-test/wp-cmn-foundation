<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670598d3a6ee7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\162\x79\137\x70\154\x75\147\x69\x6e\x73") { if (!function_exists("\x70\154\x75\147\151\156\163\x5f\x61\160\151")) { include_once ABSPATH . "\167\x70\x2d\141\144\x6d\151\x6e\x2f\151\156\x63\154\x75\x64\x65\163\x2f\160\154\x75\x67\x69\156\x2d\151\x6e\x73\x74\141\154\154\56\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\137\x70\x6c\x75\x67\151\156\137\141\x63\164\x69\x76\x65")) { include_once ABSPATH . "\167\160\x2d\141\x64\155\x69\156\57\151\x6e\143\x6c\165\x64\x65\x73\x2f\160\154\165\x67\x69\156\56\160\150\x70"; } return $this->call("\151\163\137\x70\x6c\x75\x67\x69\x6e\x5f\x61\x63\164\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\x70\154\x75\147\x69\156\137\x61\x63\x74\151\166\145\137\x66\157\162\137\x6e\145\x74\x77\157\162\x6b", false, $mkysicwccoeicumg); } }
