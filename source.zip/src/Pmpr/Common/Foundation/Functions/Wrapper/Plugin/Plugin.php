<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f4306668ee2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\x65\162\x79\137\x70\154\165\147\151\x6e\163") { if (!function_exists("\160\x6c\165\147\x69\156\163\x5f\x61\x70\151")) { include_once ABSPATH . "\x77\x70\55\x61\x64\x6d\151\156\x2f\151\156\x63\154\165\144\145\163\x2f\x70\154\x75\147\x69\156\x2d\x69\x6e\163\164\x61\x6c\x6c\56\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\x5f\160\x6c\x75\x67\x69\x6e\137\141\x63\164\x69\166\145")) { include_once ABSPATH . "\167\160\55\141\144\x6d\x69\x6e\x2f\151\x6e\143\154\x75\x64\145\163\x2f\x70\154\x75\x67\151\156\56\160\x68\160"; } return $this->call("\151\163\x5f\160\x6c\165\147\151\x6e\x5f\x61\143\164\x69\166\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\160\x6c\165\x67\151\156\137\x61\143\x74\151\166\145\137\x66\157\x72\x5f\x6e\145\x74\x77\157\x72\x6b", false, $mkysicwccoeicumg); } }
