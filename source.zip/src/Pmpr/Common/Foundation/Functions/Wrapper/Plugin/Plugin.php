<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d3647befc6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\145\x72\171\137\160\x6c\165\147\151\156\x73") { if (!function_exists("\x70\154\x75\147\151\156\163\x5f\x61\160\151")) { include_once ABSPATH . "\167\160\x2d\141\x64\x6d\151\x6e\57\x69\156\x63\x6c\x75\x64\x65\x73\x2f\x70\x6c\x75\147\151\156\55\151\x6e\x73\x74\x61\154\154\56\x70\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\x5f\x70\x6c\x75\x67\151\x6e\x5f\141\143\x74\x69\x76\145")) { include_once ABSPATH . "\167\x70\x2d\x61\x64\155\x69\x6e\57\151\156\x63\154\165\x64\x65\x73\x2f\160\154\165\x67\x69\x6e\x2e\x70\150\160"; } return $this->call("\x69\163\x5f\x70\x6c\x75\x67\151\x6e\x5f\141\143\164\151\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\x70\x6c\x75\147\151\x6e\x5f\141\143\x74\x69\x76\x65\137\x66\x6f\162\137\156\x65\x74\x77\x6f\x72\x6b", false, $mkysicwccoeicumg); } }
