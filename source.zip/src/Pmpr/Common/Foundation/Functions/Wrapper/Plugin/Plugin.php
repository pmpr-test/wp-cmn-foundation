<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\145\162\x79\x5f\x70\154\165\147\151\x6e\x73") { if (!function_exists("\160\154\165\x67\151\156\x73\x5f\141\160\x69")) { include_once ABSPATH . "\167\x70\x2d\141\144\x6d\x69\156\x2f\151\x6e\143\154\x75\x64\x65\163\57\160\154\165\x67\x69\156\55\151\156\x73\x74\141\x6c\154\56\x70\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\x5f\160\154\165\147\x69\156\137\x61\143\164\x69\x76\x65")) { include_once ABSPATH . "\x77\x70\55\x61\x64\155\x69\x6e\x2f\151\156\143\x6c\x75\144\145\163\x2f\160\x6c\165\x67\151\x6e\x2e\160\x68\x70"; } return $this->call("\x69\163\137\160\x6c\x75\147\x69\156\137\x61\143\x74\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\137\160\x6c\x75\x67\151\x6e\137\141\x63\164\x69\x76\x65\x5f\146\157\162\137\156\x65\x74\x77\157\x72\x6b", false, $mkysicwccoeicumg); } }
