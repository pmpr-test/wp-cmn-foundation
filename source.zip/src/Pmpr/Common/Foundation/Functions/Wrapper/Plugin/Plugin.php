<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fe543e50             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\162\x79\x5f\160\x6c\x75\147\x69\156\x73") { if (!function_exists("\160\x6c\165\x67\x69\156\x73\x5f\141\160\151")) { include_once ABSPATH . "\x77\160\x2d\141\x64\x6d\x69\x6e\57\x69\156\143\154\165\144\145\x73\57\160\154\165\x67\x69\x6e\x2d\x69\x6e\163\x74\141\x6c\x6c\56\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\160\x6c\165\x67\x69\x6e\x5f\141\x63\164\x69\166\x65")) { include_once ABSPATH . "\167\x70\55\141\x64\155\x69\156\57\x69\x6e\x63\154\165\x64\145\163\57\x70\x6c\x75\x67\x69\156\56\x70\150\160"; } return $this->call("\151\163\137\160\x6c\x75\x67\151\156\x5f\x61\143\x74\x69\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\160\154\x75\147\151\156\x5f\141\143\x74\x69\x76\x65\x5f\146\157\x72\x5f\x6e\x65\x74\x77\x6f\162\x6b", false, $mkysicwccoeicumg); } }
