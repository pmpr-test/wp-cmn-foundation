<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abcde521502             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\x65\162\171\137\160\x6c\165\147\x69\156\163") { if (!function_exists("\160\x6c\x75\147\151\156\x73\x5f\x61\160\x69")) { include_once ABSPATH . "\x77\x70\x2d\x61\x64\x6d\151\x6e\57\x69\x6e\x63\154\x75\144\x65\163\x2f\160\x6c\165\147\151\x6e\55\151\x6e\x73\164\141\x6c\x6c\56\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\137\x70\154\165\147\x69\156\x5f\141\143\164\151\x76\x65")) { include_once ABSPATH . "\x77\x70\55\141\144\155\151\x6e\x2f\x69\x6e\143\154\x75\x64\x65\163\x2f\160\x6c\165\x67\x69\156\56\x70\150\x70"; } return $this->call("\151\x73\137\x70\x6c\165\x67\151\x6e\137\141\143\x74\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\x5f\160\154\x75\147\151\156\x5f\x61\143\164\x69\x76\x65\x5f\x66\x6f\162\137\156\x65\x74\x77\x6f\162\153", false, $mkysicwccoeicumg); } }
