<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b088f1290             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\145\x72\171\137\160\154\165\x67\151\156\163") { if (!function_exists("\160\154\165\147\x69\x6e\x73\137\141\160\x69")) { include_once ABSPATH . "\x77\160\55\141\144\155\151\156\x2f\151\x6e\x63\154\165\x64\x65\x73\x2f\160\x6c\165\147\x69\156\x2d\x69\156\163\x74\141\x6c\154\x2e\160\x68\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\137\160\154\x75\x67\151\156\137\x61\143\x74\x69\x76\145")) { include_once ABSPATH . "\x77\160\55\x61\x64\155\151\x6e\x2f\151\156\x63\154\x75\144\145\163\57\160\x6c\x75\147\x69\156\x2e\160\x68\x70"; } return $this->call("\151\x73\x5f\x70\x6c\165\x67\x69\156\x5f\x61\x63\164\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\x5f\160\x6c\x75\147\x69\156\x5f\141\x63\164\151\166\145\137\x66\157\162\x5f\156\145\x74\x77\x6f\x72\x6b", false, $mkysicwccoeicumg); } }
