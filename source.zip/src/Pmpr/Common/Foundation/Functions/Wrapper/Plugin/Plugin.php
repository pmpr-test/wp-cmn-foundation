<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec064496439             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\145\162\x79\137\x70\154\165\147\151\x6e\163") { if (!function_exists("\160\x6c\165\147\151\x6e\163\137\141\160\x69")) { include_once ABSPATH . "\167\x70\x2d\x61\x64\x6d\x69\156\x2f\x69\x6e\143\x6c\165\144\145\x73\57\160\x6c\165\x67\x69\x6e\x2d\151\x6e\163\164\141\x6c\x6c\56\x70\x68\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\x5f\x70\x6c\x75\x67\x69\x6e\137\x61\x63\164\151\x76\145")) { include_once ABSPATH . "\167\x70\55\x61\x64\155\x69\156\x2f\151\x6e\143\x6c\165\x64\x65\163\x2f\160\154\165\x67\151\x6e\56\x70\150\160"; } return $this->call("\151\x73\x5f\x70\x6c\x75\x67\151\156\137\141\143\x74\151\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\160\x6c\x75\x67\x69\156\x5f\x61\143\164\151\166\145\x5f\146\x6f\162\137\x6e\145\x74\x77\x6f\x72\153", false, $mkysicwccoeicumg); } }
