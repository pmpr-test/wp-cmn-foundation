<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbcd2165a5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\145\x72\x79\137\160\154\165\x67\151\x6e\x73") { if (!function_exists("\x70\x6c\165\147\151\x6e\x73\137\x61\x70\151")) { include_once ABSPATH . "\x77\160\55\x61\144\x6d\x69\x6e\x2f\151\x6e\143\154\x75\x64\x65\163\57\160\x6c\165\x67\x69\x6e\55\151\156\163\x74\x61\x6c\x6c\x2e\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\137\160\154\x75\x67\x69\156\x5f\x61\143\164\x69\166\145")) { include_once ABSPATH . "\167\160\55\141\144\x6d\151\156\57\151\x6e\143\154\x75\144\145\163\57\160\x6c\x75\147\151\x6e\56\160\x68\x70"; } return $this->call("\151\x73\137\x70\154\x75\x67\151\156\137\141\x63\x74\x69\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\x70\154\x75\147\x69\156\137\141\143\164\x69\166\x65\137\146\157\162\x5f\156\x65\164\167\157\x72\153", false, $mkysicwccoeicumg); } }
