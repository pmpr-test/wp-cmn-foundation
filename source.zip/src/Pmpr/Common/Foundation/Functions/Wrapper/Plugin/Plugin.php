<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977684bcc9f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\x65\162\x79\137\x70\154\165\x67\151\156\x73") { if (!function_exists("\160\x6c\165\147\151\156\x73\x5f\141\x70\x69")) { include_once ABSPATH . "\x77\160\55\141\x64\155\151\x6e\57\x69\156\x63\x6c\165\144\145\x73\x2f\x70\x6c\165\x67\x69\x6e\x2d\x69\156\163\164\x61\154\154\x2e\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\160\x6c\x75\147\151\156\137\x61\x63\164\x69\166\x65")) { include_once ABSPATH . "\x77\x70\x2d\141\x64\155\151\156\57\151\x6e\143\154\x75\144\145\x73\x2f\x70\x6c\x75\x67\151\x6e\56\x70\150\x70"; } return $this->call("\151\x73\137\160\x6c\165\147\151\x6e\x5f\x61\143\164\151\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\160\154\x75\x67\151\x6e\x5f\141\143\164\151\166\x65\x5f\x66\x6f\x72\x5f\x6e\x65\164\167\x6f\162\x6b", false, $mkysicwccoeicumg); } }
