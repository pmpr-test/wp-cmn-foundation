<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6ea7f40             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\x65\162\x79\x5f\160\154\165\147\x69\156\163") { if (!function_exists("\160\154\165\147\x69\x6e\x73\x5f\141\x70\x69")) { include_once ABSPATH . "\x77\x70\55\x61\x64\x6d\151\156\57\x69\156\x63\x6c\165\x64\x65\163\x2f\160\154\165\147\151\156\x2d\151\x6e\x73\x74\x61\x6c\x6c\56\x70\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\137\160\x6c\x75\x67\151\156\137\x61\143\x74\x69\166\x65")) { include_once ABSPATH . "\x77\x70\55\141\144\155\x69\156\57\151\156\x63\154\x75\x64\x65\163\x2f\x70\154\x75\x67\151\x6e\56\x70\150\160"; } return $this->call("\x69\163\137\160\154\165\x67\x69\x6e\x5f\x61\x63\x74\x69\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\x70\x6c\165\147\x69\x6e\x5f\141\143\x74\x69\166\145\137\146\157\162\137\156\x65\x74\167\x6f\162\x6b", false, $mkysicwccoeicumg); } }
