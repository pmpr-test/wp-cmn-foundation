<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d16a012f73             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\145\162\x79\x5f\160\x6c\165\x67\x69\x6e\163") { if (!function_exists("\160\154\165\x67\x69\156\163\137\x61\x70\151")) { include_once ABSPATH . "\167\160\55\x61\144\x6d\x69\156\x2f\151\156\x63\x6c\165\144\145\163\x2f\160\x6c\165\147\x69\x6e\x2d\151\x6e\163\164\141\154\x6c\x2e\160\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\x5f\160\154\165\x67\x69\156\137\141\143\x74\151\166\x65")) { include_once ABSPATH . "\x77\160\55\x61\x64\155\x69\156\x2f\151\x6e\143\154\165\144\x65\163\57\x70\154\165\x67\151\x6e\x2e\160\x68\x70"; } return $this->call("\151\163\x5f\160\x6c\x75\147\x69\x6e\x5f\141\143\164\x69\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\160\154\x75\x67\151\x6e\x5f\141\143\164\151\x76\x65\137\146\x6f\162\137\156\x65\164\167\x6f\162\x6b", false, $mkysicwccoeicumg); } }
