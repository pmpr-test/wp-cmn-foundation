<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec7e2db2b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\x65\x72\171\x5f\160\x6c\165\147\151\156\163") { if (!function_exists("\x70\154\x75\x67\x69\x6e\163\137\x61\160\x69")) { include_once ABSPATH . "\167\160\55\141\144\x6d\x69\156\57\x69\x6e\x63\x6c\x75\x64\x65\x73\x2f\x70\154\165\x67\x69\156\55\x69\x6e\163\164\x61\x6c\x6c\56\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\x5f\x70\154\x75\147\151\156\x5f\141\x63\x74\x69\166\145")) { include_once ABSPATH . "\167\x70\55\141\144\155\x69\156\x2f\151\156\x63\154\165\144\x65\x73\57\x70\x6c\165\x67\151\156\x2e\x70\150\x70"; } return $this->call("\x69\x73\x5f\160\x6c\x75\x67\151\156\137\141\143\x74\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\x70\x6c\x75\147\151\x6e\x5f\141\x63\x74\x69\x76\x65\137\146\157\x72\x5f\x6e\x65\x74\167\x6f\x72\x6b", false, $mkysicwccoeicumg); } }
