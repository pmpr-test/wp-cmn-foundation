<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43c6c83e1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\x65\162\171\137\160\154\x75\147\x69\x6e\163") { if (!function_exists("\x70\154\165\x67\x69\x6e\163\137\x61\160\x69")) { include_once ABSPATH . "\167\x70\x2d\x61\144\155\x69\156\x2f\x69\156\x63\x6c\x75\144\145\163\57\x70\x6c\x75\147\151\156\55\151\156\163\164\x61\154\154\56\x70\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\137\x70\x6c\x75\x67\151\156\137\141\x63\x74\151\166\x65")) { include_once ABSPATH . "\167\x70\x2d\141\144\155\151\156\x2f\x69\x6e\x63\154\x75\x64\x65\x73\57\160\x6c\165\x67\151\156\56\160\x68\160"; } return $this->call("\x69\x73\x5f\x70\154\x75\x67\x69\x6e\137\141\x63\164\x69\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\x70\x6c\165\147\151\x6e\x5f\141\143\164\x69\166\145\137\x66\157\162\x5f\x6e\x65\164\x77\157\162\153", false, $mkysicwccoeicumg); } }
