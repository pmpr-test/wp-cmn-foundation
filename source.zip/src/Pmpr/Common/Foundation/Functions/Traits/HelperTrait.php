<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0611cd07             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Traits; use Pmpr\Common\Foundation\Functions\Helper\Helper; trait HelperTrait { public function caokeucsksukesyo() : Helper { return Helper::symcgieuakksimmu(); } public static function iwgqamekocwaigci() : Helper { return Helper::symcgieuakksimmu(); } }
