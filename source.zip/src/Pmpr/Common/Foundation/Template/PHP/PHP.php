<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6994f2c42b22b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\PHP; use Pmpr\Common\Foundation\Container\Container; class PHP extends Container { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
