<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c8474599ed             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\PHP; use Pmpr\Common\Foundation\Container\Container; class PHP extends Container { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
