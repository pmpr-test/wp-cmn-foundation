<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c72e8c2b8c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\PHP; use Pmpr\Common\Foundation\Container\Container; class PHP extends Container { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
