<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c3eae6175f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\PHP; use Pmpr\Common\Foundation\Container\Container; class PHP extends Container { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
