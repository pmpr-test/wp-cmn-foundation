<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76ba63557             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template; use Pmpr\Common\Foundation\Template\Twig\Twig; class Template extends Common { public function mameiwsayuyquoeq() { Twig::symcgieuakksimmu(); } }
