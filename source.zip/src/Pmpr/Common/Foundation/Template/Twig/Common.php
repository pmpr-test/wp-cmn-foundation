<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae859a8f03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; use Pmpr\Common\Foundation\Template\Common as BaseClass; class Common extends BaseClass { }
