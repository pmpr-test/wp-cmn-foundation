<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7a86a94f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\x67\151\x6e\163\137\154\x6f\141\x64\145\x64", [$this, "\154\x6f\x61\144"])->qcsmikeggeemccuu("\141\x66\164\x65\162\137\163\x65\164\165\160\x5f\164\x68\145\155\145", [$this, "\153\x67\153\155\167\x75\143\x6d\153\x63\x71\x61\153\x73\155\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\144\137\164\x65\155\160\154\141\164\151\x6e\147\x5f\160\x61\x74\x68", [$this, "\167\153\x6f\x73\151\143\163\x65\153\x77\153\x69\x67\171\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
