<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d8187bb66             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\x75\x67\x69\x6e\x73\137\154\157\x61\x64\145\144", [$this, "\x6c\x6f\x61\x64"])->qcsmikeggeemccuu("\x61\x66\164\145\x72\137\x73\x65\x74\x75\160\x5f\x74\x68\145\155\145", [$this, "\153\147\x6b\155\167\x75\143\x6d\153\x63\x71\x61\153\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\x64\x64\137\164\x65\x6d\x70\x6c\x61\164\151\156\147\137\160\141\164\x68", [$this, "\x77\x6b\157\x73\151\143\x73\x65\153\x77\153\151\x67\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
