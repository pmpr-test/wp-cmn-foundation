<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16ae3d454f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\x69\156\163\137\x6c\x6f\x61\x64\x65\x64", [$this, "\x6c\157\141\x64"])->qcsmikeggeemccuu("\141\x66\x74\x65\162\137\x73\145\x74\165\160\137\164\x68\x65\155\x65", [$this, "\153\147\153\155\167\x75\x63\x6d\153\143\x71\x61\153\163\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\144\144\137\x74\145\155\160\154\x61\x74\x69\156\147\x5f\160\x61\x74\150", [$this, "\x77\x6b\x6f\163\x69\x63\163\x65\153\x77\x6b\x69\147\x79\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
