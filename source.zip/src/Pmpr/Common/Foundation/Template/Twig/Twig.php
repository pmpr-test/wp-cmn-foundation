<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192c055a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\165\x67\x69\156\163\137\154\x6f\141\x64\x65\x64", [$this, "\x6c\157\141\x64"])->qcsmikeggeemccuu("\141\x66\x74\145\x72\137\x73\x65\164\165\x70\x5f\164\150\145\155\x65", [$this, "\153\147\153\x6d\167\x75\x63\155\x6b\x63\161\x61\x6b\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\x64\144\x5f\164\x65\x6d\160\154\x61\x74\151\156\x67\137\160\141\164\150", [$this, "\167\153\157\x73\x69\x63\x73\x65\153\167\x6b\151\147\171\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
