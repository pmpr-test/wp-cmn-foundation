<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2ce2062a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\165\147\151\156\x73\x5f\154\x6f\141\144\x65\x64", [$this, "\154\157\x61\144"])->qcsmikeggeemccuu("\141\x66\x74\145\x72\x5f\x73\145\164\x75\160\137\164\150\145\155\145", [$this, "\153\x67\153\155\167\x75\143\x6d\x6b\143\x71\141\x6b\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\137\164\145\x6d\160\154\x61\164\151\x6e\147\x5f\160\x61\164\x68", [$this, "\167\153\157\163\x69\143\x73\x65\153\x77\x6b\151\147\x79\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
