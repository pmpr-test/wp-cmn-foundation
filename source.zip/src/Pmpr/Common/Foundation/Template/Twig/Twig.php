<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b55badb8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\x67\151\x6e\163\137\154\x6f\x61\144\x65\144", [$this, "\154\x6f\141\144"])->qcsmikeggeemccuu("\x61\x66\164\145\162\x5f\163\x65\x74\165\160\x5f\164\150\x65\x6d\x65", [$this, "\153\147\153\x6d\x77\165\143\x6d\x6b\143\161\x61\x6b\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\144\144\137\x74\x65\x6d\160\154\x61\164\x69\x6e\x67\137\x70\x61\x74\x68", [$this, "\167\153\157\x73\x69\143\x73\x65\x6b\167\153\151\x67\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
