<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdfa86cb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\151\x6e\x73\137\154\157\141\144\145\144", [$this, "\x6c\157\x61\x64"])->qcsmikeggeemccuu("\x61\x66\164\x65\x72\x5f\x73\x65\164\x75\x70\137\x74\x68\x65\155\x65", [$this, "\x6b\x67\153\x6d\167\x75\x63\155\x6b\143\161\x61\153\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\x5f\164\145\155\160\154\x61\x74\x69\x6e\147\x5f\x70\141\164\150", [$this, "\167\x6b\x6f\163\151\143\x73\x65\153\167\x6b\x69\x67\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
