<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132d18d1e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\165\147\151\156\x73\x5f\x6c\157\141\144\145\144", [$this, "\x6c\x6f\141\144"])->qcsmikeggeemccuu("\x61\x66\164\145\162\137\x73\145\164\x75\x70\x5f\164\x68\145\x6d\145", [$this, "\153\x67\x6b\155\x77\165\143\x6d\153\x63\x71\x61\x6b\x73\155\157"], 99, 2); $this->waqewsckuayqguos("\141\x64\x64\x5f\164\145\x6d\160\154\141\x74\151\156\x67\x5f\x70\141\164\x68", [$this, "\167\153\x6f\163\151\143\163\145\153\167\153\151\147\171\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
