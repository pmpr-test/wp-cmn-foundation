<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e76cb0010             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\x75\147\x69\156\163\137\x6c\157\141\x64\145\x64", [$this, "\x6c\157\141\x64"])->qcsmikeggeemccuu("\x61\x66\164\x65\x72\x5f\x73\145\x74\165\160\137\164\x68\145\155\x65", [$this, "\x6b\147\153\x6d\x77\165\x63\155\x6b\143\161\141\x6b\163\x6d\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\x5f\x74\x65\155\160\154\141\x74\151\156\147\x5f\160\x61\x74\150", [$this, "\x77\x6b\x6f\163\151\x63\163\x65\x6b\x77\153\151\147\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
