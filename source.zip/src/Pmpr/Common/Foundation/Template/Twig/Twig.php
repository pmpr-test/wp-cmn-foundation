<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe091cfc2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\147\151\x6e\x73\x5f\x6c\157\141\x64\145\x64", [$this, "\154\157\141\144"])->qcsmikeggeemccuu("\141\x66\164\145\162\x5f\163\145\x74\x75\160\137\x74\150\145\155\145", [$this, "\x6b\147\153\155\167\165\143\155\x6b\x63\x71\141\x6b\163\155\157"], 99, 2); $this->waqewsckuayqguos("\141\x64\x64\x5f\164\x65\x6d\x70\154\141\164\151\x6e\147\x5f\160\x61\x74\150", [$this, "\167\153\x6f\163\151\x63\x73\145\153\x77\153\x69\x67\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
