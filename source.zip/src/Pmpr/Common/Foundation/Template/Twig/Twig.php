<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71e78dabb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; use Pmpr\Common\Foundation\Container\Container; class Twig extends Container { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('plugins_loaded', [$this, 'load'])->qcsmikeggeemccuu('pmpr_component_changed', [$this, 'mekkwmacsyouqyum'])->qcsmikeggeemccuu('after_setup_theme', [$this, 'kgkmwucmkcqaksmo'], 99, 2); $this->waqewsckuayqguos('add_templating_path', [$this, 'wkosicsekwkigyss'], 10, 2); } public function load() { $this->uykissogmuaaocsg()->load(); } public function mekkwmacsyouqyum() { if ($skacuygeqykiwiwy = $this->uykissogmuaaocsg()->gskqygiceygcguyo()) { $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk()->remove($skacuygeqykiwiwy); } } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
