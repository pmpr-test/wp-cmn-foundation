<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1795dce7fb             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\x67\x69\156\x73\x5f\x6c\x6f\x61\144\x65\x64", [$this, "\x6c\x6f\x61\x64"])->qcsmikeggeemccuu("\x61\x66\164\x65\162\137\163\x65\164\x75\x70\x5f\164\x68\x65\155\x65", [$this, "\x6b\147\153\155\x77\x75\x63\x6d\153\143\x71\141\x6b\163\x6d\157"], 99, 2); $this->waqewsckuayqguos("\141\144\x64\137\x74\x65\155\x70\x6c\141\x74\x69\x6e\x67\x5f\x70\x61\164\x68", [$this, "\x77\x6b\x6f\163\x69\143\x73\145\153\167\x6b\x69\147\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
