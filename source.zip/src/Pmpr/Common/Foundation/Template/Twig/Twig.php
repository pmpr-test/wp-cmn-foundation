<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16ccfaa782             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\165\x67\151\156\163\x5f\x6c\x6f\x61\144\x65\x64", [$this, "\x6c\157\141\x64"])->qcsmikeggeemccuu("\x61\146\x74\145\x72\137\163\x65\x74\165\x70\137\x74\150\x65\x6d\145", [$this, "\153\x67\x6b\155\x77\x75\x63\x6d\x6b\143\x71\x61\x6b\x73\155\157"], 99, 2); $this->waqewsckuayqguos("\141\144\144\x5f\164\145\155\160\154\141\x74\151\x6e\x67\x5f\160\141\164\x68", [$this, "\167\153\157\x73\151\143\x73\145\x6b\167\153\151\x67\x79\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
