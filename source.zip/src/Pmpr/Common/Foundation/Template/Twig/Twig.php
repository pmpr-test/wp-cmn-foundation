<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2e8864db             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\x67\151\x6e\163\137\154\x6f\x61\x64\145\x64", [$this, "\x6c\x6f\x61\x64"])->qcsmikeggeemccuu("\141\x66\164\x65\162\137\x73\x65\164\x75\160\x5f\x74\150\x65\x6d\x65", [$this, "\153\147\x6b\x6d\167\x75\143\x6d\153\143\161\x61\x6b\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\144\x5f\164\145\x6d\160\x6c\x61\164\x69\156\x67\137\160\141\164\150", [$this, "\x77\x6b\157\x73\151\x63\163\x65\x6b\167\x6b\151\x67\171\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
