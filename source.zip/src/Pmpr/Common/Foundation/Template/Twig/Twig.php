<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e1810bd5408             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\x67\x69\x6e\x73\137\154\x6f\141\144\x65\x64", [$this, "\154\157\141\144"])->qcsmikeggeemccuu("\141\x66\x74\x65\162\137\163\145\164\x75\160\137\x74\150\145\x6d\x65", [$this, "\153\147\x6b\155\x77\165\x63\155\x6b\x63\161\x61\153\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\x64\137\x74\145\155\160\154\141\164\151\x6e\x67\137\x70\x61\x74\x68", [$this, "\x77\153\x6f\163\151\x63\163\x65\x6b\167\153\x69\x67\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
