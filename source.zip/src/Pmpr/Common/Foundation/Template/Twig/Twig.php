<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae859a8f03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\x67\151\156\x73\137\x6c\157\x61\144\145\144", [$this, "\x6c\157\141\x64"])->qcsmikeggeemccuu("\141\146\x74\145\x72\137\163\x65\164\x75\x70\137\x74\x68\145\x6d\145", [$this, "\x6b\x67\153\x6d\167\165\x63\x6d\153\x63\x71\141\153\x73\x6d\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\x64\137\164\x65\155\160\154\x61\x74\151\x6e\x67\x5f\160\141\x74\150", [$this, "\x77\x6b\x6f\163\x69\143\x73\x65\x6b\167\153\151\147\x79\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
