<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08edec3b9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\x67\x69\156\163\x5f\154\157\141\x64\145\144", [$this, "\154\x6f\x61\x64"])->qcsmikeggeemccuu("\141\146\164\x65\162\x5f\x73\145\x74\x75\x70\x5f\x74\x68\x65\x6d\145", [$this, "\x6b\147\x6b\155\x77\x75\x63\x6d\153\143\x71\141\x6b\163\155\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\137\164\x65\x6d\160\154\x61\164\x69\x6e\147\x5f\x70\141\x74\150", [$this, "\x77\153\x6f\x73\151\143\163\x65\153\x77\153\151\x67\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
