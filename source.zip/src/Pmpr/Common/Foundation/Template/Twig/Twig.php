<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf62d32095             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\147\x69\x6e\x73\x5f\154\157\141\x64\145\x64", [$this, "\x6c\x6f\141\144"])->qcsmikeggeemccuu("\x61\146\164\145\162\x5f\163\145\164\165\x70\x5f\x74\x68\145\155\x65", [$this, "\x6b\147\x6b\155\x77\x75\x63\155\x6b\x63\x71\141\x6b\x73\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\x64\x5f\164\x65\x6d\x70\154\x61\x74\x69\x6e\x67\137\x70\x61\164\150", [$this, "\x77\x6b\157\163\151\x63\x73\145\153\167\153\x69\147\171\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
