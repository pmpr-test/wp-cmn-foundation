<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f3a1d1b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\x67\151\156\x73\137\154\x6f\141\x64\x65\144", [$this, "\x6c\x6f\141\x64"])->qcsmikeggeemccuu("\x61\146\x74\x65\x72\x5f\163\145\164\165\x70\137\164\150\x65\155\x65", [$this, "\153\147\x6b\x6d\167\x75\143\x6d\x6b\143\x71\x61\x6b\163\155\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\144\137\164\145\155\x70\154\x61\164\x69\x6e\x67\137\160\141\164\x68", [$this, "\167\153\157\163\151\x63\x73\x65\x6b\x77\x6b\x69\147\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
