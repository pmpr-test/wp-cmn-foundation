<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e176fddf2d5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\151\x6e\163\137\154\157\141\x64\145\x64", [$this, "\x6c\x6f\x61\x64"])->qcsmikeggeemccuu("\x61\x66\x74\x65\162\x5f\x73\x65\164\165\x70\x5f\164\150\x65\155\145", [$this, "\153\147\x6b\x6d\167\165\143\x6d\x6b\143\x71\x61\x6b\163\155\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\144\137\164\x65\x6d\x70\x6c\x61\164\151\x6e\147\x5f\x70\141\x74\150", [$this, "\167\153\x6f\163\151\143\x73\145\x6b\167\x6b\151\x67\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
