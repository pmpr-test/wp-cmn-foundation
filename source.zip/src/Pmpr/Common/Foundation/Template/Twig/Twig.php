<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e17b763d23d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\x67\x69\156\x73\137\154\x6f\x61\144\145\x64", [$this, "\x6c\x6f\x61\144"])->qcsmikeggeemccuu("\141\146\164\145\x72\x5f\x73\x65\x74\x75\160\x5f\x74\x68\145\155\145", [$this, "\x6b\147\153\x6d\167\x75\143\155\153\143\x71\x61\x6b\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\x64\137\x74\x65\155\x70\154\x61\x74\151\x6e\147\x5f\160\x61\x74\x68", [$this, "\167\153\x6f\163\151\143\x73\x65\153\x77\x6b\151\x67\x79\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
