<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec04c26714e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\165\147\151\x6e\163\x5f\x6c\x6f\141\144\x65\144", [$this, "\154\157\141\x64"])->qcsmikeggeemccuu("\x61\x66\x74\145\162\x5f\163\145\x74\x75\160\137\164\x68\145\155\145", [$this, "\x6b\x67\153\x6d\167\x75\143\155\153\143\161\141\153\163\155\x6f"], 99, 2); $this->waqewsckuayqguos("\141\x64\x64\137\164\145\x6d\x70\x6c\x61\164\x69\x6e\x67\x5f\160\x61\x74\x68", [$this, "\167\x6b\x6f\x73\151\143\163\145\x6b\167\x6b\x69\x67\171\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
