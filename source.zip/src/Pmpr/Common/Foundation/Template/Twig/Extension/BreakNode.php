<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c1476eb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig\Extension; use Twig\Attribute\YieldReady; use Twig\Compiler; use Twig\Node\Node; #[YieldReady] class BreakNode extends Node { public function compile(Compiler $wikuywwagioieuau) { $wikuywwagioieuau->addDebugInfo($this); $wikuywwagioieuau->write("\x62\162\x65\x61\153\x3b\12"); } }
