<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6876c49d14873             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig\Extension; use Twig\Attribute\YieldReady; use Twig\Compiler; use Twig\Node\Node; #[YieldReady] class BreakNode extends Node { public function compile(Compiler $wikuywwagioieuau) { $wikuywwagioieuau->addDebugInfo($this); $wikuywwagioieuau->write("break;\n"); } }
