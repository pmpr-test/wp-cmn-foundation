<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522aeb59a71             |
    |_______________________________________|
*/
 use Pmpr\Common\Foundation\Foundation; if (!function_exists("\160\x72\x5f\147\x65\x74\137\x66\x6f\165\156\x64\x61\164\151\157\156")) { function pr_get_foundation() : Foundation { return Foundation::symcgieuakksimmu(); } } if (!function_exists("\160\x6d\x70\x72\x5f\x61\x70\160\x6c\x79\x5f\x66\151\154\164\x65\x72")) { function pmpr_apply_filters($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { return pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } if (!function_exists("\x70\155\160\162\137\x64\x6f\137\x61\143\164\151\157\x6e")) { function pmpr_do_action($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ewcsyqaaigkicgse($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } pr_get_foundation();
