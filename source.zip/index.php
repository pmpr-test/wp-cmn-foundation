<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d0000cbc1b             |
    |_______________________________________|
*/
 use Pmpr\Common\Foundation\Foundation; if (!function_exists("\160\162\137\x67\145\x74\137\x66\x6f\x75\156\x64\141\164\151\157\x6e")) { function pr_get_foundation() : Foundation { return Foundation::symcgieuakksimmu(); } } if (!function_exists("\x70\x6d\x70\x72\137\141\x70\x70\x6c\171\137\x66\x69\154\164\145\x72")) { function pmpr_apply_filters($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { return pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } if (!function_exists("\x70\155\160\162\x5f\144\x6f\x5f\x61\143\x74\x69\x6f\x6e")) { function pmpr_do_action($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ewcsyqaaigkicgse($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } pr_get_foundation();
