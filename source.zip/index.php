<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d585ed47eb             |
    |_______________________________________|
*/
 use Pmpr\Common\Foundation\Foundation; if (!function_exists("\x70\x72\137\147\145\164\137\x66\157\x75\156\x64\x61\x74\151\x6f\156")) { function pr_get_foundation() : Foundation { return Foundation::symcgieuakksimmu(); } } if (!function_exists("\x70\x6d\x70\x72\x5f\x61\160\x70\x6c\x79\x5f\146\151\154\x74\145\x72")) { function pmpr_apply_filters($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { return pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } if (!function_exists("\160\x6d\x70\162\x5f\144\157\x5f\141\143\164\x69\x6f\x6e")) { function pmpr_do_action($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ewcsyqaaigkicgse($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } pr_get_foundation();
